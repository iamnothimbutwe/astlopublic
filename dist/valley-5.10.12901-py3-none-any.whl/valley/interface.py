
import click
from .valley import Todo
from rich.console import Console
from importlib import resources
from .astlo_intergrate import AstloIntergrate
import json
import os
#import signal
import sys
from astlo import Topocentric, Contin
from .astlotalk import talk

console = Console()

email = 'astlospacesystems@gmail.com'

@click.group()
@click.version_option(version=f"v5.10.12901\ndeveloper: @iamnothimbutwe on Github and Gitlab")
@click.pass_context
def ltx(ctx):
    ctx.obj={'todo':Todo(),'astlointergrate':AstloIntergrate(),'topocentric':Topocentric(),'contin':Contin()}

@ltx.command()
@click.option('--key','-k',default=None, help='the key to the cipher',type=
str)
@click.option('--priority','-p',prompt='The Priority',default='m',type=str,
help='use "l" for Lower, "m" for Medium and "h" for High...priorities'
)
@click.option('--restore','-r',default=None,help='give a value to this to restore deleted entries')
@click.pass_context
def add_todo(ctx,key,priority,restore):
    ctx.obj['todo'].add_todo(key,priority,restore)


@ltx.command()
@click.option('--clrh','-c',default=None,help='giving a value to this to empty the recycle bin',type=str)
@click.pass_context
def delete_todo(ctx,clrh):
    ctx.obj['todo'].delete_todo(clrh)


@ltx.command()
@click.option('--deleted','-dted',default=None,help='lists the deleted NOTES and todos.')
@click.option('--restored','-re',default=None,help='lists the history of restored entries. Restored entries cannot be deleted/cleared. Enjoy your history')
@click.option('--talkastlo','-at',default=None,help='give this option a value to view the current stored contents of the astlo_integrate module. The upside of this option is that valley spices up the view to be more readable and appealing to the human user.')
@click.pass_context
def list_todo(ctx,deleted,restored,talkastlo):
    if os.name=='nt':
        os.system('cls')
    else:
        os.system('clear')

    ctx.obj['todo'].list_todo(deleted,restored,talkastlo)



@ltx.command()
@click.option('--reset','-r',default=None,help='giving this a value will reset/clear all files automatically and exit')
@click.option('--single','-s',default=None,help='giving a value to this will allow the user to choose which file to clear and then exit')
@click.option('--show','-sh',default=None,help='give a value to this option to show the current set settings')
@click.pass_context
def settings(ctx,reset,single,show):
    if show:
        package_root = resources.files('valley')
        setup = package_root / 'setup.json'
        with open(setup,'r') as f:
            data = json.load(f)

        print(f'internal_key_generation_boolean: {data['ciph_sett']}\nUser_specific_location_settings: {data['location_setting']}')
        return

    ctx.obj['todo'].settings(reset,single)



@ltx.command()
@click.option('--entry','-ent',default=None,help='pass the entry here if both ways of decoding fail. if you forget the manually used key, contact the author.',type=str)
@click.pass_context
def decode(ctx,entry):

    if entry:
        decode = ctx.obj['todo'].override_decode(entry)
        console.print(f'[bold cyan]For the passed entry [yellow]{entry}[/yellow], using all the available internal keys gives the following encoded values. white spaces are removed for security reasons:[/bold cyan]\n\n')

        for idx,itm in enumerate(decode):
            print(f'encoding {idx+1} ¦¦¦ {itm}')

        return
    else:
        ctx.obj['todo'].decode()



@ltx.command()
@click.option('--key','-k',default=None,help='if the key used to encode an entry is manually passed, pass it here. This option expects the remembered key. if the manual key used is forgotten, contact the author/developer for help.',type=str)
@click.pass_context
def manual_decode(ctx,key):
    ctx.obj['todo'].manual_decode(key)



@ltx.command()
@click.option('--name','-n',default=None,help='The name of the Solar system object',type=str)
@click.pass_context
def astlointergrate(ctx,name):
    if name==None:
        console.print('[red]name is required to continue for this method.[/red]')
        return

    try_one = ctx.obj['astlointergrate'].genfullpath(name)

    if try_one=='NAME NOT SUPPORTED':
        console.print(f'[red]{try_one}[/red]')
        sys.exit(0) #failed.


    console.print(f'[bold white]Saved to {os.system('pwd') if os.name=='nt' else os.system('cd')} - fullpath.json[/bold white]')






@ltx.command
@click.option('--name','-n',default=None,help='the name of the Solar system object.',type=str) #maybe it is not a must i use -- or - whule defining an option initializer..
@click.option('--latitude','-lat',default=None,help='''Your location's latitude in degrees North or South of Equator.''',type=float)
@click.option('--longitude','-long',default=None,help='''Your location's longitude in degrees East or West of Equator.''',type=float)
@click.option('--altitude','-alt',default=None,help='''Your location's altitude above sea level in meters m.''',type=float)
@click.option('--days','-dy',default=None,help='if you want to time step to a certain second, minute, hour, day, year, millions and billions of years forwad or backwards, give this option an interger value in terms of days. IN TERMS OF DAYS.',type=float)
@click.option('--rktt','-tt',default=None,help='default is one hour for the internal rungekutta 4th order accuracy. How long do you want the runge kutta logic to time-step.? If unrequired, do not touch this option.',type=float)
@click.option('--visible_or_not','-visnot',default=None,help='if you want to know which solar system object is visible or not relative your location on Earths surface, give this option any value.')
@click.option('--explain','-expl',default=None,help='if you want astlo to explain to you in raw-text whatever is happening in your local sky. Solar System Object.')
@click.option('--ephem','-eph',default='y',help='if you want to use de440.bsp from NASA JPL to track the object. This file only supportes Sun, Venus, Mercury and moon-luna. astlo has an internal ephemeris powered by its internal rungekutta for all the objects. The external file is only for precision.\n If visnot option is given a value, astlo will only read Luna topocentric states externally and the other objects topocentric states will be internal. ephem option is best used with a single object /Sun,Venus,Mercury.\n Ignore this option.')
@click.pass_context
def topocentric(ctx,name,latitude,longitude,altitude,days,rktt,visible_or_not,explain,ephem):
    '''this valley interface method resembles astlos topocentric method in interface too. Though the main d8ffrence is that this method automatically triggers talk method in astlotalk. for ease of use to the normal user.'''

    if name and visible_or_not and explain==None:
        console.print('[red]if visible_or_not option is given a value, do not use it together with the name option[/red]')
        return
    if latitude==None or longitude==None or altitude==None:
        console.print('[red]The solar system object name and your latitude, longitude, altitude are all reauired to continue')
        return

    if name:
        name = name.upper()
    
    ephe_supp = ['SUN','VENUS','MERCURY','LUNA','LUNAR','MOON'] #for luna, the core engine automatugally reads from the external json file...however remember to initialize the states from de440 if needed...the previois hashed out comment was for astlo.topocentric not valley.topocentric
    if ephem and name not in ephe_supp: #here ephem is always set to True with a value..
      #  console.print(f'[red]Target object {name} cannot be read from the external file. Use astlo-topocentric standalone without the ephem option. de440 only supportes Sun, Venus, Mercury and Luna. If name passed was luna, do not activate ephem since astlo automatically reads luna states externally.[/red]') #reduntant error message. was for astlo..here everything is automatic
        console.print('[red]Target object cannot be read from the external file. astlohorizons needs to be updated to handle all internal objects. Use astlo.topocentric CLI for the other objects. Currently supported objects by astlo.valley.topocentric = [SUN,VENUS,MERCURY,LUNA,LUNAR,MOON][/red]')
        return

    if visible_or_not and explain:
        console.print('[red]either use visnot solely or explain solely but not both at the same time.')
        return

#topocentric method in both astlo and valley needs update because astlo supports 21 objects as of now.                                                                                                                                             
    data_dict = ['SUN','MERCURY','VENUS','LUNA','MARS','VESTA','CERES','PALLAS','HYGIEA','JUPITER','SATURN','URANUS','NEPTUNE','PLUTO','HAUMEA','MAKEMAKE','ERIS']

    if visible_or_not==None and explain==None:
        if name==None:
            console.print('[red]The name of the object is required[/red]')
            return

        if name=='EARTH':
            console.print('[red]you cannot observe Earth from Earth[/red]')
            return
      #  while True:
        # This sends a real SIGINT to the current process, triggering the handler cleanly
       # os.kill(os.getpid(), signal.SIGINT) #this statement passes the keyboard interrupt that the talk msthod will catch then the excspt statement will handle it Nd continue
     #using a try exceptnway that will allow jumping to the next line without aboritng the whoke program
      #  try:
        talk(name)# valley has its own version of astlotalk which is modified to not print a filw updated text evey one minute..the SIGINT # Calling the method immediately after; it will intercept the pending SIGINT
       # except KeyboardInterrupt:
          #  print('\ncontinuing to main\n')
          #  break

        data = ctx.obj['topocentric'].topo(name,latitude,longitude,altitude,days,rktt,ephem)

        #    if name=='EARTH':
        #       return

        console.print(f'[cyan]name: [/cyan][bold white]{data['name']}[/bold white]\n\n[yellow]The following are the topocentric states for {data['name']} relative location //{latitude}, {longitude}, {altitude}] [/yellow//\n\n[cyan]UTC time: [/cyan][bold white]{data['UTC_time']} + {data['dayss']} days[/bold white]\n[cyan]Time: [/cyan][bold white]{data['time']} + {data['dayss']} days[/bold white]\n[cyan]elevation angle in degrees: [/cyan][bold white]{data['elevation_deg']}°[/bold white]\n[cyan]azimuth angle in degrees: [/cyan][bold white]{data['azimuth_deg']}°[/bold white]\n[cyan]slant range-The distance from your eyes to {data['name']}: [/cyan][bold white]{data['slant_range']} meters ¦ {data['slant_range']/ctx.obj['contin'].AU_m} AU[/bold white]\n[cyan]Horizontal slant_range: [/cyan][bold white]{data['horizontal_slant_range']} meters ¦ {data['horizontal_slant_range']/ctx.obj['contin'].AU_m} AU[/bold white]\n[yellow]Earth position vector relative SSB: [/yellow][bold white]{data['earth_pos_vector_rel_SSB']} meters[/bold white]\n[yellow]{data['name']} position vector relative SSB: [/yellow][bold white]{data[f'{data['name']}_pos_vector_rel_SSB']} meters[/bold white]\n[cyan]{data['name']} Geocentric distance: [/cyan][bold white]{data['r_geocentric_magn']} meters ¦ {data['r_geocentric_magn']/ctx.obj['contin'].AU_m} AU[/bold white]\n[yellow]Light takes {data['light_delay']} seconds, {data['light_delay']/60} minutes to reach your eyes from {data['name']}[/yellow]')
        return

    if visible_or_not==None and explain:
        if name==None:
            console.print('[red]The name of the object is required[/red]')
            return

        console.print(f'\n[yellow]The explain option requires a time delay of 1 minute for each object to allow your location on Earth to rotate 0.25° east.\ndelay.../\n\n\n')

        if name=='EARTH':
            console.print('[red]you cannot observe Earth from Earth[/red]')
            return

     #   while True:
     #   os.kill(os.getpid(), signal.SIGINT)
      #  try:
        talk(name)
       # except KeyboardInterrupt:
        #    print('\ncontinuing to main\n')
          #  break

        data, exp = ctx.obj['topocentric'].topo_combined(name,latitude,longitude,altitude,days,rktt,ephem)

      #  if name=='EARTH':
       #     return



        console.print(f'[cyan]name: [/cyan][bold white]{data['name']}[/bold white]\n\n[yellow]The following are the topocentric states for {data['name']} relative location //{latitude}, {longitude}, {altitude}// [/yellow]\n\n[cyan]UTC time: [/cyan][bold white]{data['UTC_time']} + {data['dayss']} days[/bold white]\n[cyan]Time: [/cyan][bold white]{data['time']} + {data['dayss']} days[/bold white]\n[cyan]elevation angle in degrees: [/cyan][bold white]{data['elevation_deg']}°[/bold white]\n[cyan]azimuth angle in degrees: [/cyan][bold white]{data['azimuth_deg']}°[/bold white]\n[cyan]slant range-The distance from your eyes to {data['name']}: [/cyan][bold white]{data['slant_range']} meters ¦ {data['slant_range']/ctx.obj['contin'].AU_m} AU[/bold white]\n[cyan]Horizontal slant_range: [/cyan][bold white]{data['horizontal_slant_range']} meters ¦ {data['horizontal_slant_range']/ctx.obj['contin'].AU_m} AU[/bold white]\n[yellow]Earth position vector relative SSB: [/yellow][bold white]{data['earth_pos_vector_rel_SSB']} meters[/bold white]\n[yellow]{data['name']} position vector relative SSB: [/yellow][bold white]{data[f'{data['name']}_pos_vector_rel_SSB']} meters[/bold white]\n[cyan]{data['name']} Geocentric distance: [/cyan][bold white]{data['r_geocentric_magn']} meters ¦ {data['r_geocentric_magn']/ctx.obj['contin'].AU_m} AU[/bold white]\n[yellow]Light takes {data['light_delay']} seconds, {data['light_delay']/60} minutes to reach your eyes from {data['name']}[/yellow]\n\n[yellow]Explanation 1: [/yellow][bold white]{exp['setting']}[/bold white]\n[yellow]Explanation 2: [/yellow][bold white]{exp['explanation']}[/bold white]\n')
        return

    if visible_or_not and explain==None:
        console.print(f'\n[yellow]The explain option requires a time delay of 1 minute for each object to allow your location on Earth to rotate 0.25° east.\ndelay.../\n\n\n     [yellow]Solar system objects relative location //{latitude}, {longitude}, {altitude}//\n')
        if name=='EARTH':
            console.print('[red]you cannot observe Earth from Earth[/red]')
            return

        vis,dayz,timee,utctime = ctx.obj['topocentric'].which(latitude,longitude,altitude,days,rktt)

     #   if name=='EARTH':
      #      return


        for idx,itm in enumerate(vis):
            console.print(f'[yellow]{data_dict[idx]}: [/yellow][bold white]{itm}[/bold white] ((at {timee[idx]} UTCtime = {utctime[idx]})) + {dayz} days.')

        return

