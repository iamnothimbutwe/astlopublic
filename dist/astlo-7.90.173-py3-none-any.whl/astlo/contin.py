# Copyright © 2026 Mark Macharia [@iamnothimbutwe Github]
# All rights reserved.

# Unauthorized copying, modification, distribution, or commercial use of this software (or substantial portions of it) is strictly prohibited without express written permission from the author.


from .astlo import Astro
from rich.console import Console
import sys
import math
import time
import plotext as ptxt
import platform
import os
from .vect import Vectors


# ---------------------------------------------------------
# Copyright (c) 2026 Mark. All rights reserved.
# Unauthorized copying of this file, via any medium, is
# strictly prohibited. developed by Mark Macharia [iamnothimbutwe] on Github.
# ---------------------------------------------------------


console = Console()
vectors = Vectors()


class Contin(Astro):

    def __init__(self):
        super().__init__()
        self.mission = 'to make astrophyiscs and orbital mechanics accessible to anykne with a terminal withoit nneeding heavy libraries and the internet..' #it will be big one day thougu😣/heavy library one day


    def day_finder(self,name: str=None):
        name = name.upper()
        return #continue
        



    def baryc_sun(self):
        '''calculates the barycebtric shift relative to the barycentric center of mass using meters and seconds'''

        values = ['MERCURY','VENUS','EARTH','MARS','VESTA','CERES','PALLAS','HYGIEA','JUPITER','SATURN','URANUS','NEPTUNE','PLUTO','HAUMEA','MAKEMAKE','ERIS']
        
        vallues = []

        for i in values:
            vallues.append(super().orbits(i)) # orbits returns a dictionary therefore vallues will contain multiple dictionaries containing values of of planeta at specific unux time stamps

        ###barycentric logic..USING ALL PLANETS FOR PRESICION###
        #total_mass = (self.MoS_kg+(self.Jupiter_mass*self.MoE_kg)+(self.Saturn_mass*self.MoE_kg)+(self.Uranus_mass*self.MoE_kg)+(self.Neptune_mass*self.MoE_kg))

        mercury = self.Mercury_mass*self.MoE_kg
        venus = self.Venus_mass*self.MoE_kg
        earth = self.MoE_kg
        mars = self.Mars_mass*self.MoE_kg
        vesta = self.Vesta_mass*self.MoE_kg
        ceres = self.Ceres_mass*self.MoE_kg
        pallas = self.Pallas_mass*self.MoE_kg
        hygiea = self.Hygiea_mass*self.MoE_kg
        jupiter = self.Jupiter_mass*self.MoE_kg
        saturn = self.Saturn_mass*self.MoE_kg
        uranus = self.Uranus_mass*self.MoE_kg
        neptune = self.Neptune_mass*self.MoE_kg
        pluto = self.Pluto_mass*self.MoE_kg
        makemake = self.Makemake_mass*self.MoE_kg
        haumea = self.Haumea_mass*self.MoE_kg
        eris = self.Eris_mass*self.MoE_kg

        total_mass = (self.MoS_kg+(mercury+venus+earth+mars+ceres+jupiter+saturn+uranus+neptune+pluto+eris+haumea+makemake+vesta+pallas+hygiea))

        summation_tranSun_vector_X = -(((mercury*vallues[0]['X_helio'])+(venus*vallues[1]['X_helio'])+(earth*vallues[2]['X_helio'])+(mars*vallues[3]['X_helio'])+(ceres*vallues[4]['X_helio'])+(jupiter*vallues[5]['X_helio'])+(saturn*vallues[6]['X_helio'])+(uranus*vallues[7]['X_helio'])+(neptune*vallues[8]['X_helio'])+(pluto*vallues[9]['X_helio'])+(eris*vallues[10]['X_helio']))/total_mass)

        summation_tranSun_vector_Y = -(((mercury*vallues[0]['Y_helio']
)+(venus*vallues[1]['Y_helio'])+(earth*vallues[2]['Y_helio'])+(mars*vallues[3]['Y_helio'])+(ceres*vallues[4]['Y_helio'])+(jupiter*vallues[5]['Y_helio'])+(saturn*vallues[6]['Y_helio'])+(uranus*vallues[7]['Y_helio'])+(neptune*vallues[8]['Y_helio'])+(pluto*vallues[9]['Y_helio'])+(eris+vallues[10]['Y_helio']))/total_mass)

        summation_tranSun_vector_Z = -(((mercury*vallues[0]['Z_helio']
)+(venus*vallues[1]['Z_helio'])+(earth*vallues[2]['Z_helio'])+(mars*vallues[3]['Z_helio'])+(ceres*vallues[4]['Z_helio'])+(jupiter*vallues[5]['Z_helio'])+(saturn*vallues[6]['Z_helio'])+(uranus*vallues[7]['Z_helio'])+(neptune*vallues[8]['Z_helio'])+(pluto*vallues[9]['Z_helio'])+(eris*vallues[10]['Z_helio']))/total_mass)


        return {'X_s':summation_tranSun_vector_X,'Y_s':summation_tranSun_vector_Y,'Z_s':summation_tranSun_vector_Z,'total_mass':total_mass,'Unix_time':vallues[10]['Unix_time'],'N':'Sun','desc':'GETS BARYCENTRIC SHIFT OF THE SUN IN REAL TIME USING s AND m.'} #used unix time for eris. because it is the last iteration in the loop

    def acce(self,name: str=None):
        '''gets the acceleration vectors for specific planet X'''
        name = name.upper() #name here is the target
        retu = self.barycentric(name) # thw real time xyz for trget planet

        values = ['SUN','MERCURY','VENUS','EARTH','MARS','VESTA','CERES','PALLAS','HYGIEA','JUPITER','SATURN','URANUS','NEPTUNE','PLUTO','HAUMEA','MAKEMAKE','ERIS']

        #index = 0 if name==values[0] else 1 if name==values[1] else 2 if name==values[2] else 3 if name==values[3] else 4 if name==values[4] else 5 if name==values[5] else 6 if name==values[6] else 7 if name==values[7] else 8 if name==values[8] else 9 if name==values[9] else 10 if name==values[10] else 11 if name==values[11] else 12 if name==values[12] else 13 if name==values[13] else 14 if name==values[14] else 15 if name==values[15] else 16 if name==values[16] else None

        vallues = [
                {'N':'SUN','u_mass':self.GM_S},
                {'N':'MERCURY','u_mass':(self.G*(self.Mercury_mass*self.MoE_kg))},
                {'N':'VENUS','u_mass':(self.G*(self.Venus_mass*self.MoE_kg))},
                {'N':'EARTH','u_mass':(self.G*self.MoE_kg)},
                {'N':'MARS','u_mass':(self.G*(self.Mars_mass*self.MoE_kg))},
                {'N':'VESTA','u_mass':(self.G*(self.Vesta_mass*self.MoE_kg))},
                {'N':'CERES','u_mass':(self.G*(self.Ceres_mass*self.MoE_kg))},
                {'N':'PALLAS','u_mass':(self.G*(self.Pallas_mass*self.MoE_kg))},
                {'N':'HYGIEA','u_mass':(self.G*(self.Hygiea_mass*self.MoE_kg))},
                {'N':'JUPITER','u_mass':(self.G*(self.Jupiter_mass*self.MoE_kg))},
                {'N':'SATURN','u_mass':(self.G*(self.Saturn_mass*self.MoE_kg))},
                {'N':'URANUS','u_mass':(self.G*(self.Uranus_mass*self.MoE_kg))},
                {'N':'NEPTUNE','u_mass':(self.G*(self.Neptune_mass*self.MoE_kg))},
                {'N':'PLUTO','u_mass':(self.G*(self.Pluto_mass*self.MoE_kg))},
                {'N':'HAUMEA','u_mass':(self.G*(self.Haumea_mass*self.MoE_kg))},
                {'N':'MAKEMAKE','u_mass':(self.G*(self.Makemake_mass*self.MoE_kg))},
                {'N':'ERIS','u_mass':(self.G*(self.Eris_mass*self.MoE_kg))}
                ]

        individual_pulls_X = [] #manually add suns pull to target planet for compatibility with previous code logic..handled it in the for loop
        individual_pulls_Y = []
        individual_pulls_Z = []


        if name: #the target
            for _,dictio in enumerate(vallues):
                if vallues[_]['N']==name:
                    continue
                if vallues[_]['N']==values[0]: #sun
                    r_chord_sun_3 = math.sqrt(math.pow((retu['sun_baryc_X']-retu['X_bary']),2) + math.pow((retu['sun_baryc_Y']-retu['Y_bary']),2) + math.pow((retu['sun_baryc_Z']-retu['Z_bary']),2))
                    r_chord_sun = math.pow(r_chord_sun_3,3)
                    relative_sun_X = retu['sun_baryc_X'] - retu['X_bary']
                    relative_sun_Y = retu['sun_baryc_Y'] - retu['Y_bary']
                    relative_sun_Z = retu['sun_baryc_Z'] - retu['Z_bary']
                    u_mass_sun = vallues[0]['u_mass']
                    pull_sun_X = ((u_mass_sun/r_chord_sun)*relative_sun_X)
                    pull_sun_Y = ((u_mass_sun/r_chord_sun)*relative_sun_Y)
                    pull_sun_Z = ((u_mass_sun/r_chord_sun)*relative_sun_Z)
                    individual_pulls_X.append(pull_sun_X)
                    individual_pulls_Y.append(pull_sun_Y)
                    individual_pulls_Z.append(pull_sun_Z)
                    continue

                retur = self.barycentric(vallues[_]['N']) #the puller
                r_chord_3 = math.sqrt(math.pow((retur['X_bary']-retu['X_bary']),2) + math.pow((retur['Y_bary']-retu['Y_bary']),2) + math.pow((retur['Z_bary']-retu['Z_bary']),2))
                r_chord = math.pow(r_chord_3,3)
                relative_r_X = retur['X_bary'] - retu['X_bary']
                relative_r_Y = retur['Y_bary'] - retu['Y_bary']
                relative_r_Z = retur['Z_bary'] - retu['Z_bary']
                u_mass = vallues[_]['u_mass']

                pull_X = ((u_mass/r_chord)*relative_r_X) #force factorprojected into the X_axis and so on....
                pull_Y = ((u_mass/r_chord)*relative_r_Y)
                pull_Z = ((u_mass/r_chord)*relative_r_Z)

                #individual_pulls_X.append(pull_sun_X)
                individual_pulls_X.append(pull_X)
                individual_pulls_Y.append(pull_Y)
                individual_pulls_Z.append(pull_Z)

            acceleration_a_X = sum(individual_pulls_X)#sum of all individual pulls on planet X
            acceleration_a_Y = sum(individual_pulls_Y)
            acceleration_a_Z = sum(individual_pulls_Z)

            return acceleration_a_X,acceleration_a_Y,acceleration_a_Z


    def barycentric(self,name: str=None):
        '''applies the barycentric shift to the heliocentric coordonates X,Y,Z of orbits fxn. it uses meters and seconds the SI units'''

        if name==None:
            console.print('[bold red]NAME CANT BE NONE/EMPTY[/bold red]')
            sys.exit(0)



        name = name.upper()

        #sun_barycentric = baryc_sun()

        if name:

            sun_barycentric = self.baryc_sun()
            r_sun_SSB = math.sqrt(math.pow(sun_barycentric['X_s'],2) + math.pow(sun_barycentric['Y_s'],2) + math.pow(sun_barycentric['Z_s'],2))
            u_total = super().u_total() #gravitational parameter--total mass * universal gravitation constant G
            #spec_uhelio = super().spec_uhelio(name)

            retu = super().orbits(name)
            #total_mass_u = (self.G*sun_barycentric['total_mass'])
            spec_uhelio = super().spec_uhelio(name)

            X_bary = retu['X_helio'] + sun_barycentric['X_s']
            Y_bary = retu['Y_helio'] + sun_barycentric['Y_s']
            Z_bary = retu['Z_helio'] + sun_barycentric['Z_s']

            r_bary = math.sqrt(math.pow(X_bary,2)+math.pow(Y_bary,2)+math.pow(Z_bary,2)) # relative to SSB
            r_helio = math.sqrt(math.pow(retu['X_helio'],2)+math.pow(retu['Y_helio'],2)+math.pow(retu['Z_helio'],2)) #relative to heliocentric sun.
            #v_bary = math.sqrt(total_mass_u * ((2/(r_bary))-(1/(retu['a'])))) # the vis-viva equation..cant use the vis vuva to get barycentric velocity..
            v_bary = math.sqrt(math.pow(retu['v_X'],2) + math.pow(retu['v_Y'],2) + math.pow(retu['v_Z'],2)) #the magnitude of the barycentric velocity vectors
            v_helio = math.sqrt(spec_uhelio * ((2/r_helio) - (1/retu['a']))) #heliocentric spee
            osculating_a = math.pow(((2/r_bary) - (math.pow(v_bary,2)/u_total)),-1) #live semi major axis a osculating element a...

            light_delay_sun_bary = r_bary/self.c_m_s
            light_delay_sun_helio = r_helio/self.c_m_s

            ##angular momentum and energy E##
            h_X = (Y_bary*retu['v_Z']) - (Z_bary*retu['v_Y']) #h SSB
            h_Y = (Z_bary*retu['v_X']) - (X_bary*retu['v_Z'])
            h_Z = (X_bary*retu['v_Y']) - (Y_bary*retu['v_X'])

            energy_bary = (math.pow(v_bary,2)/2) - (u_total/r_bary)
            h_bary = math.sqrt(math.pow(h_X,2) + math.pow(h_Y,2) + math.pow(h_Z,2))

            #e_X = 1/u_total*((v_bary**2-(u_total/r_bary))*(X_bary - ((X_bary*retu['v_X'])*retu['v_X'])))    #eccentric vector
            #e_Y = 1/u_total*((v_bary**2-(u_total/r_bary))*(Y_bary - ((Y_bary*retu['v_Y'])*retu['v_Y'])))
            #e_Z = 1/u_total*((v_bary**2-(u_total/r_bary))*(Z_bary - ((Z_bary*retu['v_Z'])*retu['v_Z'])))
            list_r = [X_bary,Y_bary,Z_bary]
            list_v = [retu['v_X'],retu['v_Y'],retu['v_Z']]
            vec = Vectors()
            dot_r_v = vec.dot_vect(list_r,list_v)

            e_X = 1/u_total*((math.pow(v_bary,2)-(u_total/r_bary))*X_bary - (dot_r_v*retu['v_X']))    #eccentric vector
            e_Y = 1/u_total*((math.pow(v_bary,2)-(u_total/r_bary))*Y_bary - (dot_r_v*retu['v_Y']))
            e_Z = 1/u_total*((math.pow(v_bary,2)-(u_total/r_bary))*Z_bary - (dot_r_v*retu['v_Z']))
            mgn_e = math.sqrt(math.pow(e_X,2) + math.pow(e_Y,2) + math.pow(e_Z,2))   #eccentric osculating element                          
            osc_i = math.degrees(math.acos(h_Z/h_bary)) % 360
            epsilon = 1e-8
            degr = '°'
            #vectors = Vectors()
            if mgn_e<epsilon and osc_i<epsilon:  #equitorial circular orbit
                q = 'equitorial circular orbit'
                Omega = 0
                argof_perihelion = 0
                true_longitude = math.degrees(math.atan2(Y_bary,X_bary)) % 360
                true_anomaly = true_longitude
                argof_latitude = 0
                longof_periapsis = 0

            elif osc_i<epsilon and epsilon<mgn_e<1:   #equitorial elliptical orbit

                q = 'equitorial elliptical orbits'
                Omega = 0
                argof_perihelion = 0
                longof_periapsis = math.degrees(math.atan2(e_Y,e_X)) % 360
                #argof_perihelion = longofperiapsis
                true_longitude = math.degrees(math.atan2(Y_bary,X_bary)) % 360 #L
                true_anomaly = true_longitude
                argof_latitude = 0

            elif osc_i>epsilon and mgn_e<epsilon: #tilted criscular orbit
                o = 'inclined circular orbit'
                list_k = [0,0,1]
                list_h = [h_X,h_Y,h_Z]
                #vectors = Vectors(0,0,1,h_X,h_Y,h_Z)
                cross_n_vect = vectors.cross_vect(list_k,list_h)
                list_n_vect = [cross_n_vect[0],cross_n_vect[1],cross_n_vect[2]]
                list_r_vect = [X_bary,Y_bary,Z_bary]
                magn_n_r = vectors.magn_vect(list_n_vect,list_r_vect)
                dot_n_r = vectors.dot_vect(list_n_vect,list_r_vect)
                Omega = math.degrees(math.acos(cross_n_vect[0]/cross_n_vect[3])) % 360                                                      
                if cross_n_vect[1]<0: #node_vector component y less than zero
                    Omega = 360 - Omega

                argof_perihelion = 0
                longof_periapsis = 0
                true_longitude = 0
                argof_latitude = math.degrees(math.acos(dot_n_r/magn_n_r[4])) % 360 #u
                true_anomaly = argof_latitude
                if Z<0: #u is greater than 180 degrees
                    argof_latitude = 360 - argof_latitude
                    true_anomaly = argof_latitude

            elif osc_i>epsilon and epsilon<mgn_e<1: #General inclined elliptical orbit
                x = 'General case. inclined elliptical orbit'         

                ##General case inclined elliptical orbits###

                #degr = '°'
                #node vector,longitude of ascending nide and argument of perihelion
                #list_angularmoment = [h_X,h_Y,h_Z]
                #list_normalized_k = [0,0,1]
                #vectors = Vectors(list_normalized_k,list_angularmoment)
                #cross = vectors.icross_vect()
                #if q:
                 #   print(q)
                  #  node_vectX = 0
                   # node_vectY = 0
                    #node_VectZ = 0

                #vectors = Vectors(0,0,1,h_X,h_Y,h_Z)
                list_k = [0,0,1]
                list_h = [h_X,h_Y,h_Z]
                cross_node_vect = vectors.cross_vect(list_k,list_h)
                argof_latitude = 0
                true_longitude = 0
                longof_periapsis = 0

                ##omega##
                node_vectX = cross_node_vect[0]
                node_vectY = cross_node_vect[1]
                node_vectZ = cross_node_vect[2]
                Omega = math.degrees(math.acos(node_vectX/cross_node_vect[3])) % 360
                if node_vectY<0: #
                    Omega = 360 - Omega

                ##argument kf perihelion###
                list_n = [node_vectX,node_vectY,node_vectZ]
                list_e = [e_X,e_Y,e_Z]

                dot_n_e = vectors.dot_vect(list_n,list_e)
                magn_n_e = vectors.magn_vect(list_n,list_e)

                argof_periapsis = math.degrees(math.acos(dot_n_e/magn_n_e[4])) % 360 #periapsis because barycentric else perihelion
                if e_Z<0: #the perihelion is below 180<perih<360
                    argof_periapsis = 360 - argof_periapsis

                ##true anomaly##
                list_r = [X_bary,Y_bary,Z_bary]
                dot_e_r = vectors.dot_vect(list_e,list_r)
                magn_e_r = vectors.magn_vect(list_e,list_r)
                true_anomaly = math.degrees(math.acos(dot_e_r/magn_e_r[4])) % 360
                list_v = [retu['v_X'],retu['v_Y'],retu['v_Z']]
                dot_r_v = vectors.dot_vect(list_r,list_v)
                if dot_r_v < 0: #object falling to perihelion
                    trv = 'climbing to aphelion'
                    true_anomaly = 360 - true_anomaly

                elif dot_r_v >= 0: #object climbing to aphelion
                    trv = 'falling to perihelion'


            if name!='EARTH':

                sun_barycentric = self.baryc_sun()
                
                X_E_bary = retu['X_E_helio'] + sun_barycentric['X_s']
                Y_E_bary = retu['Y_E_helio'] + sun_barycentric['Y_s']
                Z_E_bary = retu['Z_E_helio'] + sun_barycentric['Z_s']

                d_bary = math.sqrt(math.pow((X_bary-X_E_bary),2) + math.pow((Y_bary-Y_E_bary),2) + math.pow((Z_bary-Z_E_bary),2)) # relative to SSB
                d_helio = math.sqrt(math.pow((retu['X_helio']-retu['X_E_helio']),2) + math.pow((retu['Y_helio']-retu['Y_E_helio']),2) + math.pow((retu['Z_helio']-retu['Z_E_helio']),2)) # relative to heliocentric sun
                light_delay_bary = d_bary/self.c_m_s # light delay in seconds
                light_delay_helio = d_helio/self.c_m_s # light delay relative to heliocenter._
                return {'name':retu['N'],'X_helio':retu['X_helio'],'Y_helio':retu['Y_helio'],'Z_helio':retu['Z_helio'],'X_bary':X_bary,'Y_bary':Y_bary,'Z_bary':Z_bary,'X_E_bary':X_E_bary,'Y_E_bary':Y_E_bary,'Z_E_bary':Z_E_bary,'r_bary':r_bary,'v_bary':v_bary,'d_bary':d_bary,'light_delay_bary':light_delay_bary,'r_helio':r_helio,'v_helio':v_helio,'light_delay_helio':light_delay_helio,'light_delay_sun_bary':light_delay_sun_bary,'light_delay_sun_helio':light_delay_sun_helio,'d_helio':d_helio,'a':retu['a'],'b':retu['b'],'M':retu['M'],'E':retu['E'],'sun_baryc_X':sun_barycentric['X_s'],'sun_baryc_Y':sun_barycentric['Y_s'],'sun_baryc_Z':sun_barycentric['Z_s'],'r_sun_SSB':r_sun_SSB,'osc_a':osculating_a,'resp_day':retu['resp_day'],'v_X':retu['v_X'],'v_Y':retu['v_Y'],'v_Z':retu['v_Z'],'v_Xhelio':retu['v_Xhelio'],'v_Yhelio':retu['v_Yhelio'],'v_Zhelio':retu['v_Zhelio'],'h':h_bary,'h_X':h_X,'h_Y':h_Y,'h_Z':h_Z,'energy_bary':energy_bary,'energyhelio':retu['energy_helio'],'osc_i':osc_i,'e_X':e_X,'e_Y':e_Y,'e_Z':e_Z,'mgn_eccentricity':mgn_e,'Omega':Omega,'argof_periapsis':argof_periapsis,'true_anomaly':true_anomaly,'longof_periapsis':longof_periapsis,'argof_latitude':argof_latitude,'true_longitude':true_longitude,'osc_ihelio':retu['osc_i'],'mgn_eccentricityhelio':retu['mgn_eccentricity'],'Omegahelio':retu['Omega'],'osc_ahelio':retu['osc_a'],'argof_perihelion':retu['argumentof_perihelion'],'e_Xhelio':retu['e_X'],'e_Yhelio':retu['e_Y'],'e_Zhelio':retu['e_Z'],'true_anomalyhelio':retu['true_anomaly'],'longof_periapsishelio':retu['longof_periapsis'],'argof_latitudehelio':retu['argof_latitude'],'true_longitudehelio':retu['true_longitude'],'h_helio':retu['h'],'Unix_time':retu['Unix_time']}

            else: ##if name==earth  

                return {'name':retu['N'],'X_helio':retu['X_helio'],'Y_helio':retu['Y_helio'],'Z_helio':retu['Z_helio'],'X_bary':X_bary,'Y_bary':Y_bary,'Z_bary':Z_bary,'r_bary':r_bary,'v_bary':v_bary,'a':retu['a'],'b':retu['b'],'M':retu['M'],'E':retu['E'],'sun_baryc_X':sun_barycentric['X_s'],'sun_baryc_Y':sun_barycentric['Y_s'],'sun_baryc_Z':sun_barycentric['Z_s'],'r_helio':r_helio,'v_helio':v_helio,'light_delay_sun_bary':light_delay_sun_bary,'light_delay_sun_helio':light_delay_sun_helio,'r_sun_SSB':r_sun_SSB,'resp_day':retu['resp_day'],'osc_a':osculating_a,'v_X':retu['v_X'],'v_Y':retu['v_Y'],'v_Z':retu['v_Z'],'v_Xhelio':retu['v_Xhelio'],'v_Yhelio':retu['v_Yhelio'],'h':h_bary,'h_X':h_X,'h_Y':h_Y,'h_Z':h_Z,'energy_bary':energy_bary,'v_Zhelio':retu['v_Zhelio'],'osc_i':osc_i,'e_X':e_X,'e_Y':e_Y,'e_Z':e_Z,'mgn_eccentricity':mgn_e,'Omega':Omega,'argof_periapsis':argof_periapsis,'true_anomaly':true_anomaly,'longof_periapsis':longof_periapsis,'argof_latitude':argof_latitude,'true_longitude':true_longitude,'osc_ahelio':retu['osc_a'],'osc_ihelio':retu['osc_i'],'mgn_eccentricityhelio':retu['mgn_eccentricity'],'Omegahelio':retu['Omega'],'e_Xhelio':retu['e_X'],'e_Yhelio':retu['e_Y'],'e_Zhelio':retu['e_Z'],'argof_perihelion':retu['argumentof_perihelion'],'true_anomalyhelio':retu['true_anomaly'],'longof_periapsishelio':retu['longof_periapsis'],'argof_latitudehelio':retu['argof_latitude'],'true_longitudehelio':retu['true_longitude'],'energyhelio':retu['energy_helio'],'h_helio':retu['h'],'Unix_time':retu['Unix_time']}



 #   def baryc_sun_daus(self):
  #      '''calculates the barycentric shift of the sun using AU'''
   #     name = name.upper()
#
 #       if name==None:
  #          console.print('[bold red]NAME CANNOT BE NONE/EMPTY[/bold red]')
   #         sys.exit(0)

    #    values = ['JUPITER','SATURN','URANUS','NEPTUNE']
#
 #       #vallues = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'CERES':1681,'JUPITER':4333,'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174}
  #      vallues = []
#
 #       
#
 #       for _ in values:
  #         vallues.append(super().orbits(_)) # orbits returns the real mean anomaly
#
 #       day_J = (vallues[0]['M']/(2*math.pi))*self.Jupiter_P*self.earthperiod_d
  #      day_S = (vallues[1]['M']/(2*math.pi))*self.Saturn_P*self.earthperiod_d
   #     day_U = (vallues[2]['M']/(2*math.pi))*self.Uranus_P*self.earthperiod_d
    #    day_N = (vallues[3]['M']/(2*math.pi))*self.Neptune_P*self.earthperiod_d
#
 #       retu = self.baryc_sun() # only to get the mass
  #      mass = retu['total_mass'] #jsun
#
#


        #X_sun_bary = (retu['X_s']/self.AU_m)
        #Y_sun_bary = (retu['Y_s']/self.AU_m)
        #Z_sun_bary = (retu['Z_s']/self.AU_m)
#
        
 #       return {'X_saun':X_sun_bary,'Y_saun':Y_sun_bary,'Z_saun':Z_sun_bary,'Unix_time':retu['Unix_time'],'N':'Sun','desc':'GETS THE BARYCENTRIC SHIFT OF THE SUN IN REAL TIME BUT USING AU.'}
#
#

    def full_list_bary(self,name: str=None):
        '''gets full list of the XYZ barycentric coordinates of celestial objecte using seconds'''
        ##full coordinates imolemented in astlo module..just for testing logic##


        #name = name.upper()
        

        values = ['MERCURY','VENUS','EARTH','MARS','VESTA','CERES','PALLAS','HYGIEA','JUPITER','SATURN','URANUS','NEPTUNE','PLUTO','HAUMEA','MAKEMAKE','ERIS']

        if name==None:
            console.print('[bold red]NAME CANNOT BE NONE/EMPTY[/bold red]')
            sys.exit(0)

        name = name.upper()

        retu = super().orbits(name,1) # fcdts is activated

        return retu ##### continue







    def stumpff(self,z):
        #gets the cosine and sine like energies.##
        #z = max(z,-100.0)   #Never let z go below -100
        fact_2 = math.factorial(2)
        fact_3 = math.factorial(3)
        fact_4 = math.factorial(4)
        fact_5 = math.factorial(5)
        fact_6 = math.factorial(6)
        fact_7 = math.factorial(7)
        fact_8 = math.factorial(8)
        fact_9 = math.factorial(9)
        fact_10 = math.factorial(10)
        fact_11 = math.factorial(11)
        fact_12 = math.factorial(12)
        fact_13 = math.factorial(13)
        fact_14 = math.factorial(14)
        fact_15 = math.factorial(15)
        fact_16 = math.factorial(16)
        fact_17 = math.factorial(17)
        fact_18 = math.factorial(18)
        fact_19 = math.factorial(19)
        fact_20 = math.factorial(20)
        fact_21 = math.factorial(21)


        if 0<=z<1e-5: #parabolic path ::near zero..
            C_z = 1/fact_2
            S_z = 1/fact_3
            #C_z = (1.0/6.0) - (z/120.0) + (z**2/5040.0) - (z**3/362880.0) + (z**4/39916800)
            #S_z = ((1.0/6.0) - (z/120.0) + (z**2/5040.0) - (z**3/362880.0) + (z**4/39916800))*(1.0/7.0)
        #elif 0<z<1e-5:
         #   C_z = 1/fact_2
          #  S_z = 1/fact_3

        if z > 0 and z > 1e-5: #elliptical path
           C_z =  ((1/fact_2) - (z/fact_4) + (math.pow(z,2)/fact_6) - (math.pow(z,3)/fact_8) + (math.pow(z,4)/fact_10) - (math.pow(z,5)/fact_12) + (math.pow(z,6)/fact_14) - (math.pow(z,7)/fact_16) + (math.pow(z,8)/fact_18) - (math.pow(z,9)/fact_20))
           S_z = ((1/fact_3) - (z/fact_5) + (math.pow(z,2)/fact_7) - (math.pow(z,3)/fact_9) + (math.pow(z,4)/fact_11) - (math.pow(z,5)/fact_13) + (math.pow(z,6)/fact_15) - (math.pow(z,7)/fact_17) + (math.pow(z,8)/fact_19) - (math.pow(z,9)/fact_21))
            #sz = math.sqrt(z)
            #C_z = (1 - math.cos(sz))/z
            #S_z = ((sz - math.sin(sz))/(math.pow(sz,3)))

        #if z == 0 or abs(z) < 1e-8: #parabolic path ::near zero..
            #C_z = 1/2 1/6?
            #S_z = 1/6
            #C_z = (1.0/6.0) - (z/120.0) + (z**2/5040.0) - (z**3/362880.0) + (z**4/39916800)
            #S_z = ((1.0/6.0) - (z/120.0) + (z**2/5040.0) - (z**3/362880.0) + (z**4/39916800))*(1.0/7.0)

        if z < 0: # hyperbolic path <0
            C_z =  ((1/fact_2) + (z/fact_4) + (math.pow(z,2)/fact_6) + (math.pow(z,3)/fact_8) + (math.pow(z,4)/fact_10) + (math.pow(z,5)/fact_12) + (math.pow(z,6)/fact_14) + (math.pow(z,7)/fact_16) + (math.pow(z,8)/fact_18) + (math.pow(z,9)/fact_20))
            S_z = ((1/fact_3) + (z/fact_5) + (math.pow(z,2)/fact_7) + (math.pow(z,3)/fact_9) + (math.pow(z,4)/fact_11) + (math.pow(z,5)/fact_13) + (math.pow(z,6)/fact_15) + (math.pow(z,7)/fact_17) + (math.pow(z,8)/fact_19) + (math.pow(z,9)/fact_21))
            #sz = math.sqrt(-z)
            #C_z = ((math.cosh(sz) - 1.0)/(-z)) #cosh returns the inverse hyperbolic cosine of sz
            #S_z = ((math.sinh(sz) - sz)/(math.pow(sz,3)))  #sinh the inverse hyperbolic sine of sz

        
            
        return {'C_z':C_z,'S_z':S_z}




    def deriv_stumpff(self,z):
        '''the derivatives for the stumpff series'''



       # fact_2 = math.factorial(2)
        #fact_3 = math.factorial(3)
      #  fact_4 = math.factorial(4)
    #    fact_5 = math.factorial(5)
     #   fact_6 = math.factorial(6)
        #fact_7 = math.factorial(7)
       # fact_8 = math.factorial(8)
        #fact_9 = math.factorial(9)
      #  fact_10 = math.factorial(10)
        #fact_11 = math.factorial(11)
     #   fact_12 = math.factorial(12)
        #fact_13 = math.factorial(13)
    #    fact_14 = math.factorial(14)
        #fact_15 = math.factorial(15)
       # fact_16 = math.factorial(16)
        #fact_17 = math.factorial(17)
      #  fact_18 = math.factorial(18)
        #fact_19 = math.factorial(19)
        #fact_20 = math.factorial(20)
        #fact_21 = math.factorial(21)

        if 0<=z<1e-5:
            C_z = -(1/24)
            S_z = -(1/120)

        else:
            C = self.stumpff(z)
            S = self.stumpff(z)
            C_z = (1/(2*z))*(S['S_z']-(2*C['C_z']))
            S_z = (1/(2*z))*(C['C_z']-(3*S['S_z']))

        #elif 0<z<1e-5:
         #   C_z = -(1/24)
          #  S_z = -(1/120)




       # if z>0 and z>1e-5:
            #C_z = (-(1/24) + (z/360) - (math.pow(z,2)/13440) + (math.pow(z,3)/907200) - (math.pow(z,4)/95800320) + (math.pow(z,5)/14529715200) - (math.pow(z,6)/2988969984000) + (math.pow(z,7)/800296713216000) - (math.pow(z,8)/270322445352960000) + (math.pow(z,9)/112400072777760768000))
            #S_z = (-(1/120) + (z/2520) - (math.pow(z,2)/120960) + (math.pow(z,3)/9979200) - (math.pow(z,4)/1245404160) + (math.pow(z,5)/217945728000) - (math.pow(z,6)/50812489728000) + (math.pow(z,7)/15205637551104000) - (math.pow(z,8)/5676771352412160000) + (math.pow(z,9)/2585201673888497664000))


     #   if z<0:
      #      C_z = (-(1/24) + (z/360) - (math.pow(z,2)/13440) + (math.pow(z,3)/907200) - (math.pow(z,4)/95800320) + (math.pow(z,5)/14529715200) - (math.pow(z,6)/2988969984000) + (math.pow(z,7)/800296713216000) - (math.pow(z,8)/270322445352960000) + (math.pow(z,9)/112400072777760768000))
       #     S_z = (-(1/120) + (z/2520) - (math.pow(z,2)/120960) + (math.pow(z,3)/9979200) - (math.pow(z,4)/1245404160) + (math.pow(z,5)/217945728000) - (math.pow(z,6)/50812489728000) + (math.pow(z,7)/15205637551104000) - (math.pow(z,8)/5676771352412160000) + (math.pow(z,9)/2585201673888497664000))


        return {'der_C':C_z,'der_S':S_z}






    def future(self,objname: str=None,days: int=None,real=None):
        '''gets the future coordinates for planet X after time t'''

        #seconds = (days*24*60*60)
        #time_now=time.time()
        #delta_t  = time_now + seconds   #the change in days since now the epoch and the last das
        #objname = objname.upper()

        ##LAMBERTS IS HELIOCENTRIC###

        if objname==None and days==None:
            console.print('[bold red]NAME AND DAYS ADDED/SUBTRACTED CANT BE NONE[/bold red]')
            sys.exit()

        objname = objname.upper()

        retu = super().orbits(objname,None,days) # if it can get the positive value, the  it can also get the negative value
        baryc = self.baryc_sun()
        #total_mass_u = self.G*baryc['total_mass']
        u_total = super().u_total()
        spec_uhelio = super().spec_uhelio(objname)  #use suns paramter

        X_bary = retu['X_helio'] + baryc['X_s']
        Y_bary = retu['Y_helio'] + baryc['Y_s']
        Z_bary = retu['Z_helio'] + baryc['Z_s']


        r_bary = math.sqrt(math.pow(X_bary,2) + math.pow(Y_bary,2) + math.pow(Z_bary,2))
        r_helio = math.sqrt(math.pow(retu['X_helio'],2) + math.pow(retu['Y_helio'],2) + math.pow(retu['Z_helio'],2))

        #v_bary = math.sqrt(total_mass_u * ((2/(r_bary))-(1/(retu['a']))))
        v_bary = math.sqrt(math.pow(retu['v_X'],2) + math.pow(retu['v_Y'],2) + math.pow(retu['v_Z'],2))
        v_helio = math.sqrt(spec_uhelio * ((2/r_helio)-(1/retu['a'])))
        osculating_a = math.pow(((2/r_bary) - (math.pow(v_bary,2)/u_total)),-1)


        light_delay_sun_bary = r_bary/self.c_m_s
        light_delay_sun_helio = r_helio/self.c_m_s

        ##HELIOCENTRIC FOR NOW## the real osc elements



        if real: ##rotating the raw perifocal with real osculating elements
            omecos = math.cos(math.radians(retu['Omega'])) # the longtude of ascending node/Omega
            omesin = math.sin(math.radians(retu['Omega']))
            wsin = math.sin(math.radians(retu['argumentof_perihelion']))
            wcos = math.cos(math.radians(retu['argumentof_perihelion']))
            isin = math.sin(math.radians(retu['osc_i']))
            icos = math.cos(math.radians(retu['osc_i']))

            X_real = (retu['x_pfcal'] * ((omecos*wcos) - (omesin*wsin*icos))) - (retu['y_pfcal'] * ((omecos*wsin) + (omesin*wcos*icos)))
            Y_real = (retu['x_pfcal'] * (omesin*wcos + (omecos*wsin*icos))) + (retu['y_pfcal'] * ((omecos*wcos*icos) - (omesin*wsin)))
            Z_real = (retu['x_pfcal'] * (wsin*isin)) + (retu['y_pfcal'] * (wcos*isin))

            l_t = [X_real,Y_real,Z_real]

            magn_rhel = vectors.magn_vect(l_t)


            return {'X_bary':X_bary,'Y_bary':Y_bary,'Z_bary':Z_bary,'Unix_time':retu['Unix_time'],'X_helio':retu['X_helio'],'Y_helio':retu['Y_helio'],'Z_helio':retu['Z_helio'],'daysaddsub':retu['daysaddsub'],'r_bary':r_bary,'v_bary':v_bary,'v_helio':v_helio,'r_helio':r_helio,'light_delay_sun_bary':light_delay_sun_bary,'light_delay_sun_helio':light_delay_sun_helio,'osc_a':osculating_a,'v_X':retu['v_X'],'v_Y':retu['v_Y'],'v_Z':retu['v_Z'],'v_Xhelio':retu['v_Xhelio'],'v_Yhelio':retu['v_Yhelio'],'v_Zhelio':retu['v_Zhelio'],'X_helioreal':X_real,'Y_helioreal':Y_real,'Z_helioreal':Z_real,'magnhel_rl':magn_rhel,'desc':'gives the coordinates for planet X after time t'}


            

        return {'X_bary':X_bary,'Y_bary':Y_bary,'Z_bary':Z_bary,'Unix_time':retu['Unix_time'],'X_helio':retu['X_helio'],'Y_helio':retu['Y_helio'],'Z_helio':retu['Z_helio'],'daysaddsub':retu['daysaddsub'],'r_bary':r_bary,'v_bary':v_bary,'v_helio':v_helio,'r_helio':r_helio,'light_delay_sun_bary':light_delay_sun_bary,'light_delay_sun_helio':light_delay_sun_helio,'osc_a':osculating_a,'v_X':retu['v_X'],'v_Y':retu['v_Y'],'v_Z':retu['v_Z'],'v_Xhelio':retu['v_Xhelio'],'v_Yhelio':retu['v_Yhelio'],'v_Zhelio':retu['v_Zhelio'],'desc':'gives the coordinates for planet X after time t'} #static osculating elements


    def hohmann(self,name: str=None):
        '''the hohmann way for the transfer orbit'''
        ##For a perfect hohmann transfer, the phase angle upon arrival sho7ld be exactly 180°##
        name = name.upper()
        obj = ['earth','venus']
        retu = []

        for n in obj:
            retu.append(self.barycentric(n))
            pass
        pass












    def ldiscontinued(self,name: str=None,days: int=None,longway=None):
        '''launch simulations. Lamberts problem'''
        ##TRIED IT A COUPE OF TIMES. BOTH BISWCTION AND NEWTON RAPHSON WAY..SOMETHING BREAKS THE LOGIC##
        #TRYING HOFFMAN TRANSFER NEXT##

        #name = name.upper()

        if name==None:
            console.print('[bold red]NAME CANNOT BE NONE[/bold red]')
            sys.exit(0)


        name = name.upper()

        #start = time.perf_counter()

        retu = self.barycentric('EARTH') # earth XYZ coord now.
        retur = self.future(name,days) #future coordinates for choosen planet
        delta_t = days*24*60*60

        ##scalar constants##
        r_earth = retu['r_helio']
        #r_X = math.sqrt(math.pow(fut_coord['X_bary'],2) + math.pow(fut_coord['Y_helio'],2) + math.pow(fut_coord['Z_bary'],2))
        r_X = retur['r_helio']

        chord = math.sqrt(math.pow((retur['X_helio']-retu['X_helio']),2) + math.pow((retur['Y_helio']-retu['Y_helio']),2) + math.pow((retur['Z_helio']-retu['Z_helio']),2)) #the staright line distance btwn earth and future coord for planet ? eaucladian distance
        s = (r_earth + r_X + chord)/2 #semi perimeter s

        #Transfer angle v#
        #delta_theta_raw = math.acos(((retur['X_helio']*retu['X_helio']) + (retur['Y_helio']*retu['Y_helio']) + (retur['Z_helio']*retu['Z_helio']))/(retu['r_helio']*retur['r_helio']))# not needed
   #     z_comp = ((retu['X_helio']*retur['Y_helio']) - (retu['Y_helio']*retur['X_helio'])) #not need3d

  #      shrtway = 1 if z_comp >= 0 else None#if z comp of cross prod is positive/0 then shortway
 #       lngway = 2 if z_comp < 0 else None# if z comp is n3gative then long way
#
      #  if delta_theta_raw > math.pi:
     #      delta_theta_raw = (math.pi*2) - delta_theta_raw #default is the short way


        #if longway: #only use if required
         #   if delta_theta_raw > math.pi:
          #      delta_theta_raw = delta_theta_raw
           # else:
            #    delta_theta_raw = (math.pi*2) - delta_theta_raw
            

        #signum = 1 if delta_theta_raw < math.pi else -1 if delta_theta_raw > math.pi else print('Error: sin(delta theta raw) is zero.') if math.sin(delta_theta_raw)==0 else None

        #A = signum*math.sin(delta_theta_raw)*(math.sqrt(retu['r_helio']*retur['r_helio'] * (1 + math.cos(delta_theta_raw))))  #geometric anchor A
        A = math.sqrt(s*(s - retu['r_helio'])*(s - retur['r_helio'])*(s - chord))
        z_low = 0.0
        z_high = 20.0 #intial guess for energy z
        check = 5.0
        chck = 0 
        while True:
            ##stumpff fucntion C,S##
            #C_z = ((1/2) - (z/24) + (math.pow(z,2)/720) - (math.pow(z,3)/40320) + (math.pow(z,4)/3628800) - (math.pow(z,5)/479001600) + (math.pow(z,6)/87178291200) - (math.pow(z,7)/20922789888000) + (math.pow(z,8)/6402373705728000) - (math.pow(z,9)/2432902008176640000))  #cosine like function for the first 10 terms
            #S_z = ((1/3) - (z/120) + (math.pow(z,2)/5040) - (math.pow(z,3)/362880) + (math.pow(z,4)/39916800) - (math.pow(z,5)/6227020800) + (math.pow(z,6)/1307674368000) - (math.pow(z,7)/355687428096000) + (math.pow(z,8)/121645100408832000) - (math.pow(z,9)/51090942171709440000))  #sine like function for first 10 terms
            #z = (z_low + z_high)/2
            z = 2.0
            rew = self.stumpff_(z)
            #if rew['C_z'] <= 0:
             #   rew['C_z'] = 1e-8
            y_z = (retu['r_helio'] + retur['r_helio']) + (A*((z*rew['S_z'] - 1)/math.sqrt(rew['C_z']))) #Gemometry bridge
            #print('y_z_new: ',y_z)

            #if y_z < 0:
            if y_z < 0: #if y is negative then unphysical
                #z_low = z # basically increased z to try and make y positive.
                z = 2
                #z += max(0.1, (0.05 * abs(y_z) / 1e11))   #(-y_z)*0.5
                #rew = self.stumpff_(z)
                #y_z = (retu['r_helio'] + retur['r_helio']) + (A*((z*rew['S_z'] - 1)/math.sqrt(rew['C_z'])))
                continue

            X_ = math.sqrt(y_z/rew['C_z']) #universal anomaly chi
            tof = ((math.pow(X_,3)*rew['C_z']) + (A*X_))/math.sqrt(self.GM_S) #should use specuhelio
            error_f = tof - delta_t
            

            #error_f = (math.pow((y_z/rew['C_z']),1.5) * rew['S_z'])+((A*math.sqrt(y_z)) - (math.sqrt(self.GM_S)*delta_t)) #error function equation
            #print('error f: ',error_f)

            #if z==0 or abs(z) < 1e-12: #the floor derivative if z=0 to prevent division by zero error

                #derivative_f = ((math.sqrt(2)/40)*math.pow(y_z,1.5)) + ((A/8)*(math.sqrt(y_z)+(A*(math.sqrt(1/(2*y_z))))))
             #   derivative_f = ((math.pow(X_,2)*rew['C_z']) + A)/math.sqrt(self.GM_S)

                #newton raphson loop#
                #z = z - (error_f/derivative_f) #used a damp of 0.5i
                #print('z_new when z==0 floor deriv: ',z)
                #print('floor deriv: ',derivative_f)
                #continue

            #else:
                #derivative_f = math.pow((y_z/rew['C_z']),1.5) * (((1/(2*z))*(rew['C_z'] - ((3*rew['S_z'])/(2*rew['C_z'])))) + (math.pow((3*rew['S_z']),2)/(4*rew['C_z']))) + ((A/8)*((3*(rew['S_z']/rew['C_z'])*math.sqrt(y_z)) + (A*(math.sqrt(rew['C_z']/y_z)))))
             #   derivative_f = ((math.pow(X_,2)*rew['C_z']) + (X_*(1 - (z*rew['S_z']))) + A)/math.sqrt(self.GM_S)

                #z = z - ((error_f/derivative_f)) #*0.5 to take small steps
                #print('z_new when z!=0: ',z)
                #print('floor deriv: ',derivative_f)
                #continue

            if abs(error_f) < check:
                break

            if error_f > 0: #if tof is > delta_t or if tof == delta_t then = 0 ..tof-delta_t=0..curent z gives too much time
                #z_high = z
                z = 2.0
            if error_f < 0: #current z gives too less time..of course only if the break statement isnt reached.
                #z_low = z
                z = 2.0

           # z = z - (1e-6*(error_f/derivative_f))
            #chck += 1
            print(f'S_z={rew['S_z']} C_z={rew['C_z']} y_z={y_z} z_mid={z} error={error_f} tof={tof}')


        ##delta v ## THE LAGRANGE COEFFICIENTs
        f = (1 - (y_z/retu['r_helio']))
        g = delta_t - ((math.pow(X_,3)*rew['C_z']) + (A*X_))/math.sqrt(self.GM_S)    #A*math.sqrt(y_z/self.GM_S)
        #f_d = (math.sqrt(self.GM_S*y_z)/(retu['r_helio']*retur['r_helio']))*(((math.pow(z,3)*A) - (y_z*math.sqrt(z)))/y_z) ##lagrange derivative coefficients##
        g_d = (1 - (y_z/retur['r_helio'])) ##lagrange deriavtive coeffiec8ents

        ##initial velocity vectors for start of transfer orbit##
        v_transf_X = (retur['X_bary'] - (f*retu['X_bary']))/g
        v_transf_Y = (retur['Y_bary'] - (f*retu['Y_bary']))/g
        v_transf_Z = (retur['Z_bary'] - (f*retu['Z_bary']))/g
        v_transf_Xhelio = (retur['X_helio'] - (f*retu['X_helio']))/g
        v_transf_Yhelio = (retur['Y_helio'] - (f*retu['Y_helio']))/g
        v_transf_Zhelio = (retur['Z_helio'] - (f*retu['Z_helio']))/g

        ##final velocity vectors for arrival/end of transfer orbit##
        v2_transf_Xhelio = ((g_d*retur['X_helio']) - retu['r_helio'])/g
        v2_transf_Yhelio = ((g_d*retur['Y_helio']) - retu['r_helio'])/g
        v2_transf_Zhelio = ((g_d*retur['Z_helio']) - retu['r_helio'])/g
        v2_transf_X = ((g_d*retur['X_bary']) - retu['r_bary'])/g
        v2_transf_Y = ((g_d*retur['Y_bary']) - retu['r_bary'])/g
        v2_transf_Z = ((g_d*retur['Z_bary']) - retu['r_bary'])/g

        delta_v_1 = math.sqrt((math.pow((v_transf_Xhelio - retu['v_Xhelio']),2)) + (math.pow((v_transf_Yhelio - retu['v_Yhelio']),2)) + (math.pow((v_transf_Zhelio - retu['v_Zhelio']),2))) #how much kick to give the rocket as it leaves earths sphere of influence to reach object X

        delta_v_2 = math.sqrt((math.pow((retur['v_Xhelio'] - v2_transf_Xhelio),2)) + (math.pow((retur['v_Yhelio'] - v2_transf_Yhelio),2)) + (math.pow((retur['v_Zhelio'] - v2_transf_Zhelio),2))) #you have to match venus orbital velocity to stay there with it....continue

        total_delta_v = delta_v_1 + delta_v_2
        #stop = (time.perf_counter()-start)/60
        

        return  'ERROR..DISCONTINUED'  #total_delta_v,delta_v_2,delta_v_1






    def reel(self,name: str=None,bary=None,single_vector=None): #default is heliocentric..ret for returning if needed..bjt this method is onyl for returning sonwhemyou wake up.....
        '''gets the real rotated valies using the real time osculating elements. both heliocentric frame and barycentric.'''
        if name==None:
            console.print('[bold red]NAME CANNOT BE NONE/EMPTY[/bold red]')
            return # instead of sys.exit(0) which might cause frustrations to the user in the python IDE.

        name = name.upper()


        vallues = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'CERES':1681,'JUPITER':4333,'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174}


        rl = super().orbit(0,int(vallues.get(name,-2)),None,'y')
        osc_elem = self.barycentric(name)

        if bary: #barycentric osculating elements
            #X_l = [] # orbit returns AU
            #Y_l = []
            #Z_l = []
            X_AUl = []
            Y_AUl = []
            Z_AUl = []

            omecos = math.cos(math.radians(osc_elem['Omega'])) # the longtude of ascending node/Omega
            omesin = math.sin(math.radians(osc_elem['Omega']))
            wsin = math.sin(math.radians(osc_elem['argof_periapsis']))
            wcos = math.cos(math.radians(osc_elem['argof_periapsis']))
            isin = math.sin(math.radians(osc_elem['osc_i']))
            icos = math.cos(math.radians(osc_elem['osc_i']))

            #if single_vector:
             #   perirot = super().orbits(name) #now sinhle vector math availabpe gor heliocentric and berycentrc🦋



            for _,idx in enumerate(rl['x_list_peri']):
                X = (idx * ((omecos*wcos) - (omesin*wsin*icos))) - (rl['y_list_peri'][_] * ((omecos*wsin) + (omesin*wcos*icos)))
                Y = (idx * (omesin*wcos + (omecos*wsin*icos))) + (rl['y_list_peri'][_] * ((omecos*wcos*icos) - (omesin*wsin)))
                Z = (idx * (wsin*isin)) + (rl['y_list_peri'][_] * (wcos*isin))
                X_AUl.append(X)
                Y_AUl.append(Y)
                Z_AUl.append(Z)



            if single_vector:
                perirot = super().orbits(name)


                X_s = (perirot['x_pfcal'] * ((omecos*wcos) - (omesin*wsin*icos))) - (perirot['y_pfcal'] * ((omecos*wsin) + (omesin*wcos*icos)))
                Y_s = (perirot['x_pfcal'] * (omesin*wcos + (omecos*wsin*icos))) + (perirot['y_pfcal'] * ((omecos*wcos*icos) - (omesin*wsin)))
                Z_s = (perirot['x_pfcal'] * (wsin*isin)) + (perirot['y_pfcal'] * (wcos*isin))  #the rotated elements are realtive the barycenter..
                l_t = [X_s,Y_s,Z_s]
                magn_rbary = vectors.magn_vect(l_t)


                return {'X_AUl':X_AUl,'Y_AUl':Y_AUl,'Z_AUl':Z_AUl,'X_baryreal':X_s,'Y_baryreal':Y_s,'Z_baryreal':Z_s,'magnbary_rl':magn_rbary}




            return {'X_AUl':X_AUl,'Y_AUl':Y_AUl,'Z_AUl':Z_AUl} #barycentric rotated valeus



        #X_heliom = []
        #Y_heliom = []
        #Z_heliom = []
        X_helioAU = []
        Y_helioAU = []
        Z_helioAU = []

        omecos = math.cos(math.radians(osc_elem['Omegahelio'])) # the longtude of ascending node/Omega
        omesin = math.sin(math.radians(osc_elem['Omegahelio']))
        wsin = math.sin(math.radians(osc_elem['argof_perihelion']))
        wcos = math.cos(math.radians(osc_elem['argof_perihelion']))
        isin = math.sin(math.radians(osc_elem['osc_ihelio']))
        icos = math.cos(math.radians(osc_elem['osc_ihelio']))

       # if single_vec:
        #    perirot = super().orbits(name)


        for _,idx in enumerate(rl['x_list_peri']):
            X = (idx * ((omecos*wcos) - (omesin*wsin*icos))) - (rl['y_list_peri'][_] * ((omecos*wsin) + (omesin*wcos*icos)))
            Y = (idx * (omesin*wcos + (omecos*wsin*icos))) + (rl['y_list_peri'][_] * ((omecos*wcos*icos) - (omesin*wsin)))
            Z = (idx * (wsin*isin)) + (rl['y_list_peri'][_] * (wcos*isin))
            X_helioAU.append(X)
            Y_helioAU.append(Y)
            Z_helioAU.append(Z)

        #for _,idx in enumerate(X_heliom):

         #   X_AU = idx/self.AU_m
          #  Y_AU = Y_heliom[_]/self.AU_m
           # Z_AU = Z_heliom[_]/self.AU_m

            #X_helioAU.append(X_AU)
           # Y_helioAU.append(Y_AU)
           # Z_helioAU.append(Z_AU)

        if single_vector:
            perirot = super().orbits(name)

            X_s = (perirot['x_pfcal'] * ((omecos*wcos) - (omesin*wsin*icos))) - (perirot['y_pfcal'] * ((omecos*wsin) + (omesin*wcos*icos)))
            Y_s = (perirot['x_pfcal'] * (omesin*wcos + (omecos*wsin*icos))) + (perirot['y_pfcal'] * ((omecos*wcos*icos) - (omesin*wsin)))
            Z_s = (perirot['x_pfcal'] * (wsin*isin)) + (perirot['y_pfcal'] * (wcos*isin)) #osc elemts relative heliocenter

            l_t = [X_s,Y_s,Z_s]
            magn_rhelio = vectors.magn_vect(l_t)

            return {'X_helioAU':X_helioAU,'Y_helioAU':Y_helioAU,'Z_helioAU':Z_helioAU,'X_helioreal':X_s,'Y_helioreal':Y_s,'Z_helioreal':Z_s,'magnhel_rl':magn_rhelio}



        return {'X_helioAU':X_helioAU,'Y_helioAU':Y_helioAU,'Z_helioAU':Z_helioAU}






    def lamberts(self,name: str=None,days: int=None):
        '''Lamberts problem. assumes Heliocentric frame.'''

        if name==None: #name is the target or destination
            console.print('[bold red]NAME CANNOT BE NONE. TARGET/DESTINATION[/bold red]')
            return

        name = name.upper()

        values = ['MERCURY','VENUS','EARTH','MARS','VESTA','CERES','PALLAS','HYGIEA','JUPITER','SATURN','URANUS','NEPTUNE','PLUTO','HAUMEA','MAKEMAKE','ERIS']

        if name not in values:
            console.print('[bold red]NAME NOT LOCALLY RECOGNIZED OR WRONG SPELLING[/bold red]')
            return

        ##position vectora using thebreal osc elelmts##

        retu = self.reel('EARTH',None,'y') ## last parameter is the rotated using osc elem for earth
        retur = self.future(name,days,'y') #target planet and delta t and real param for future coord
        delta_t = days*24*60*60

        mgn_mult = vectors.magn_vect([retu['X_helioreal'],retu['Y_helioreal'],retu['Z_helioreal']], [retur['X_helioreal'],retur['Y_helioreal'],retur['Z_helioreal']])


        delta_theta = math.acos((vectors.dot_vect([retu['X_helioreal'],retu['Y_helioreal'],retu['Z_helioreal']], [retur['X_helioreal'],retur['Y_helioreal'],retur['Z_helioreal']]))/mgn_mult[4]) #arccos always returns btwn 0 and pi 
        delta_theta_raw = math.degrees(delta_theta)

        ##cross product to check if Z comp is positive
        cross_Z = vectors.cross_vect([retu['X_helioreal'],retu['Y_helioreal'],retu['Z_helioreal']], [retur['X_helioreal'],retur['Y_helioreal'],retur['Z_helioreal']])

        if cross_Z[2]>=0: #short way
            delta_theta_raw_ = delta_theta_raw

        elif cross_Z[2]<0: #long way
            delta_theta_raw_ = 360 - delta_theta_raw
            console.print('[bold magenta]Craft going long way[/bold magenta]')

        delta_th = math.radians(delta_theta_raw_)


        A = math.sin(delta_th)*math.sqrt(mgn_mult[4]/(1 - math.cos(delta_th))) #The Geometric if delta theta is less pi then A will be positive because of the sin fxn and negative if delta theta if >pi
        print('A Geometric: ',A)
        z = 0 #first guess


        while 0<=z<1e-5:
            #l = (math.sqrt(2)/40)*math.pow(y,1.5)

            y = mgn_mult[2] - (A*math.sqrt(2))
            slope_y = (math.sqrt(2)/2)*((mgn_mult[2]/5) + (A/2))
            chi = math.sqrt((2*y)) #X rep the change in generalized eccentric anomaly
            change_chi_to_z = (1/(2*chi))*((2*y) + (y/6)) #not needed here
            t_calc = (1/math.sqrt(self.GM_S))*(((1/6)*math.pow(chi,3))+(A*math.sqrt(y)))
            error_f = t_calc - delta_t
            l = (math.sqrt(2)/40)*math.pow(y,1.5)
            w = A*(math.sqrt(1/(2*y)))
            slope_f = (1/math.sqrt(self.GM_S))*(l + ((A/8)*(math.sqrt(y)+w)))
            z = z - (error_f/slope_f)

        console.print('[bold magenta]Exited z=0 and continuing..[/bold magenta]')
        print('z after first 0 guess: ',z)
        print('error fuxn derivative: ',slope_f)
        print('error_f: ',error_f)





        while z>1e-5:
            stumpf = self.stumpff(z)
            deriv_stumpf = self.deriv_stumpff(z)
            y_z = mgn_mult[2] + (A*((z*stumpf['S_z']-1)/math.sqrt(stumpf['C_z'])))

            k = (deriv_stumpf['der_C']*((z*stumpf['S_z'])-1))/(2*stumpf['C_z'])

            slope_y_z = (A/math.sqrt(stumpf['C_z']))*((stumpf['S_z']+(z*deriv_stumpf['der_S'])) - k)

            if y_z<0:
                console.print('[bold red]y is negative[/bold red]')
                return

            chi_z = math.sqrt((y_z/stumpf['C_z']))
            dx_part_eq = (((slope_y_z*stumpf['C_z'])-(y_z*deriv_stumpf['der_C']))/math.pow(stumpf['C_z'],2)) #part of the dx/dz equation
            change_chi_rel_z = (1/(2*chi_z))*(dx_part_eq) #diffrent error function derivative equation uses this.
            t_calc_z = (1/math.sqrt(self.GM_S))*((math.pow(chi_z,3)*stumpf['S_z']) + (A*math.sqrt(y_z)))
            error_f_z = t_calc_z - delta_t

            if 0<=abs(error_f_z)<1e-5:
                break

            a_e = ((deriv_stumpf['der_S']-(3*stumpf['S_z']*deriv_stumpf['der_C']))/(2*math.sqrt(stumpf['C_z']))) #part of equation
            a_k = (((3*stumpf['S_z']*math.sqrt(y_z))/stumpf['C_z']) + (A*(math.sqrt(stumpf['C_z'])/y_z)))

            slope_f_z = (1/math.sqrt(self.GM_S))*((chi_z*(a_e)) + ((A/8)*a_k))
            z = z - (error_f_z/slope_f_z)
            print('z: ',z)
            print('error f',error_f_z)
            print('error f deriv: ',slope_f_z)

        return [z,error_f_z]








            











    def anmte(self,name: str=None,rt=None,real=None,baryc=None,itret=None): #itret can be used universally inside this method to tell/decide if to return or to print, baryc to activate barycentric logic..default is heliocentric.
        '''animates the orbits and current position of celestial object using seconds and AU'''

        #if os.name=='nt':
         #   os.system('cls')
        #else:
         #   os.system('clear')


        if name==None:
            console.print('[bold red]NAME CANNOT BE NONE/EMPTY[/bold red]')
            sys.exit(0)

        name = name.upper()

        values = ['MERCURY','VENUS','EARTH','MARS','VESTA','CERES','PALLAS','HYGIEA','JUPITER','SATURN','URANUS','NEPTUNE','PLUTO','HAUMEA','MAKEMAKE','ERIS']

        if name not in values:
            console.print('[bold red]NAME NOT LOCALLY RECOGNIZED OR WRONG SPELLING[/bold red]')
            sys.exit(0)

        #name = name.upper()

        #rui = self.barycentric(name)


        #values = ['MERCURY','VENUS','EARTH','MARS','VESTA','CERES','PALLAS','HYGIEA','JUPITER','SATURN','URANUS','NEPTUNE','PLUTO','HAUMEA','MAKEMAKE','ERIS']


        index = 0 if name==values[0] else 1 if name==values[1] else 2 if name==values[2] else 3 if name==values[3] else 4 if name==values[4] else 5 if name==values[5] else 6 if name==values[6] else 7 if name==values[7] else 8 if name==values[8] else 9 if name==values[9] else 10 if name==values[10] else 11 if name==values[11] else 12 if name==values[12] else 13 if name==values[13] else 14 if name==values[14] else 15 if name==values[15] else None


        values_1 = [
                {'name':'MERCURY','p':self.Mercury_P*self.earthperiod_d,'MO':self.Mercury_MO,'ps':self.Mercury_P*self.earthperiod_s,'a':self.Mercury_AU*self.AU_m,'e':self.Mercury_e,'i':math.radians(self.Mercury_i),'w':math.radians(self.Mercury_w),'omega':math.radians(self.Mercury_omega)},
                {'name':'VENUS','p':self.Venus_P*self.earthperiod_d,'MO':self.Venus_MO,'ps':self.Venus_P*self.earthperiod_s,'a':self.Venus_AU*self.AU_m,'e':self.Venus_e,'i':math.radians(self.Venus_i),'w':math.radians(self.Venus_w),'omega':math.radians(self.Venus_omega)},
                {'name':'EARTH','p':self.earthperiod_d,'MO':self.Earth_MO,'ps':self.earthperiod_s,'a':self.Earth_AU*self.AU_m,'e':self.Earth_e,'i':math.radians(self.Earth_i),'w':math.radians(self.Earth_w),'omega':math.radians(self.Earth_omega)},
                {'name':'MARS','p':self.Mars_P*self.earthperiod_d,'MO':self.Mars_MO,'ps':self.Mars_P*self.earthperiod_s,'a':self.Mars_AU*self.AU_m,'e':self.Mars_e,'i':math.radians(self.Mars_i),'w':math.radians(self.Mars_w),'omega':math.radians(self.Mars_omega)},
                {'name':'VESTA','p':self.Vesta_P*self.earthperiod_d,'MO':self.Vesta_MO,'ps':self.Vesta_P*self.earthperiod_s,'a':self.Vesta_AU*self.AU_m,'e':self.Vesta_e,'i':math.radians(self.Vesta_i),'w':math.radians(self.Vesta_w),'omega':math.radians(self.Vesta_omega)},
                {'name':'CERES','p':self.Ceres_P*self.earthperiod_d,'MO':self.Ceres_MO,'ps':self.Ceres_P*self.earthperiod_s,'a':self.Ceres_AU*self.AU_m,'e':self.Ceres_e,'i':math.radians(self.Ceres_i),'w':math.radians(self.Ceres_w),'omega':math.radians(self.Ceres_omega)},
                {'name':'PALLAS','p':self.Pallas_P*self.earthperiod_d,'MO':self.Pallas_MO,'ps':self.Pallas_P*self.earthperiod_s,'a':self.Pallas_AU*self.AU_m,'e':self.Pallas_e,'i':math.radians(self.Pallas_i),'w':math.radians(self.Pallas_w),'omega':math.radians(self.Pallas_omega)},
                {'name':'HYGIEA','p':self.Hygiea_P*self.earthperiod_d,'MO':self.Hygiea_MO,'ps':self.Hygiea_P*self.earthperiod_s,'a':self.Hygiea_AU*self.AU_m,'e':self.Hygiea_e,'i':math.radians(self.Hygiea_i),'w':math.radians(self.Hygiea_w),'omega':math.radians(self.Hygiea_omega)},
                {'name':'JUPITER','p':self.Jupiter_P*self.earthperiod_d,'MO':self.Jupiter_MO,'ps':self.Jupiter_P*self.earthperiod_s,'a':self.Jupiter_AU*self.AU_m,'e':self.Jupiter_e,'i':math.radians(self.Jupiter_i),'w':math.radians(self.Jupiter_w),'omega':math.radians(self.Jupiter_omega)},
                {'name':'SATURN','p':self.Saturn_P*self.earthperiod_d,'MO':self.Saturn_MO,'ps':self.Saturn_P*self.earthperiod_s,'a':self.Saturn_AU*self.AU_m,'e':self.Saturn_e,'i':math.radians(self.Saturn_i),'w':math.radians(self.Saturn_w),'omega':math.radians(self.Saturn_omega)},
                {'name':'URANUS','p':self.Uranus_P*self.earthperiod_d,'MO':self.Uranus_MO,'ps':self.Uranus_P*self.earthperiod_s,'a':self.Uranus_AU*self.AU_m,'e':self.Uranus_e,'i':math.radians(self.Uranus_i),'w':math.radians(self.Uranus_w),'omega':math.radians(self.Uranus_omega)},
                {'name':'NEPTUNE','p':self.Neptune_P*self.earthperiod_d,'MO':self.Neptune_MO,'ps':self.Neptune_P*self.earthperiod_s,'a':self.Neptune_AU*self.AU_m,'e':self.Neptune_e,'i':math.radians(self.Neptune_i),'w':math.radians(self.Neptune_w),'omega':math.radians(self.Neptune_omega)},
                {'name':'PLUTO','p':self.Pluto_P*self.earthperiod_d,'MO':self.Pluto_MO,'ps':self.Pluto_P*self.earthperiod_s,'a':self.Pluto_AU*self.AU_m,'e':self.Pluto_e,'i':math.radians(self.Pluto_i),'w':math.radians(self.Pluto_w),'omega':math.radians(self.Pluto_omega)},
                {'name':'HAUMEA','p':self.Haumea_P*self.earthperiod_d,'MO':self.Haumea_MO,'ps':self.Haumea_P*self.earthperiod_s,'a':self.Haumea_AU*self.AU_m,'e':self.Haumea_e,'i':math.radians(self.Haumea_i),'w':math.radians(self.Haumea_w),'omega':math.radians(self.Haumea_omega)},
                {'name':'MAKEMAKE','p':self.Makemake_P*self.earthperiod_d,'ps':self.Makemake_P*self.earthperiod_s,'a':self.Makemake_AU*self.AU_m,'MO':self.Makemake_MO,'e':self.Makemake_e,'i':math.radians(self.Makemake_i),'w':math.radians(self.Makemake_w),'omega':math.radians(self.Makemake_omega)},
                {'name':'ERIS','p':self.Eris_P*self.earthperiod_d,'MO':self.Eris_MO,'ps':self.Eris_P*self.earthperiod_s,'a':self.Eris_AU*self.AU_m,'e':self.Eris_e,'i':math.radians(self.Eris_i),'w':math.radians(self.Eris_w),'omega':math.radians(self.Eris_omega)}]

        #return retu ...from previous full list function


        

        #values = ['MERCURY','VENUS','EARTH','MARS','CERES','JUPITER','SATURN','URANUS','NEPTUNE','PLUTO','ERIS'] # should update to the current 16 objects
        Title=values_1[index].get('name','NULL ORBIT')

        #vallues = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'CERES':1681,'JUPITER':4333,'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174} #helped in getting the period

        valluesr_1 = {'MERCURY':'M','VENUS':'V','EARTH':'E','MARS':'M','CERES':'C','JUPITER':'J','SATURN':'S','URANUS':'U','NEPTUNE':'N','PLUTO':'P','ERIS':'E','HAUMEA':'H','MAKEMAKE':'M','HYGIEA':'H','VESTA':'V','PALLAS':'P'}

        #if name==None:
         #   console.print('[bold red]NAME CANNOT BE NONE/EMPTY[/bold red]')
          #  sys.exit(0)


        #retur = super().orbit(0,int(vallues.get(name,'-2')),None,'y')#using days and AU
        #retur = super().orbits(name,'y',None) #using seconds and converted to AU
        if rt:
            '''uses the accurate real time logic for a one time plot print'''
            if os.name=='nt':
                os.system('cls')
            else:
                os.system('clear')

            retu = super().orbits(name,'y',None)
            rew = self.barycentric(name)

            ptxt.clf()
            width,height = ptxt.terminal_size()
            ptxt.plotsize(width,height)
            ptxt.plot(retu['X_AUheliolist'],retu['Y_AUheliolist'],color='white')
            ptxt.scatter([rew['sun_baryc_X']/self.AU_m],[rew['sun_baryc_Y']/self.AU_m],marker='🌞') #current sun offset from barycenter
            ptxt.scatter([0],[0],marker='B') #barycenter
            ptxt.scatter([rew['X_helio']/self.AU_m],[rew['Y_helio']/self.AU_m],color='red',marker=valluesr_1.get(name,'error'))
            ptxt.xlabel('x axis AU')
            ptxt.ylabel('y axis AU')
            ptxt.title(f'{Title} at Unix time: {rew['Unix_time']}//{time.asctime()}')
            ptxt.theme('dark')
            ptxt.show()


            #return {'pltxt':ptxt,'desc':'one time real time plot print using seconds and AU'}
            sys.exit(0) #for the cli



        vallues = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'CERES':1681,'JUPITER':4333,'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174} #helped in getting the period

        retur = super().orbit(0,int(vallues.get(name,'-2')),None,'y')#using days and AU


        wrong = ['VESTA','HYGIEA','PALLAS','HAUMEA','MAKEMAKE'] #FOR NOW
        vallues_1 = {'MERCURY':'M','VENUS':'V','EARTH':'E','MARS':'M','CERES':'C','JUPITER':'J','SATURN':'S','URANUS':'U','NEPTUNE':'N','PLUTO':'P','ERIS':'E'}



        if real: ##uses the real time osculating elements to rotate and plot.
            if baryc:
                '''barycentric logic using the real time osculating elements'''
                real_osc_plot = self.reel(name,'y') #they are live osculating elements so they change iver time..but calling thw function for every iteration is too much..the returned object will always be live❤️
                #reti = self.barycentric(name)

                while name not in wrong:

                    try:
                        if os.name=='nt':
                            os.system('cls')
                        else:
                            os.system('clear')

                        reti = self.barycentric(name)

                        ##animating##
                        ptxt.clf()
                        width,height = ptxt.terminal_size()
                        ptxt.plotsize(width,height)
                        ptxt.plot(real_osc_plot['X_AUl'],real_osc_plot['Y_AUl'],color='white')
                        ptxt.scatter([reti['sun_baryc_X']/self.AU_m],[reti['sun_baryc_Y']/self.AU_m],marker='🌞') #suns barycentric offset
                        ptxt.scatter([0],[0],marker='B') #the Barycenter
                        ptxt.scatter([reti['X_bary']/self.AU_m],[reti['Y_bary']/self.AU_m],color='red',marker=vallues_1.get(name,'ERROR'))
                        ptxt.xlabel('..X_AU_axis..')
                        ptxt.ylabel('..Y_AU_axis..')
                        ptxt.title(f'{Title}-Unix time: {reti['Unix_time']}//{time.asctime()} Barycentric')
                        ptxt.theme('dark')
                        
                        if itret: #the universal return parameter
                            return ptxt

                        ptxt.show()
                        time.sleep(1)

                    except KeyboardInterrupt:
                        console.print('[bold red]KEYBOARD INTERRUPT[/bold red]')
                        sys.exit(0) #for cli use sys exit for IDE use return

            
            real_osc_plot = self.reel(name) #heliocentrci frame
            #reti = self.barycentric(name)

            while name not in wrong:
                try:
                    if os.name=='nt':
                        os.system('cls')
                    else:
                        os.system('clear')

                    reti = self.barycentric(name)

                    ##animating##
                    ptxt.clf()
                    width,height = ptxt.terminal_size()
                    ptxt.plotsize(width,height)
                    ptxt.plot(real_osc_plot['X_helioAU'],real_osc_plot['Y_helioAU'],color='white')
                    ptxt.scatter([0],[0],marker='🌞') #the sun heliocentric
                    ptxt.scatter([reti['X_helio']/self.AU_m],[reti['Y_helio']/self.AU_m],color='red',marker=vallues_1.get(name,'ERROR'))
                    ptxt.xlabel('..X_AU_axis..')
                    ptxt.ylabel('..Y_AU_axis..')
                    ptxt.title(f'{Title}-Unix time: {reti['Unix_time']}//{time.asctime()} Heliocentric')
                    ptxt.theme('dark')

                    if itret:
                        return ptxt

                    ptxt.show()
                    time.sleep(1)

                except KeyboardInterrupt:
                    console.print('[bold red]KEYBOARD INTERRUPT[/bold red]')
                    sys.exit(0)

                   

            
            
        
        while name not in wrong:

            try:
                '''the barycentric() feeds the loop with real time values.'''

                if os.name=='nt':
                    os.system('cls')
                else:
                    os.system('clear')


                ret = self.barycentric(name) # another enforcer inside barycentric.orbits()

                #vallues = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'CERES':1681,'JUPITER':4333,'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174}

                #retur = super().orbit(0,int(vallues.get(name,'-2')),None,'y') # days_elapsed set to its default value == 0..second function argument in the orbit function is the period and the 3rd argument = planet default value and the 4th argument is the activation of the eccentric logic in orbit

                day = (ret['M']/(2*math.pi))*values_1[index]['p'] #gives the day from the real mean anomaly in self.barycentric()

                #i = (ret['M']/(2*math.pi))*retur['XYZME_list_size'] # the index ...CAN USE EITHER DAY IR i...

                X_day = retur['X_heliolist'][math.trunc(day)] # using truncate because if day==87.57 then that day is not over yet and therefore not valid hence 87....###updated from days to secodns
                Y_day = retur['Y_heliolist'][math.trunc(day)] #..matches the real Mean anomaly to the corresponding XY heliocentric Coord. 
                Z_day = retur['Z_heliolist'][math.trunc(day)] # the list index starts from 0th -1 for compatibility
                


                ###animating###
                ptxt.clf()
                width,height = ptxt.terminal_size()
                ptxt.plotsize(width,height)
                #Title=values_1[index].get('name','NULL ORBIT')

                ptxt.plot(retur['X_heliolist'],retur['Y_heliolist'],color='white')
                ptxt.scatter([ret['sun_baryc_X']/self.AU_m],[ret['sun_baryc_Y']/self.AU_m],marker='🌞') #,label='Sun'
                ptxt.scatter([0],[0],marker='B') # SSB
                ptxt.scatter([X_day],[Y_day],color='red',marker=vallues_1.get(name,'Error')) #,label=..) # current position

                ptxt.xlabel('..X_axis AU..')
                ptxt.ylabel('..Y_axis AU..')
                ptxt.title(f'{Title} at Unix time: {ret['Unix_time']}//{time.asctime()}')
                ptxt.theme('dark')
                #ptxt.grid(True)
                
                if itret:
                    return ptxt # the plotext object...

                ptxt.show()

                time.sleep(1)

            except KeyboardInterrupt:
                console.print('[bold red]KEYBOARD INTERRUPT[/bold red]')
                sys.exit(0)

        console.print(f'[bold red]{[N for N in wrong]}NOT COMPATIBLE AS OF NOW[/bold red]')





    def rtime(self,name=None,lp=None,tble=None):
        '''the printer to the terminal/command line/console'''

        #console = Console()

        if (lp and name==None) or (lp==None and name==None):
            console.print('[bold red]NAME CANT BE NONE/EMPTY[/bold red]')
            sys.exit(0)


        #console = Console()
        name = name.upper()

        if name and lp==None:

            retu = self.barycentric(name)
            ax,ay,az = self.acce(name)
            accel_a = math.sqrt(math.pow(ax,2) + math.pow(ay,2) + math.pow(az,2)) #m/s2
          #  key = 'bold Cyan'
           # keyclose = '/bold Cyan'
            #vam = 'bold white'
         #   vamclose = '/bold white'
          #  si = 'bold magenta'
           # siclose  = '/bold magenta'


            if name!='EARTH':

                #prin_t = f'\n[bold yellow]{retu['name']}[/bold yellow] [bold green]for Unix time[/bold green] [bold yellow]{retu['Unix_time']}[/bold yellow] [bold green]its X,Y,Z Coordinates were[/bold green] [bold yellow]({retu['X_bary']} , {retu['Y_bary']} , {retu['Z_bary']})[/bold yellow] [bold green]at a distance of[/bold green] [bold yellow]{retu['d_bary']}--(m)-- or {retu['d_bary']/1000}--(km)--[/bold yellow] [bold green]from Earth.\nLight delay[/bold green] [bold yellow]{retu['light_delay_bary']}--(seconds)-- or {retu['light_delay_bary']/60}--(minutes)--[/bold yellow].[bold green]This means you will see it from earth as it was {retu['light_delay_bary']}--(seconds)-- or {retu['light_delay_bary']/60}--(minutes)-- ago because it takes light {retu['light_delay_bary']}--(seconds)-- or {retu['light_delay_bary']/60}--(minutes)-- to reach Earth from {retu['name']}.\n{retu['name']} is currently[/bold green] [bold yellow]{retu['r_bary']}--(meters)-- or {retu['r_bary']/1000}--(km)-- or {retu['r_bary']/self.AU_m}--(Astronomical Units AU)--[/bold yellow] [bold green]from the sun.\nIt is currently orbiting the sun with a velocity of[/bold green] [bold yellow]{retu['v_bary']}--(m/s)-- or {retu['v_bary']/1000}--(km/s)--[/bold yellow].'

                prin_t = f'''\n[bold Cyan]Name: [/bold Cyan][bold white]{retu['name']}[/bold white]\n[bold Cyan]Unix Time since JD2000: [/bold Cyan][bold white]{retu['Unix_time']}[/bold white] [bold magenta](s)[/bold magenta] or [bold white]{time.asctime()}[/bold white]\n[bold Cyan]Mean anomaly: [/bold Cyan][bold white]{retu['M']}[/bold white]\n[bold Cyan]Eccentric anomaly: [/bold Cyan][bold white]{retu['E']}[/bold white]\n[bold Cyan]Current orbital day on {retu['name']} (Orbital day): [/bold Cyan][bold white]{retu['resp_day']}[/bold white] [bold magenta](Sol)[/bold magenta]\n[bold Cyan]Velocity vector relative SSB: [/bold Cyan][bold white]({retu['v_X']}, {retu['v_Y']}, {retu['v_Z']}) [/bold white][bold magenta](m/s)[/bold magenta]\n[bold Cyan]Position vector relative SSB: [/bold Cyan][bold white]({retu['X_bary']}, {retu['Y_bary']}, {retu['Z_bary']})[/bold white] [bold magenta](m meters)[/bold magenta]\n\n[bold Cyan]Position vector relative Heliocenter: [/bold Cyan][bold white]({retu['X_helio']}, {retu['Y_helio']}, {retu['Z_helio']})[/bold white] [bold magenta](m meters)[/bold magenta]\n\n[bold Cyan]Gravitational acceleration vector due to other bodies: [/bold Cyan][bold white]({ax}, {ay}, {az})[/bold white] [bold magenta](m/s^2)[/bold magenta]\n[bold Cyan]Geocentric Distance using barycentric SSB frame: [/bold Cyan][bold white]{retu['d_bary']/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{retu['d_bary']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Geocentric Distance using heliocentric ¿sun¿ frame: [/bold Cyan][bold white]{retu['d_helio']/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{retu['d_helio']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Geocentric Light delay using barycentric SSB frame: [/bold Cyan][bold white]{retu['light_delay_bary']}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{retu['light_delay_bary']/60}[/bold white] [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Geocentric light delay using heliocentric ¿sun¿ frame: [/bold Cyan][bold white]{retu['light_delay_helio']}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{retu['light_delay_helio']/60} [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Light delay from heliocenter to {retu['name']}: [/bold Cyan][bold white]{retu['light_delay_sun_helio']}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{retu['light_delay_sun_helio']/60}[/bold white] [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Light delay from barycenter to {retu['name']}: [/bold Cyan][bold white]{retu['light_delay_sun_bary']}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{retu['light_delay_sun_bary']/60}[/bold white] [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Current distance of {retu['name']} from barycenter: [/bold Cyan][bold white]{retu['r_bary']}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{retu['r_bary']/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{retu['r_bary']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Current distance of {retu['name']} from heliocenter: [/bold Cyan][bold white]{retu['r_helio']}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{retu['r_helio']/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{retu['r_helio']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Orbital velocity relative SSB: [/bold Cyan][bold white]{retu['v_bary']}[/bold white] [bold magenta](m/s)[/bold magenta] [bold white]{retu['v_bary']/1000}[/bold white] [bold magenta](km/s)[/bold magenta]\n[bold Cyan]Orbital velocity relative heliocenter: [/bold Cyan][bold white]{retu['v_helio']}[/bold white] [bold magenta](m/s)[/bold magenta] [bold white]{retu['v_helio']/1000}[/bold white] [bold magenta](km/s)[/bold magenta]\n[bold Cyan]Position vector of Sun relative Solar System barycenter SSB: [/bold Cyan][bold white]({retu['sun_baryc_X']}, {retu['sun_baryc_Y']}, {retu['sun_baryc_Z']})[/bold white] [bold magenta](m)[/bold magenta]\n\n[bold Cyan]Current distance of sun relative/from SSB: [/bold Cyan][bold white]{retu['r_sun_SSB']}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{retu['r_sun_SSB']/1000}[/bold white] [bold magenta](km)[/bold magenta]\n[bold Cyan]{retu['name']} Gravitational acceleration due to other bodies: [/bold Cyan][bold white]{accel_a}[/bold white] [bold magenta](m/s^2)[/bold magenta]\n[bold Cyan]Angular momentum: [/bold Cyan][bold white]{retu['h']}[/bold white] [bold magenta](m^2/s)[/bold magenta]\n[bold Cyan]orbital Energy E: [/bold Cyan][bold white]{retu['energy_bary']}[/bold white] [bold magenta](m^2/s^2)[/bold magenta]\n\n[bold yellow]##osculating elements a, e, i, Omega, omega, true anomaly (v).\nEpoch: Real-time {time.time()} or {time.asctime()}\nReference frame: J2000 | Julian January 1st 2000##[/bold yellow]\n[bold Cyan]{retu['name']} Osculating/real time element a (semi-major-axis): [/bold Cyan][bold white]{retu['osc_a']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]eccentric vector: [bold Cyan][bold white ]({retu['e_X']},{retu['e_Y']},{retu['e_Z']})[/bold white]\n[bold Cyan]magnitude of eccentricity: [/bold Cyan][bold white] {retu['mgn_eccentricity']}\n[bold Cyan]Inclination: [/bold Cyan][bold white]{retu['osc_i']}[bold white][bold magenta]°[/bold magenta]\n[bold Cyan]Ω Omega: [/bold Cyan][bold white]{retu['Omega']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]ω omega: [/bold Cyan][bold white]{retu['argof_periapsis']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]True anomaly v: [bold Cyan][bold white]{retu['true_anomaly']}\n\n[bold Yellow]Heliocentric Frame##[/bold yellow]\n[bold Cyan]eccentric vector: [bold Cyan][bold white ]({retu['e_Xhelio']},{retu['e_Yhelio']},{retu['e_Zhelio']})[/bold white]\n[bold Cyan]magnitude of eccentricity: [/bold Cyan][bold white] {retu['mgn_eccentricityhelio']}\n[bold Cyan]semi-major axis a: [/bold Cyan][bold white]{retu['osc_ahelio']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Inclination: [/bold Cyan][bold white]{retu['osc_ihelio']}[bold white][bold magenta]°[/bold magenta]\n[bold Cyan]Ω Omega: [/bold Cyan][bold white]{retu['Omegahelio']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]ω omega: [/bold Cyan][bold white]{retu['argof_perihelion']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]True anomaly v: [bold Cyan][bold white]{retu['true_anomalyhelio']}\n[bold Cyan]Energy E: [bold Cyan][bold white]{retu['energyhelio']}[/bold white] [bold magenta](m^2/s^2)[/bold magenta]\n[bold Cyan]Angular momentum h: [bold Cyan][bold white]{retu['h_helio']}[/bold white] [bold magenta](m^2/s)[/bold magenta]\n[bold yellow]##/()\##[/bold yellow]\n'''

                console.print(prin_t)

            else: # if name==earth

                ##prin_t = f'\n[bold yellow]{retu['name']}[/bold yellow] [bold green]for Unix time[/bold green] [bold yellow]{retu['Unix_time']}[/bold yellow] [bold green]its X,Y,Z Coordinates were[/bold green] [bold yellow]({retu['X_bary']} , {retu['Y_bary']} , {retu['Z_bary']})[/bold yellow].\n[bold green]{retu['name']} is currently[/bold green] [bold yellow]{retu['r_bary']}--(meters)-- or {retu['r_bary']/1000}--(km)-- or {retu['r_bary']/self.AU_m}--(Astronomical Units AU)--[/bold yellow] [bold green]from the sun.\nLight delay: {retu['r_bary']/self.c_m_s}--(seconds)-- *//* {(retu['r_bary']/self.c_m_s)/60}--(minutes)-- from the sun.\nIt is currently orbiting the sun with a velocity of[/bold green] [bold yellow]{retu['v_bary']}--(m/s)-- or {retu['v_bary']/1000}--(km/s)--[/bold yellow].'
                #prin_t = f'\n[bold Cyan]Name: [/bold Cyan][bold white]{retu['name']}[/bold white]\n[bold Cyan]Unix Time: [/bold Cyan][bold white]{retu['Unix_time']}[/bold white] [bold magenta](s)[/bold magenta] or [vam]{time.asctime()}[vamclose]\n[bold Cyan]Mean anomaly :[/bold Cyan][bold white]{retu['M']}[/bold white]\n[bold Cyan]Eccentric anomaly: [/bold Cyan][bold white]{retu['E']}[/bold white]\n[bold Cyan]X_Y_Z RELATIVE TO SSB l: [/bold Cyan][bold white]({retu['X_bary']},{retu['Y_bary']},{retu['Z_bary']})[/bold white] [bold magenta](m meters)[/bold magenta]\n[bold Cyan]X_Y_Z HELIOCENTRIC: [/bold Cyan][bold white]({retu['X_helio']},{retu['Y_helio']},{retu['Z_helio']})[/bold white] [bold magenta](m meters)[/bold magenta]\n\n[bold Cyan]Light delay from Sun to {retu['name']} heliocentric XYZ: [/bold Cyan][bold white]{retu['light_delay_sun_helio']}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{retu['light_delay_sun_helio']/60}[/bold white] [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Light delay from sun to {retu['name']} SSB XYZ: [/bold Cyan][bold white]{retu['light_delay_sun_bary']}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{retu['light_delay_sun_bary']}[/bold white] [bold magenta]

                prin_t = f'''\n[bold Cyan]Name: [/bold Cyan][bold white]{retu['name']}[/bold white]\n[bold Cyan]Unix Time since JD2000: [/bold Cyan][bold white]{retu['Unix_time']}[/bold white] [bold magenta](s)[/bold magenta] or [bold white]{time.asctime()}[/bold white]\n[bold Cyan]Mean anomaly :[/bold Cyan][bold white]{retu['M']}[/bold white]\n[bold Cyan]Eccentric anomaly: [/bold Cyan][bold white]{retu['E']}[/bold white]\n[bold Cyan]Current orbital day on {retu['name']} (Orbital day): [/bold Cyan][bold white]{retu['resp_day']}[/bold white] [bold magenta](Sol)[/bold magenta]\n[bold Cyan]Velocity vector relative SSB: [/bold Cyan][bold white]({retu['v_X']}, {retu['v_Y']}, {retu['v_Z']}) [/bold white][bold magenta](m/s)[/bold magenta]\n[bold Cyan]Position vector relative SSB: [/bold Cyan][bold white]({retu['X_bary']}, {retu['Y_bary']}, {retu['Z_bary']})[/bold white] [bold magenta](m meters)[/bold magenta]\n\n[bold Cyan]Position vector relative Heliocenter: [/bold Cyan][bold white]({retu['X_helio']}, {retu['Y_helio']}, {retu['Z_helio']})[/bold white] [bold magenta](m meters)[/bold magenta]\n\n[bold Cyan]Gravitational acceleration vector due to other bodies: [/bold Cyan][bold white]({ax}, {ay}, {az})[/bold white] [bold magenta](m/s^2)[/bold magenta]\n[bold Cyan]Light delay from heliocenter to {retu['name']}: [/bold Cyan][bold white]{retu['light_delay_sun_helio']}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{retu['light_delay_sun_helio']/60}[/bold white] [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Light delay from barycenter to {retu['name']}: [/bold Cyan][bold white]{retu['light_delay_sun_bary']}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{retu['light_delay_sun_bary']/60}[/bold white] [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Current distance of {retu['name']} from barycenter: [/bold Cyan][bold white]{retu['r_bary']}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{retu['r_bary']/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{retu['r_bary']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Current distance of {retu['name']} from heliocenter: [/bold Cyan][bold white]{retu['r_helio']}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{retu['r_helio']/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{retu['r_helio']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Position vector of Sun relative Solar System barycenter SSB: [/bold Cyan][bold white]({retu['sun_baryc_X']}, {retu['sun_baryc_Y']}, {retu['sun_baryc_Z']})[/bold white] [bold magenta](m)[/bold magenta]\n\n[bold Cyan]Current distance of sun relative/from SSB: [/bold Cyan][bold white]{retu['r_sun_SSB']}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{retu['r_sun_SSB']/1000}[/bold white] [bold magenta](km)[/bold magenta]\n[bold Cyan]Orbital velocity relative SSB: [/bold Cyan][bold white]{retu['v_bary']}[/bold white] [bold magenta](m/s)[/bold magenta] [bold white]{retu['v_bary']/1000}[/bold white] [bold magenta](km/s)[/bold magenta]\n[bold Cyan]Orbital velocity relative heliocenter: [/bold Cyan][bold white]{retu['v_helio']}[/bold white] [bold magenta](m/s)[/bold magenta] [bold white]{retu['v_helio']/1000}[/bold white] [bold magenta](km)[/bold magenta]\n[bold Cyan]{retu['name']} Gravitational acceleration due to other bodies: [/bold Cyan][bold white]{accel_a}[/bold white] [bold magenta](m/s^2)[/bold magenta]\n[bold Cyan]Angular momentum: [/bold Cyan][bold white]{retu['h']}[/bold white] [bold magenta](m^2/s)[/bold magenta]\n[bold Cyan]orbital Energy E: [/bold Cyan][bold white]{retu['energy_bary']}[/bold white] [bold magenta](m^2/s^2)[/bold magenta]\n\n[bold yellow]##Osculating elements a, e, i, Omega, omega, true anomaly (v).\nEpoch: Real-time {time.time()} or {time.asctime()}\nReference frame: J2000 | Julian January 1st 2000##[/bold yellow]\n[bold Cyan]eccentric vector: [bold Cyan][bold white ]({retu['e_X']},{retu['e_Y']},{retu['e_Z']})[/bold white]\n[bold Cyan]{retu['name']} Osculating/real time element a (semi-major-axis): [/bold Cyan][bold white]{retu['osc_a']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]magnitude of eccentricity: [/bold Cyan][bold white] {retu['mgn_eccentricity']}\n[bold Cyan]Inclination: [/bold Cyan][bold white]{retu['osc_i']}[bold white][bold magenta]°[/bold magenta]\n[bold Cyan]Ω Omega: [/bold Cyan][bold white]{retu['Omega']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]ω omega: [/bold Cyan][bold white]{retu['argof_periapsis']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]True anomaly v: [bold Cyan][bold white]{retu['true_anomaly']}\n\n[bold Yellow]Heliocentric Frame##[/bold yellow]\n[bold Cyan]eccentric vector: [bold Cyan][bold white ]({retu['e_Xhelio']},{retu['e_Yhelio']},{retu['e_Zhelio']})[/bold white]\n[bold Cyan]magnitude of eccentricity: [/bold Cyan][bold white] {retu['mgn_eccentricityhelio']}\n[bold Cyan]semi-major axis a: [/bold Cyan][bold white]{retu['osc_ahelio']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Inclination: [/bold Cyan][bold white]{retu['osc_ihelio']}[bold white][bold magenta]°[/bold magenta]\n[bold Cyan]Ω Omega: [/bold Cyan][bold white]{retu['Omegahelio']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]ω omega: [/bold Cyan][bold white]{retu['argof_perihelion']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]True anomaly v: [bold Cyan][bold white]{retu['true_anomalyhelio']}\n[bold Cyan]Energy E: [bold Cyan][bold white]{retu['energyhelio']}[/bold white] [bold magenta](m^2/s^2)[/bold magenta]\n[bold Cyan]Angular momentum h: [bold Cyan][bold white]{retu['h_helio']}[/bold white] [bold magenta](m^2/s)[/bold magenta]\n[bold yellow]##/()\##[/bold yellow]\n'''


                console.print(prin_t)




        if name and lp:
            while True:
                try:

                    if os.name=='nt':
                        os.system('cls')
                    else:
                        os.system('clear')

                    sun_barycentric = self.baryc_sun()
                    r_sun_SSB = math.sqrt(math.pow(sun_barycentric['X_s'],2) + math.pow(sun_barycentric['Y_s'],2) + math.pow(sun_barycentric['Z_s'],2))
                    ax,ay,az = self.acce(name)
                    accel_a = math.sqrt(math.pow(ax,2) + math.pow(ay,2) + math.pow(az,2))
                    #total_mass_u = self.G*sun_barycentric['total_mass']
                    spec_uhelio = super().spec_uhelio(name)

                    retu = super().orbits(name) # ,lp)
                    ruii = self.barycentric(name) #this function can handle everything here i repeated myself
                    u_total = super().u_total()

                    X_bary = retu['X_helio'] + sun_barycentric['X_s']
                    Y_bary = retu['Y_helio'] + sun_barycentric['Y_s']
                    Z_bary = retu['Z_helio'] + sun_barycentric['Z_s']

                    r_bary = math.sqrt(math.pow(X_bary,2)+math.pow(Y_bary,2)+math.pow(Z_bary,2))

                    r_helio = math.sqrt(math.pow(retu['X_helio'],2)+math.pow(retu['Y_helio'],2)+math.pow(retu['Z_helio'],2)) #relative to heliocentric sun.
                    #v_bary = math.sqrt(total_mass_u * ((2/(r_bary))-(1/(retu['a'])))) # the vis-viva equation
                    v_bary = math.sqrt(math.pow(retu['v_X'],2) + math.pow(retu['v_Y'],2) + math.pow(retu['v_Z'],2))

                    v_helio = math.sqrt(spec_uhelio * ((2/r_helio) - (1/retu['a']))) #heliocentric speed
                    osculating_a = math.pow(((2/r_bary) - (math.pow(v_bary,2)/u_total)),-1)

                    light_delay_sun_bary = r_bary/self.c_m_s
                    light_delay_sun_helio = r_helio/self.c_m_s


                    if name!='EARTH':

                        sun_barycentric = self.baryc_sun()
                        X_E_bary = retu['X_E_helio'] + sun_barycentric['X_s']
                        Y_E_bary = retu['Y_E_helio'] + sun_barycentric['Y_s']
                        Z_E_bary = retu['Z_E_helio'] + sun_barycentric['Z_s']
                        d_bary = math.sqrt(math.pow((X_bary-X_E_bary),2) + math.pow((Y_bary-Y_E_bary),2) + math.pow((Z_bary-Z_E_bary),2))

                        d_helio = math.sqrt(math.pow((retu['X_helio']-retu['X_E_helio']),2) + math.pow((retu['Y_helio']-retu['Y_E_helio']),2) + math.pow((retu['Z_helio']-retu['Z_E_helio']),2)) # relative to heliocentric sun

                        light_delay_bary = d_bary/self.c_m_s # light delay in seconds
                        light_delay_helio = d_helio/self.c_m_s # light delay relative to heliocenter.

                        #prin_t = f'\n[bold yellow]{retu['N']}[/bold yellow] [bold green]for Unix time[/bold green] [bold yellow]{retu['Unix_time']}[/bold yellow] [bold green]its X,Y,Z Coordinates were[/bold green] [bold yellow]({X_bary} , {Y_bary} , {Z_bary})[/bold yellow] [bold green]at a distance of[/bold green] [bold yellow]{d_bary}--(m)-- or {d_bary/1000}--(km)--[/bold yellow] [bold green]from Earth.\nLight delay[/bold green] [bold yellow]{light_delay_bary}--(seconds)-- or {light_delay_bary/60}--(minutes)--[/bold yellow].[bold green]This means you will see it from earth as it was {light_delay_bary}--(seconds)-- or {light_delay_bary/60}--(minutes)-- ago because it takes light {light_delay_bary}--(seconds)-- or {light_delay_bary/60}--(minutes)-- to reach Earth from {retu['N']}.\n{retu['N']} is currently[/bold green] [bold yellow]{r_bary}--(meters)-- or {r_bary/1000}--(km)-- or {r_bary/self.AU_m}--(Astronomical Units AU)--[/bold yellow] [bold green]from the sun.\nIt is currently orbiting the sun with a velocity of[/bold green] [bold yellow]{v_bary}--(m/s)-- or {v_bary/1000}--(km/s)--[/bold yellow].'

                        prin_t = f'''\n[bold Cyan]Name: [/bold Cyan][bold white]{retu['N']}[/bold white]\n[bold Cyan]Unix Time since JD2000: [/bold Cyan][bold white]{retu['Unix_time']}[/bold white] [bold magenta](s)[/bold magenta] or [bold white]{time.asctime()}[/bold white]\n[bold Cyan]Mean anomaly :[/bold Cyan][bold white]{retu['M']}[/bold white]\n[bold Cyan]Eccentric anomaly: [/bold Cyan][bold white]{retu['E']}[/bold white]\n[bold Cyan]Current orbital day on {retu['N']} (Orbital day): [/bold Cyan][bold white]{retu['resp_day']}[/bold white] [bold magenta](Sol)[/bold magenta]\n[bold Cyan]Velocity vector relative SSB: [/bold Cyan][bold white]({retu['v_X']}, {retu['v_Y']}, {retu['v_Z']}) [/bold white][bold magenta](m/s)[/bold magenta]\n[bold Cyan]Position vector relative SSB: [/bold Cyan][bold white]({X_bary}, {Y_bary}, {Z_bary})[/bold white] [bold magenta](m meters)[/bold magenta]\n\n[bold Cyan]Position vector relative Heliocenter: [/bold Cyan][bold white]({retu['X_helio']}, {retu['Y_helio']}, {retu['Z_helio']})[/bold white] [bold magenta](m meters)[/bold magenta]\n\n[bold Cyan]Gravitational acceleration vector due to other bodies: [/bold Cyan][bold white]({ax}, {ay}, {az})[/bold white] [bold magenta](m/s^2)[/bold magenta]\n[bold Cyan]Geocentric Distance using barycentric SSB frame: [/bold Cyan][bold white]{d_bary/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{d_bary/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Geocentric Distance using heliocentric ¿sun¿ frame: [/bold Cyan][bold white]{d_helio/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{d_helio/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Geocentric Light delay using barycentric SSB frame: [/bold Cyan][bold white]{light_delay_bary}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{light_delay_bary/60}[/bold white] [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Geocentric light delay using heliocentric ¿sun¿ frame: [/bold Cyan][bold white]{light_delay_helio}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{light_delay_helio/60} [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Light delay from heliocenter to {retu['N']}: [/bold Cyan][bold white]{light_delay_sun_helio}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{light_delay_sun_helio/60}[/bold white] [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Light delay from barycenter to {retu['N']}: [/bold Cyan][bold white]{light_delay_sun_bary}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{light_delay_sun_bary/60}[/bold white] [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Current distance of {retu['N']} from barycenter: [/bold Cyan][bold white]{r_bary}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{r_bary/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{r_bary/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Current distance of {retu['N']} from heliocenter: [/bold Cyan][bold white]{r_helio}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{r_helio/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{r_helio/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Orbital velocity relative SSB: [/bold Cyan][bold white]{v_bary}[/bold white] [bold magenta](m/s)[/bold magenta] [bold white]{v_bary/1000}[/bold white] [bold magenta](km/s)[/bold magenta]\n[bold Cyan]Orbital velocity relative heliocenter: [/bold Cyan][bold white]{v_helio}[/bold white] [bold magenta](m/s)[/bold magenta] [bold white]{v_helio/1000}[/bold white] [bold magenta](km/s)[/bold magenta]\n[bold Cyan]Position vector of Sun relative Solar System barycenter SSB: [/bold Cyan][bold white]({sun_barycentric['X_s']}, {sun_barycentric['Y_s']}, {sun_barycentric['Z_s']})[/bold white] [bold magenta](m)[/bold magenta]\n\n[bold Cyan]Current distance of sun relative/from SSB: [/bold Cyan][bold white]{r_sun_SSB}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{r_sun_SSB/1000}[/bold white] [bold magenta](km)[/bold magenta]\n[bold Cyan]{retu['N']} Gravitational acceleration due to other bodies: [/bold Cyan][bold white]{accel_a}[/bold white] [bold magenta](m/s^2)[/bold magenta]\n[bold Cyan]Angular momentum: [/bold Cyan][bold white]{ruii['h']}[/bold white] [bold magenta](m^2/s)[/bold magenta]\n[bold Cyan]orbital Energy E: [/bold Cyan][bold white]{ruii['energy_bary']}[/bold white] [bold magenta](m^2/s^2)[/bold magenta]\n\n\n[bold yellow]##osculating elements a, e, i, Omega, omega, true anomaly (v).\nEpoch: Real-time {time.time()} or {time.asctime()}\nReference frame: J2000 | Julian January 1st 2000##[/bold yellow]\n[bold Cyan]eccentric vector: [bold Cyan][bold white ]({ruii['e_X']},{ruii['e_Y']},{ruii['e_Z']})[/bold white]\n[bold Cyan]{ruii['name']} Osculating/real time element a (semi-major-axis): [/bold Cyan][bold white]{ruii['osc_a']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]magnitude of eccentricity: [/bold Cyan][bold white] {ruii['mgn_eccentricity']}\n[bold Cyan]Inclination: [/bold Cyan][bold white]{ruii['osc_i']}[bold white][bold magenta]°[/bold magenta]\n[bold Cyan]Ω Omega: [/bold Cyan][bold white]{ruii['Omega']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]ω omega: [/bold Cyan][bold white]{ruii['argof_periapsis']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]True anomaly v: [bold Cyan][bold white]{ruii['true_anomaly']}\n\n[bold Yellow]Heliocentric Frame##[/bold yellow]\n[bold Cyan]eccentric vector: [bold Cyan][bold white ]({retu['e_X']},{retu['e_Y']},{retu['e_Z']})[/bold white]\n[bold Cyan]semi-major axis a: [/bold Cyan][bold white]{retu['osc_a']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]magnitude of eccentricity: [/bold Cyan][bold white] {retu['mgn_eccentricity']}\n[bold Cyan]Inclination: [/bold Cyan][bold white]{retu['osc_i']}[bold white][bold magenta]°[/bold magenta]\n[bold Cyan]Ω Omega: [/bold Cyan][bold white]{retu['Omega']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]ω omega: [/bold Cyan][bold white]{retu['argumentof_perihelion']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]True anomaly v: [bold Cyan][bold white]{retu['true_anomaly']}\n[bold Cyan]Energy E: [bold Cyan][bold white]{retu['energy_helio']}[/bold white] [bold magenta](m^2/s^2)[/bold magenta]\n[bold Cyan]Angular momentum h: [bold Cyan][bold white]{retu['h']}[/bold white] [bold magenta](m^2/s)[/bold magenta]\n[bold yellow]##/()\##[/bold yellow]\n'''


                        console.print(prin_t)


                    else: # if name==earth

                        #prin_t = f'\n[bold yellow]{retu['N']}[/bold yellow] [bold green]for Unix time[/bold green] [bold yellow]{retu['Unix_time']}[/bold yellow] [bold green]its X,Y,Z Coordinates were[/bold green] [bold yellow]({X_bary} , {Y_bary} , {Z_bary})[/bold yellow].\n[bold green]{retu['N']} is currently[/bold green] [bold yellow]{r_bary}--(meters)-- or {r_bary/1000}--(km)-- or {r_bary/self.AU_m}--(Astronomical Units AU)--[/bold yellow] [bold green]from the sun.\nLight delay: {r_bary/self.c_m_s}--(seconds)-- *//* {(r_bary/self.c_m_s)/60}--(minutes)-- from the sun.\nIt is currently orbiting the sun with a velocity of[/bold green] [bold yellow]{v_bary}--(m/s)-- or {v_bary/1000}--(km/s)--[/bold yellow].'

                        prin_t = f'''\n[bold Cyan]Name: [/bold Cyan][bold white]{retu['N']}[/bold white]\n[bold Cyan]Unix Time since JD2000: [/bold Cyan][bold white]{retu['Unix_time']}[/bold white] [bold magenta](s)[/bold magenta] or [bold white]{time.asctime()}[/bold white]\n[bold Cyan]Mean anomaly :[/bold Cyan][bold white]{retu['M']}[/bold white]\n[bold Cyan]Eccentric anomaly: [/bold Cyan][bold white]{retu['E']}[/bold white]\n[bold Cyan]Current orbital day on {retu['N']} (Orbital day): [/bold Cyan][bold white]{retu['resp_day']}[/bold white] [bold magenta](Sol)[/bold magenta]\n[bold Cyan]Velocity vectors relative SSB: [/bold Cyan][bold white]({retu['v_X']}, {retu['v_Y']}, {retu['v_Z']}) [/bold white][bold magenta](m/s)[/bold magenta]\n[bold Cyan]Position vector relative SSB: [/bold Cyan][bold white]({X_bary}, {Y_bary}, {Z_bary})[/bold white] [bold magenta](m meters)[/bold magenta]\n\n[bold Cyan]Position vector relative Heliocenter: [/bold Cyan][bold white]({retu['X_helio']}, {retu['Y_helio']}, {retu['Z_helio']})[/bold white] [bold magenta](m meters)[/bold magenta]\n\n[bold Cyan]Gravitational acceleration vector due to other bodies: [/bold Cyan][bold white]({ax}, {ay}, {az})[/bold white] [bold magenta](m/s^2)[/bold magenta]\n[bold Cyan]Light delay from heliocenter to {retu['N']}: [/bold Cyan][bold white]{light_delay_sun_helio}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{light_delay_sun_helio/60}[/bold white] [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Light delay from barycenter to {retu['N']}: [/bold Cyan][bold white]{light_delay_sun_bary}[/bold white] [bold magenta](s)[/bold magenta] [bold white]{light_delay_sun_bary/60}[/bold white] [bold magenta](minutes)[/bold magenta]\n[bold Cyan]Current distance of {retu['N']} from barycenter: [/bold Cyan][bold white]{r_bary}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{r_bary/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{r_bary/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Current distance of {retu['N']} from heliocenter: [/bold Cyan][bold white]{r_helio}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{r_helio/1000}[/bold white] [bold magenta](km)[/bold magenta] [bold white]{r_helio/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]Position vector of Sun relative Solar System barycenter SSB: [/bold Cyan][bold white]({sun_barycentric['X_s']}, {sun_barycentric['Y_s']}, {sun_barycentric['Z_s']})[/bold white] [bold magenta](m)[/bold magenta]\n\n[bold Cyan]Current distance of sun relative/from SSB: [/bold Cyan][bold white]{r_sun_SSB}[/bold white] [bold magenta](m)[/bold magenta] [bold white]{r_sun_SSB/1000}[/bold white] [bold magenta](km)[/bold magenta]\n[bold Cyan]Orbital velocity relative SSB: [/bold Cyan][bold white]{v_bary}[/bold white] [bold magenta](m/s)[/bold magenta] [bold white]{v_bary/1000}[/bold white] [bold magenta](km/s)[/bold magenta]\n[bold Cyan]Orbital velocity relative heliocenter: [/bold Cyan][bold white]{v_helio}[/bold white] [bold magenta](m/s)[/bold magenta] [bold white]{v_helio/1000}[/bold white] [bold magenta](km/s)[/bold magenta]\n[bold Cyan]{retu['N']} Gravitational acceleration due to other bodies: [/bold Cyan][bold white]{accel_a}[/bold white] [bold magenta](m/s^2)[/bold magenta]\n[bold Cyan]Angular momentum: [/bold Cyan][bold white]{ruii['h']}[/bold white] [bold magenta](m^2/s)[/bold magenta]\n[bold Cyan]orbital Energy E: [/bold Cyan][bold white]{ruii['energy_bary']}[/bold white] [bold magenta](m^2/s^2)[/bold magenta]\n\n[bold yellow]##osculating elements a, e, i, Omega, omega, true anomaly (v).\nEpoch: Real-time {time.time()} or {time.asctime()}\nReference frame: J2000 | Julian January 1st 2000##[/bold yellow]\n[bold Cyan]{ruii['name']} Osculating/real time element a (semi-major-axis): [/bold Cyan][bold white]{retu['osc_a']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]eccentric vector: [bold Cyan][bold white ]({ruii['e_X']},{ruii['e_Y']},{ruii['e_Z']})[/bold white]\n[bold Cyan]magnitude of eccentricity: [/bold Cyan][bold white] {ruii['mgn_eccentricity']}\n[bold Cyan]Inclination: [/bold Cyan][bold white]{ruii['osc_i']}[bold white][bold magenta]°[/bold magenta]\n[bold Cyan]Ω Omega: [/bold Cyan][bold white]{ruii['Omega']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]ω omega: [/bold Cyan][bold white]{ruii['argof_periapsis']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]True anomaly v: [bold Cyan][bold white]{ruii['true_anomaly']}\n\n[bold Yellow]Heliocentric Frame##[/bold yellow]\n[bold Cyan]eccentric vector: [bold Cyan][bold white ]({retu['e_X']},{retu['e_Y']},{retu['e_Z']})[/bold white]\n[bold Cyan]semi-major axis a: [/bold Cyan][bold white]{retu['osc_a']/self.AU_m}[/bold white] [bold magenta](AU)[/bold magenta]\n[bold Cyan]magnitude of eccentricity: [/bold Cyan][bold white] {retu['mgn_eccentricity']}\n[bold Cyan]Inclination: [/bold Cyan][bold white]{retu['osc_i']}[bold white][bold magenta]°[/bold magenta]\n[bold Cyan]Ω Omega: [/bold Cyan][bold white]{retu['Omega']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]ω omega: [/bold Cyan][bold white]{retu['argumentof_perihelion']}[/bold white][bold magenta]°[/bold magenta]\n[bold Cyan]True anomaly v: [bold Cyan][bold white]{retu['true_anomaly']}\n[bold Cyan]Energy E: [bold Cyan][bold white]{retu['energy_helio']}[/bold white] [bold magenta](m^2/s^2)[/bold magenta]\n[bold Cyan]Angular momentum h: [bold Cyan][bold white]{retu['h']}[/bold white] [bold magenta](m^2/s)[/bold magenta]\n[bold yellow]##/()\##[/bold yellow]\n'''

                        console.print(prin_t)

                    time.sleep(1)



                except KeyboardInterrupt:
                    console.print('[bold red]KEYBOARD INTERRUPT[/bold red]')
                    sys.exit(0)

        if name and tble and lp==None:
            '''prints table to terminal'''

            vallues = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'CERES':1681,'JUPITER':4333,'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174}

            X = None







        




