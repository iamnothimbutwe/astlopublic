from .interface import term


if __name__ == '__main__':
    term()
