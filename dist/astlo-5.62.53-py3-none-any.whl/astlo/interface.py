# the command line interface for the engine

# Copyright © 2026 Mark Macharia[@iamnothimbutwe Github]
# All rights reserved.

# Unauthorized copying, modification, distribution, or commercial use of this software (or substantial portions of it) is strictly prohibited without express written permission from the author.

import click
from .astlo import Astro
from .contin import Contin

# ---------------------------------------------------------
# Copyright (c) 2026 Mark. All rights reserved.
# Unauthorized copying of this file, via any medium, is
# strictly prohibited. Written by Mark (iamnothimbutwe) on Github.
# ---------------------------------------------------------


email='markmacgh@gmail.com/hecateare@gmail.com'


@click.group()
#@click.option(help='in some calculations, only one mass is required.you can use either of the --mass/--Mass options.In other calculations both the masses are required therefore use the two options --mass/--Mass respectively')
@click.option('--tble',default=None,help='if not None, a table containing values of the solar system will be printed to the console')
@click.version_option(version=f'v5.62.53 ..astlo A Real-time and still developing astrophysics/celestial orbital mechanics engine\ndeveloper: @iamnothimbutwe/me on Github and Gitlab/Macharia. 2026\nemail = {email}')
@click.pass_context
def term(ctx,tble):
    ctx.obj=Astro(tble)
    ctx.obj=Contin()



@term.command()
@click.option('--velocity',default=1,help='the velocity of the object in space. Use the SI unit m/s',type=float)
@click.option('--distance',default=1,help='the distance between the two objects in space. Use the SI unit m',type=float)
@click.option('--mass',default=1,help='the Mass of the smaller mass. Use the SI unit kg',type=float)
@click.option('--ass',default=1,help='the Mass of the larger mass. Use the SI unit kg',type=float)
@click.option('--o_p',default=1,help='the orbital period of the planet if known.',type=float)
@click.pass_obj
def harmonic(astro,velocity,distance,mass,ass,o_p):
    astro.harmonic(velocity,distance,mass,ass,o_p)


@term.command()
@click.option('--r_a',default=1,help='apside value (aphelion) which is the maximum distance from the sun',type=float)
@click.option('--r_p',default=1,help='apside value (perihelion) which is the minimum distance from the sun',type=float)
@click.option('--tble',default=None,help='if not None, a table containing values of the solar system will be printed to the console')
@click.pass_obj
def eccent(astro,r_a,r_p,tble):
    astro.eccent(r_a,r_p,tble)
    if tble:
        astro.tebl()


@term.command()
@click.option('--k_e',default=1,help='kinetic energy value',type=float
)
@click.option('--p_e',default=1,help='potential energy value',type=float)
@click.option('--distance',default=1,help='distance between the two object or masses. Mostly the sun and the orbiting object a in AU',type=float)
@click.option('--mass',default=1,help='the mass of the smaller mass',type=float)
@click.option('--ass',default=1,help='the mass of the larger Mass',type=float)
@click.option('--tble',default=None,help='if not None, a table containing values will be printed to the console')
@click.pass_obj
def energy(astro,k_e,p_e,mass,ass,distance,tble):
    astro.energy(k_e,p_e,mass,ass,distance,tble)
    if tble:
        astro.tebl()


@term.command()
@click.option('--proper_time',default=1,help='for the stationary object at or near the surface of the mass',type=float)
@click.option('--coordinate_time',default=1,help='for the distant stationary object where space time is flat',type=float)
@click.option('--mass',default=1,help='the mass of the Mass',type=float)
@click.option('--distance',default=1,help='the distance from the center of the Mass to the stationary object at or near the surface of the mass',type=float)
@click.pass_obj
def timee(astro,mass,distance,coordinate_time,proper_time):
    astro.timee(mass,distance,coordinate_time,proper_time)


@term.command()
@click.option('--parallax',default=1,help='the value of the parallax angle',type=float)
@click.option('--distance',default=1,help='the distance in meters if it is the only value available',type=float)
@click.option('--light_years',default=1,help='the value of light years if it is the only value available',type=float)
@click.pass_obj
def distance(astro,parallax,distance,light_years):
    astro.distance(parallax,distance,light_years)


#@term.command()
#@click.option('--days_elapsed',default=0,help='the number of days elapsed since the epoch',type=int)
#@click.option('--period',default=-1,help='the period in days for the planet. Use int as the number type',type=int)
#@click.option('--planet',default=None,help='the object value 1 for Mercury\n2 for Venus\n3 for Earth\n4 for Mars\n5 for Ceres \n6 for Jupiter\n7 for Saturn\n8 for Uranus\n9 for Neptune\n10 for Pluto\n11 for Eris.',type=int)
#@click.option('--eccentric',default=None,help='giving a value to this will activate eccentric orbits')
#@click.option('--plx',default=None,help='giving a value to this will activate plotting directly on the terminal')
#@click.pass_obj
#def orbit(astro,days_elapsed,period,planet,eccentric,plx):
 #   astro.orbit(days_elapsed,period,planet,eccentric,plx)


#@term.command()
#@click.option('--plx',default=None,help='giving a value to this will activate plotting directly on the terminal')
#@click.option('--fcdts',default=None,help='giving a value to this will print a table on the terminal')
#@click.option('--name','-n',default=None,help='the name of the object. currently supports 16 objects in the solar sytem.',type=str)
#@click.option('--lp','-lp',default=None,help='if you want to get the coordinates in real time')
#@click.pass_obj
#def orbits(astro,plx,fcdts,name,lp):
    #astro.orbits(name,lp,fcdts,plx)

@term.command
@click.option('--name','-n',default=None,help='the name of the object. currently supports 16 objects in the solar system.',type=str)
@click.option('--lp','-lp',default=None,help='if you want to get the state vectors and other values in real time')
@click.pass_obj
def rtime(contin,name,lp):
    contin.rtime(name,lp)


@term.command
@click.option('--name','-n',default=None,help='the name of the celestial object. currently, animating supports 11 objects',type=str)
@click.option('--rt','-r',default=None,help='givimg a value to this will print a one time true real time plot to the terminal. supports all 16 objects')
@click.pass_obj
def anmte(contin,name,rt):
    contin.anmte(name,rt)




