# ---------------------------------------------------------
# Copyright (c) 2026 Mark. All rights reserved.
# Unauthorized copying of this file, via any medium, is
# strictly prohibited. developed by Mark Macharia [iamnothimbutwe] on Github.
# ---------------------------------------------------------


#import time
from rich.console import Console
#from rich.table import Table
from .vect import Vectors
import numpy as np
import math
from .contin import Contin


vect = Vectors()
console=Console()

class Lsim(Contin):
    '''THE LAUNCH SIMS CORE ENGINE'''

    def __init__(self): #name of reocket 👀
        #self.rocketname = rocketname
        super().__init__()
        self.Merlin_space_X_engine = {'thrust_sea_level':845000,'si_thrust':'N','SI_thrust':'N Newtons','spec_impulse_slevel':282,'si_spimp':'s','SI_spimp':'s seconds','spec_impulse_vcm':311,'dry_mass':470,'si_drymass':'kg','name':'Merlin SpaceX Engine 1D'} #the ones to follow should use the same format
        self.sup = {'m_sx':self.Merlin_space_X_engine} #the supoorted engine
        self.g_zero = 9.80665 # m/s2
        self.TWR_standard = 1.3
        self.atm_density_at_0 = 1.225 #kg/m3
        self.H = 8500 #meters the charac height over wich the earths atmsph press and density drop by a factor of e~2.718
        self.H_e = 2.718





    def wetmass(self,supported: str=None,thrust_slevel=None,twr=1.3,isp_slevel=None,number_of_engines: int=1): #supported for suppted engines, twr thrust to weight ratio at 1.3 industry standard, supported if not None is the code word for the supted Engine...assumes values 
        '''gets the wet mass and the mass flow ratio of the rocket at launch using the standard 1.3 thrust to weight ratio. Assumes values enetered are at sea level. the mass flow rate assumes full throttle. default value for the number of engines is 1'''

        if supported==None and thrust_slevel==None and isp_slevel==None:
            console.print('[bold red]choose one between a supported engine and one of your own')
            return


        if supported==None and thrust_slevel and isp_slevel:
            pass

        if supported==None and thrust_slevel and isp_slevel==None:
            console.print('[bold red]engine thrust at sea level not given[/bold red]')
            return
        if supported==None and thrust_slevel==None and isp_slevel:
            console.print('[bold red]engine specific impulse at sea level not given[/bold red]')
            return

        if (supported and thrust_slevel) or (supported and isp_slevel) or (supported and thrust_slevel and isp_slevel):
            console.print('[bold red]choose one between a supported engine and one of your own[/bold red]')
            return

        if number_of_engines<1:
            return 'cannot have zero engines'


        #try:

         #   thrust_slevel = float(thrust_slevel) #if error arises due to none number then automatically will handle it
        #    isp_slevel = float(isp_slevel)
       #     twr = float(twr)
       # except ValueError:
      #      raise ValueError()





        if supported and thrust_slevel==None and isp_slevel==None:
            if supported in self.sup:
                engine = self.sup.get(supported,'ERROR') #returns the corrssponding engine

              #  if number_of_engines:
                wet_mass = ((engine['thrust_sea_level']*number_of_engines)/(twr*self.g_zero)) #kg what if i can add the number of engines tonincrease the thrust net at sea level then the wet mass will have to modulo twr = 1.3...
                mass_flow_rate = ((engine['thrust_sea_level']*number_of_engines)/((engine['spec_impulse_slevel']*number_of_engines)*self.g_zero)) #kg/s...if runs at full throttle, this is the mass flow rate per second


            else:
                console.print('[bold red]Wrong spelling or engine not supported[/bold red]')
                return


            return {'rocket_wet_mass':wet_mass,'mass_flow_rate':mass_flow_rate,'si':'kg and kg/s','TWR_used':twr,'engine_thrust_slevel_N':engine['thrust_sea_level'],'engine_isp_slevel_s':engine['spec_impulse_slevel'],'engine_name':engine['name'],'engine_count':number_of_engines}

# i dont even have to write blocks to check if supported==None then do... straight to the poijt because if the return statememt is not reacged then supported is none then move on.
        
        try:

            thrust_slevel = float(thrust_slevel) #if error arises due to none number then automatically will handle it
            isp_slevel = float(isp_slevel)
            twr = float(twr)
        except ValueError:
                raise ValueError()


        ##if non supported wngine##
        wet_mass = (thrust_slevel*number_of_engines/(twr*self.g_zero)) #kg
        mass_flow_rate = ((thrust_slevel*number_of_engines)/((isp_slevel*number_of_engines)*self.g_zero))

        return {'engine_name':'Aslo','rocket_wet_mass':wet_mass,'mass_flow_rate':mass_flow_rate,'engine_thrust_slevel_N':thrust_slevel,'TWR_used':twr,'engine_isp_slevel_s':isp_slevel,'si':'kg and kg/s','engine_count':number_of_engines}




    def launch(self):
        '''Should invlove a logic that acts as a laucnh button'''
        pass

    
    def netacc(self,rocket_state=None,frame='2D',pitch: float=0):
        '''gets the net acceleration vector acting on the rocket'''

        if rocket_state==None:
            return 'rocket state is none'

        if not isinstance(rocket_state,tuple):
            return f'expected tuple object instead got: {rocket_state}'
        if len(rocket_state)!=7: #rx,ry,vx,vy,mcurrent mass,mass flow rate, ISP for rocket..multiply bh the number of engiens b4 passing the tuple object
            return f'expected a 7 object tuple for rocket_state instead got: {len(rocket_state)}'


        mass_flow_rate = rocket_state[5]#kg/s
        isp_rocket = rocket_state[6]
        #thrust#
        acc_thrust_x = ((mass_flow_rate*self.g_zero*isp_rocket)/rocket_state[4])*(np.sin(pitch))#assumes the last index 5 is mass flow rate for engine. x
        acc_thrust_y = ((mass_flow_rate*self.g_zero*isp_rocket)/rocket_state[4])*(np.cos(pitch)) #y

        thrust_acc_vector = np.array([acc_thrust_x,acc_thrust_y]) #perifocal first

        #grav#
        current_posmagnfrom_geocenter = math.sqrt(math.pow(rocket_state[0],2)+math.pow(rocket_state[1],2))
        acc_grav_x = -((self.G*self.MoE_kg)/math.pow(current_posmagnfrom_geocenter,3))*rocket_state[0] #projected to x axis
        acc_grav_y = -((self.G*self.MoE_kg)/math.pow(current_posmagnfrom_geocenter,3))*rocket_state[1] #projected to y axis.
        grav_acc_vector = np.array([acc_grav_x,acc_grav_y])

        #drag#
        air_density_p_h = atm_density_at_0*(self.H_e**(-(current_posmagnfrom_geocenter/self.H)))
        curent_v_magn = math.sqrt(math.pow(rocket_state[2],2)+math.pow(rocket_state[3],2))
        ballistic_coef = (rocket_state[4]/())
        acc_drag_magn = air_density_p_h*000

        pass

    def rocket_state_updater(self):
        '''updates the rocket pos, vel, current mass, mass flow rate and the specific impulse of the rocket engines.'''
        pass



    def trie(self,rocket_det=None): #the wetmass method allows rough rocket buidling..the final wetmass is the maximum possible mass those engines can lift at 100% throttle - so you can play around with the number..
        '''rocket launch to orbit insertion simulation'''

        if not isinstance(rocket,dict):
            console.print('[red]method trie in Lsim expected a wetmass-dictionary object from the wetmass metho[/red]')
            return 'method trie in Lsim expected a wetmass-dictionary object from the wetmass method.'

        while True:
            print('The following questions are required to determine the maximum wetmass that can be lifted with your desired engine configuration.\nPress any key to continue')
            any_key = input()
            if any_key:
                break

        noe = input('\nNumber of engines: ')
        engine_name = input('Name of engine: ')
        twr = input('Desired Thrust to weight ratio: ')

        print('\n\n')
        






