##matplotlib and numpy##

import matplotlib
from rich.console import Console

console=Console()

#matplotlib.use('TkAgg')

try:
    matplotlib.use('TkAgg')
    console.print('[bold Cyan]Using TkAgg backend.[/bold Cyan]')
except ImportError:
    # If TkAgg fails, let Matplotlib pick the best available backend automatically
    console.print('[bold red]Warning: Tkinter not found. Falling back to default backend.[/bold red]')
    pass 

#import matplotlib.pyplot as plt

from .astlo import Astro
from .contin import Contin
from .vect import Vectors
from rich.console import Console
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import StrMethodFormatter
import time
import plotext as pl
import json

##matplotlib uses specific geometric markers not like plotext##


astro = Astro()
contin = Contin()
vectors = Vectors()
#console = Console()


class Mat:
    def __init__(self):
        self.mission = 'to make astrophysiscs and the universe available to anyone with just a phone or a terminal without needing heavy libraries or the internet.'
        self.working = 'uses the TkAgg X-11 friendly backend'
        self.frames = ('2D','3D')

    def matpt(self,name: str=None,baryc=None):
        '''the 3D projections..orbit supported 11 objects plotting. i will update'''

        if name==None:
            console.print('[bold red]NAME CANNOT BE NONE OR EMPTY[/bold red]')
            return ##IDE friendly..
        name = name.upper()

        vallues = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'CERES':1681,'JUPITER':4333,'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174}

        if name not in vallues.keys():
            console.print('[bold red]NAME NOT LOCALLY RECOGNIZED FOR VISUALIZATIONS OR WRONG SPELLING\nSUPPORTS PLOTTING 11 OBJECTS AS OF NOW[/bold red]')
            return

        vallues_1 = {'MERCURY':'red','VENUS':'yellow','EARTH':'blue','MARS':'red','CERES':'grey','JUPITER':'grey','SATURN':'grey','URANUS':'cyan','NEPTUNE':'blue','PLUTO':'grey','ERIS':'red','HAUMEA':'grey','MAKEMAKE':'grey','HYGIEA':'grey','VESTA':'grey','PALLAS':'grey'} #mat uses specific geometric markers use the colors in the dictionary

        if baryc:
            pass


        #ret = astro.orbit(0,vallues.get(name,-2),None,'y')
        ret = contin.reel(name) # heliocentric frame
        reti = contin.barycentric(name)
        tro = astro.orbit(0,int(vallues.get(name,'ERROR')),None,'y')


        py_list = []
        for _,idx in enumerate(ret['X_helioAU']):
            g = [idx,ret['Y_helioAU'][_],ret['Z_helioAU'][_]]
            py_list.append(g)

        array_np = np.array(py_list)
        X = array_np[:,0] #all rows first column
        Y = array_np[:,1] #second volumn
        Z = array_np[:,2]

        fig = plt.figure(figsize=(10,10))
        ax = fig.add_subplot(projection='3d') #maybe the 111 was kinda makingit render one small box square quadrant

        ax.plot(tro['x_list_peri'],tro['y_list_peri'],color='cyan',alpha=0.4,linewidth=0.7,label='2D orbit')


        ##plot##
        ax.plot(X,Y,Z,color='magenta',label=name,linewidth=1.2)
        ax.scatter([0],[0],[0],s=300,marker='o',color='yellow',label='sun') #the heliocenter..heliocentric frame plotting
        ax.scatter([reti['X_helio']/contin.AU_m],[reti['Y_helio']/contin.AU_m],[reti['Z_helio']/contin.AU_m],s=100,marker='o',color=vallues_1.get(name,'ERROR'))

        ax.set_facecolor('darkgrey')
        fig.patch.set_facecolor('darkgrey')

        #hide the grey grid lines
        ax.xaxis.pane.fill = False
        ax.yaxis.pane.fill = False
        ax.zaxis.pane.fill = False #obviously if not fals then default is true .?..maybe

        #the numbers to be int,float with how many decimal places.
        au_f = StrMethodFormatter('{x:.2f}AU')
        ax.xaxis.set_major_formatter(au_f)
        ax.yaxis.set_major_formatter(au_f)
        ax.zaxis.set_major_formatter(au_f)


        ##tick labels the numbers formatter##
        ax.tick_params(axis='x',color='white')
        ax.tick_params(axis='y',color='white')
        ax.tick_params(axis='z',color='white')

        ax.set_xlabel('x_AU',color='magenta')
        ax.set_ylabel('y_AU',color='magenta')
        ax.set_zlabel('z_AU',color='magenta')
        ax.set_box_aspect([1,1,1])
        ax.set_title(f'{name}-Unix time: {reti['Unix_time']}//{time.asctime().replace(':','t')} Heliocentric',color='green')

        #save file

        output_save = f'{name}-Unix time: {reti['Unix_time']} or {time.asctime().replace(':','t')} Heliocentric.png'
        plt.savefig(output_save,facecolor=fig.get_facecolor(),dpi=300)

        console.print(f'\n[bold Cyan]3D visualization rendered to {output_save} [/bold Cyan]\n')

        return plt


        #plt.show() # save the image instead of the mainloop to show one state.


    def fulplot(self,jview=None,inview=None):
        '''plots all of the orbits in one instance'''

        vallues = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'CERES':1681,'JUPITER':4333,'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174}

        if jview and inview:
            return 'cannot pass values to both jview and innview at the same time. use one solely.'

        flx_list = []
        fly_list = []
        flz_list = [] #ill only append the live orbital plots and live positions
        psx_list = []
        psy_list = []
        psz_list = []
        fl_listx = []
        fl_listy = []
        fl_listz = []

        fl_ps = []

        #tro = astro.orbit(0,int(vallues.get('ERIS','ERROR')),None,'y')



        for _ in vallues.keys():
            reel = contin.reel(_) #heliocentric
            ps = contin.barycentric(_)
            flx_list.append(reel['X_helioAU'])
            fly_list.append(reel['Y_helioAU'])
            flz_list.append(reel['Z_helioAU'])
            psx_list.append(ps['X_helio'])
            psy_list.append(ps['Y_helio'])
            psz_list.append(ps['Z_helio'])

        


        ##Numpy and matplotlib##

        for _,idx in enumerate(flx_list): #the array has a shape of 11, big number maybe😑..
            array_npfx = np.array(idx)
            array_npfy = np.array(fly_list[_])
            array_npfz = np.array(flz_list[_]) #maybe this part wasnt needed the sho7ld have just turned the raw python list into an array instead of the for iteration

            fl_listx.append(array_npfx)
            fl_listy.append(array_npfy)
            fl_listz.append(array_npfz)

        px = np.array(psx_list)
        py = np.array(psy_list)
        pz = np.array(psz_list)



        fig = plt.figure(figsize=(10,10))
        ax = fig.add_subplot(projection='3d')

            

        #ax.plot(tro['x_list_peri'],tro['y_list_peri'],color='cyan',alpha=0.4,linewidth=0.7,label='2D ORBIT')
        ax.scatter([0],[0],[0],s=400,color='yellow',marker='o',label='sun')

        vallues_1 = {'MERCURY':'magenta','VENUS':'yellow','EARTH':'blue','MARS':'darkred','CERES':'darkgrey','JUPITER':'lightgrey','SATURN':'black','URANUS':'lightblue','NEPTUNE':'darkblue','PLUTO':'red','ERIS':'magenta','HAUMEA':'grey','MAKEMAKE':'grey','HYGIEA':'grey','VESTA':'lightgrey','PALLAS':'black'}
        vallues_C = {'MERCURY':'MERCURY','VENUS':'VENUS','EARTH':'EARTH','MARS':'MARS','CERES':'CERES','JUPITER':'JUPITER','SATURN':'SATURN','URANUS':'URANUS','NEPTUNE':'NEPTUNE','PLUTO':'PLUTO','ERIS':'ERIS','HAUMEA':'HAUMEA','MAKEMAKE':'MAKEMAKE','HYGIEA':'HYGIEA','VESTA':'VESTA','PALLAS':'PALLAS'}
        vallues_j = {'MERCURY':'MERCURY','VENUS':'VENUS','EARTH':'EARTH','MARS':'MARS','CERES':'CERES','JUPITER':'JUPITER'} #was using this as vallues_j but then all obiects can now be plotted.. so i updated the below dictionary for jupview..THUS dictionary is still used by innview option.
        vallues_jupview = {'MERCURY':'MERCURY','VENUS':'VENUS','EARTH':'EARTH','MARS':'MARS','VESTA':'VESTA','CERES':'CERES','PALLAS':'PALLAS','HYGIEA':'HYGIEA','JUPITER':'JUPITER'}
        

        if jview and inview==None: #updated it to use astlo.orbits with fcdts option..
            tro = astro.orbit(0,int(vallues.get('JUPITER','ERROR')),None,'y')
            
            ax.plot(tro['x_list_peri'],tro['y_list_peri'],color='cyan',alpha=0.4,linewidth=0.7,label='2D Jupiter ORBIT')

            for _,t in enumerate(vallues_jupview):
                full = astro.orbits(t,'y',None,'y')
                current = contin.barycentric(t)
            #    ax.plot(fl_listx[_],fl_listy[_],fl_listz[_],color=vallues_1.get(t,'ERROR'),linewidth=1.3)#label=vallues_C.get(t,'ERROR'))
                ax.plot(full['X_AUheliolist'],full['Y_AUheliolist'],full['Z_AUheliolist'],color=vallues_1.get(t,'ERROR'),linewidth=1.3)
                ax.scatter([current['X_helio']/contin.AU_m],[current['Y_helio']/contin.AU_m],[current['Z_helio']/contin.AU_m],color=vallues_1.get(t,'ERROR'),marker='o',label=vallues_C.get(t,'ERROR'))


            ax.set_facecolor('darkgrey')
            fig.patch.set_facecolor('darkgrey')


            #hide the grey grid line

            ax.xaxis.pane.fill = False
            ax.yaxis.pane.fill = False
            ax.zaxis.pane.fill = False #obviously if not fals then default is true .?..maybe

            #the numbers to be int,float with how many decimal places.

            au_f = StrMethodFormatter('{x:.2f}AU')
            ax.xaxis.set_major_formatter(au_f)
            ax.yaxis.set_major_formatter(au_f)
            ax.zaxis.set_major_formatter(au_f)

            ##tick labels the numbers formatter##

            ax.tick_params(axis='x',color='white')
            ax.tick_params(axis='y',color='white')
            ax.tick_params(axis='z',color='white')
            ax.set_xlabel('x_AU',color='magenta')
            ax.set_ylabel('y_AU',color='magenta')
            ax.set_zlabel('z_AU',color='magenta')
            ax.set_box_aspect([1,1,1])

            ax.set_title(f'Jupiter and inner planets plot - Unix time: {ps['Unix_time']}//{time.asctime().replace(':','t')} Heliocentric',color='green')

            #save file

            output_save = f'Jupiter and inner planets plot - Unix time: {ps['Unix_time']} or {time.asctime().replace(':','t')} Heliocentric.png'
            plt.savefig(output_save,facecolor=fig.get_facecolor(),dpi=300)
            console.print(f'\n[bold Cyan]3D visualization rendered to {output_save} [/bold Cyan]\n')


            return plt

        if inview and jview==None:
            tro = astro.orbit(0,int(vallues.get('MARS','ERROR')),None,'y')
            ax.plot(tro['x_list_peri'],tro['y_list_peri'],color='cyan',alpha=0.4,linewidth=0.7,label='2D Mars Orbit')

            for _,t in enumerate(vallues_j):
                if t=='JUPITER':
                    continue
                ax.plot(fl_listx[_],fl_listy[_],fl_listz[_],color=vallues_1.get(t,'ERROR'),linewidth=1.3)
                ax.scatter([px[_]/contin.AU_m],[py[_]/contin.AU_m],[pz[_]/contin.AU_m],color=vallues_1.get(t,'ERROR'),marker='o',label=vallues_C.get(t,'ERROR'))


            ax.set_facecolor('darkgrey')
            fig.patch.set_facecolor('darkgrey')


            #hide the grey grid line

            ax.xaxis.pane.fill = False
            ax.yaxis.pane.fill = False
            ax.zaxis.pane.fill = False #obviously if not fals then default is true .?..maybe                                                                                    
            #the numbers to be int,float with how many decimal places.

            au_f = StrMethodFormatter('{x:.2f}AU')
            ax.xaxis.set_major_formatter(au_f)
            ax.yaxis.set_major_formatter(au_f)
            ax.zaxis.set_major_formatter(au_f)                                          
            ##tick labels the numbers formatter##

            ax.tick_params(axis='x',color='white')
            ax.tick_params(axis='y',color='white')
            ax.tick_params(axis='z',color='white')
            ax.set_xlabel('x_AU',color='magenta')
            ax.set_ylabel('y_AU',color='magenta')
            ax.set_zlabel('z_AU',color='magenta')
            ax.set_box_aspect([1,1,1])

            ax.set_title(f'inner planets plot - Unix time: {ps['Unix_time']}//{time.asctime().replace(':','t')} Heliocentric',color='green')                                         
            #save file

            output_save = f'inner planets plot - Unix time: {ps['Unix_time']} or {time.asctime().replace(':','t')} Heliocentric.png'
            plt.savefig(output_save,facecolor=fig.get_facecolor(),dpi=300)

            console.print(f'\n[bold Cyan]3D visualization rendered to {output_save} [/bold Cyan]\n')

            return plt




        tro = astro.orbit(0,int(vallues.get('ERIS','ERROR')),None,'y')       

        ax.plot(tro['x_list_peri'],tro['y_list_peri'],color='cyan',alpha=0.4,linewidth=0.7,label='2D Eris ORBIT')

        name_l = [g for g in vallues_1.keys()]


        for _,idx in enumerate(fl_listx): #the multiple plots

            name = name_l[_]

            ax.plot(idx,fl_listy[_],fl_listz[_],color=vallues_1.get(name,'ERROR'),linewidth=1.3,label=vallues_C.get(name,'ERROR'))
            ax.scatter([px[_]/contin.AU_m],[py[_]/contin.AU_m],[pz[_]/contin.AU_m],s=120,color=vallues_1.get(name,'ERROR'),marker='o')


        ax.set_facecolor('darkgrey')
        fig.patch.set_facecolor('darkgrey')

        #hide the grey grid linne

        ax.xaxis.pane.fill = False
        ax.yaxis.pane.fill = False
        ax.zaxis.pane.fill = False #obviously if not fals then default is true .?..maybe

        #the numbers to be int,float with how many decimal places.

        au_f = StrMethodFormatter('{x:.2f}AU')
        ax.xaxis.set_major_formatter(au_f)
        ax.yaxis.set_major_formatter(au_f)
        ax.zaxis.set_major_formatter(au_f)
        
        ##tick labels the numbers formatter##

        ax.tick_params(axis='x',color='white')
        ax.tick_params(axis='y',color='white')
        ax.tick_params(axis='z',color='white')

        ax.set_xlabel('x_AU',color='magenta')
        ax.set_ylabel('y_AU',color='magenta')
        ax.set_zlabel('z_AU',color='magenta')
        ax.set_box_aspect([1,1,1])
        ax.set_title(f'Fulplot - Unix time: {ps['Unix_time']}//{time.asctime().replace(':','t')} Heliocentric',color='green')

        #save file

        output_save = f'Fulplot - Unix time: {ps['Unix_time']} or {time.asctime().replace(':','t')} Heliocentric.png'
        plt.savefig(output_save,facecolor=fig.get_facecolor(),dpi=300)

        console.print(f'\n[bold Cyan]3D visualization rendered to {output_save} [/bold Cyan]\n')


        return plt








    def pin(self,name: str=None,view='2D',jupview=None,innerview=None,fullview=None,days: float=None):
        '''Geocentric plots 2D and 3D, full 2D solarsystem view..jupiter inner view..inner planets only view. returns plotext objects. use the days positional argument if you want to see the state of the solar system x days into the future or past.'''

        if name:
            name = name.upper()


        if (jupview and innerview) or (jupview and fullview) or (innerview and fullview) or (jupview and innerview and fullview):
            console.print('[red]choose one between jupiter and inner objects and full view or the innerview only but not both/all at the same time[/red]')
            return

        if name=='EARTH':
            console.print('[red]Name cannot be Earth for this method[/red]')
            return
        
        try:
            if days:
                days = float(days)
        except ValueError:
            raise ValueError(f'days value passed is not supported: {days}')

##cannot check name because jupivuew and inner view can run without name
        lst = ['3D','2D']
        vallues = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'CERES':1681,'JUPITER':4333,'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174}

        vallues_1 = {'MERCURY':'magenta','VENUS':'yellow','EARTH':'blue','MARS':'darkred','CERES':'darkgrey','JUPITER':'lightgrey','SATURN':'black','URANUS':'lightblue','NEPTUNE':'darkblue','PLUTO':'red','ERIS':'magenta'}
        vallues_j = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'VESTA':1326,'CERES':1681,'PALLAS':1687,'HYGIEA':2031,'JUPITER':4333,'APOPHIS':324,'BENNU':437,'EROS':643}#'HALLEY':27511,'APOPHIS':324}#'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174}
        vallues_jjj = ('MERCURY','VENUS','EARTH','MARS','VESTA','CERES','PALLAS','HYGIEA','JUPITER','APOPHIS','BENNU','EROS')

        vallues_C = {'MERCURY':'MERCURY','VENUS':'VENUS','EARTH':'EARTH','MARS':'MARS','VESTA':'VESTA','CERES':'CERES','PALLAS':'PALLAS','HYGIEA':'HYGIEA','JUPITER':'JUPITER','SATURN':'SATURN','URANUS':'URANUS','NEPTUNE':'NEPTUNE','PLUTO':'PLUTO','ERIS':'ERIS','HALLEY':'HALLEY','APOPHIS':'APOPHIS','BENNU':'BENNU','EROS':'EROS'}

        view = view.upper()



        while view not in lst:
            console.print(f'[white]first argument ¦view¦ only accepts 2D or 3D.[/white]\nit was given: {view}.')
            return

        if view=='3D': #Geocentric view in 3D

            fig = plt.figure(figsize=(10,10))
            ax = fig.add_subplot(projection='3d')

            retu = contin.barycentric('Earth')
            retur = contin.barycentric(name)
            efull = contin.reel('EARTH')
            othfull = contin.reel(name) #heliocentric



            ##the 2D orbit decider based on distance##
            if vallues[name]>vallues['EARTH']:
                tro = astro.orbit(0,int(vallues.get(name,'ERROR')),None,'y')
            else:
                tro = astro.orbit(0,int(vallues.get('EARTH','ERROR')),None,'y')


            np_efull_X = np.array(efull['X_helioAU'])
            np_efull_Y = np.array(efull['Y_helioAU'])
            np_efull_Z = np.array(efull['Z_helioAU'])
            np_othfull_X = np.array(othfull['X_helioAU'])
            np_othfull_Y = np.array(othfull['Y_helioAU'])
            np_othfull_Z = np.array(othfull['Z_helioAU'])



            #e2d = astro.orbit(0,int(vallues.get('EARTH','ERROR')),None,'y')

            #tro = astro.orbit(0,int(vallues.get(name,'ERROR')),None,'y')
            ax.plot(tro['x_list_peri'],tro['y_list_peri'],color='cyan',alpha=0.4,linewidth=0.7,label='2D orbit')
            ax.scatter([0],[0],[0],s=150,color='yellow',marker='o',label='sun')

            ax.plot(np_efull_X,np_efull_Y,np_efull_Z,color=vallues_1.get('EARTH','ERROR'),linewidth=1.3) #Earth plot
            ax.scatter([retu['X_helio']/contin.AU_m],[retu['Y_helio']/contin.AU_m],[retu['Z_helio']/contin.AU_m],color=vallues_1.get('EARTH','ERROR'),s=80,marker='o',label=vallues_C.get(name,'ERROR')) #Earth scatter
            ax.plot(np_othfull_X,np_othfull_Y,np_othfull_Z,color=vallues_1.get(name,'ERROR'),linewidth=1.3)
            ax.scatter([retur['X_helio']/contin.AU_m],[retur['Y_helio']/contin.AU_m],[retur['Z_helio']/contin.AU_m],color=vallues_1.get(name,'ERROR'),s=30,marker='o',label=vallues_C.get(name,'ERROR'))


            ax.set_facecolor('darkgrey')
            fig.patch.set_facecolor('darkgrey')                                         

            #hide the grey grid line
            ax.xaxis.pane.fill = False
            ax.yaxis.pane.fill = False
            ax.zaxis.pane.fill = False #obviously if not fals then default is true .?..maybe
            #the numbers to be int,float with how many decimal places.

            au_f = StrMethodFormatter('{x:.2f}AU')
            ax.xaxis.set_major_formatter(au_f)
            ax.yaxis.set_major_formatter(au_f)
            ax.zaxis.set_major_formatter(au_f)

            ##tick labels the numbers formatter##

            ax.tick_params(axis='x',color='white')
            ax.tick_params(axis='y',color='white')
            ax.tick_params(axis='z',color='white')
            ax.set_xlabel('x_AU',color='magenta')
            ax.set_ylabel('y_AU',color='magenta')
            ax.set_zlabel('z_AU',color='magenta')
            ax.set_box_aspect([1,1,1])

            ax.set_title(f'Geocentric {vallues_C.get(name,'ERROR')} plot - Unix time: {retur['Unix_time']}//{time.asctime().replace(':','t')} Heliocentric',color='green')
            #save file

            output_save = f'Geocentric {vallues_C.get(name,'ERROR')} plot - Unix time: {retur['Unix_time']} or {time.asctime().replace(':','t')} Heliocentric.png'
            plt.savefig(output_save,facecolor=fig.get_facecolor(),dpi=300)

            console.print(f'\n[bold Cyan]3D visualization rendered to {output_save} [/bold Cyan]\n')

            return plt



        vallues_col = {'MERCURY':'darkgrey','VENUS':'yellow','EARTH':'blue','MARS':'darkred','VESTA':'red','CERES':'red','PALLAS':'red','HYGIEA':'red','JUPITER':'green','SATURN':'magenta','URANUS':'lightblue','NEPTUNE':'darkblue','PLUTO':'red','HAUMEA':'red','MAKEMAKE':'red','ERIS':'magenta'}
        vallues_mar = {'MERCURY':'m','VENUS':'V','EARTH':'E','MARS':'M','VESTA':'v','CERES':'c','PALLAS':'p','HYGIEA':'H','JUPITER':'j','SATURN':'s','URANUS':'u','NEPTUNE':'n','PLUTO':'P','HAUMEA':'h','MAKEMAKE':'m','ERIS':'e','HALLEY':'L','APOPHIS':'A','BENNU':'N','EROS':'R'}


        if jupview and view=='2D': #degault is 2D...i want the geocentric system in 2D to be the degault for tthis method if the pos arg are None..like if all argyments are None and name is enetered whule view is 2D then default shall be geicentric 2D system
         #   vallues_col = {'MERCURY':'darkgrey','VENUS':'yellow','EARTH':'blue','MARS':'darkred','VESTA':'red','CERES':'red','PALLAS':'red','HYGIEA':'red','JUPITER':'green','SATURN':'magenta','URANUS':'lightblue','NEPTUNE':'darkblue','PLUTO':'red','HAUMEA':'red','MAKEMAKE':'red','ERIS':'magenta'} #if hygiea or otger unsupported entered, nothing will happen
          #  vallues_mar = {'MERCURY':'m','VENUS':'V','EARTH':'E','MARS':'M','VESTA':'v','CERES':'c','PALLAS':'p','HYGIEA':'H','JUPITER':'j','SATURN':'s','URANUS':'u','NEPTUNE':'n','PLUTO':'P','HAUMEA':'h','MAKEMAKE':'m','ERIS':'e'}
            '''if days, the scatter points will be relative SSB'''

            X = []
            Y = []
            #Z = []
            fullX = []
            fullY = []
          #  fullZ = []
            names = []

            if days:
                rungekutta = contin.rungekutta(None,None,None,days) #placed itnoutside because i shoiod.not call it every iteration
               
            for idx,_ in enumerate(vallues_jjj): #if i want to see object x then i just eneter the terminal and edit this file..i stead of tweaking the function making it more complex..
                if days:
                    if _=='APOPHIS':
                        retu = rungekutta['new_pos_vectors'][18] #apophis is index 18 in the internal object tuple... doing this if statemnets because jjj does not follow the internal object indexes..only the mercury to jupiter...apophis,bennu and the othwrs to be added have to be handeled by if statements..
                    elif _=='BENNU':
                        retu = rungekutta['new_pos_vectors'][19] #or just use the supp_objs dictionary because _ is thevobjects name..
                    elif _=='EROS':
                        retu = rungekutta['new_pos_vectors'][20]
                    else:
                        retu = rungekutta['new_pos_vectors'][idx+1] #+1 becyaseb index 0 is Sol.
                    retur = astro.orbits(_,'y',None,'y')
                    X.append(retu[0]/contin.AU_m)
                    Y.append(retu[1]/contin.AU_m)
                    fullX.append(retur['X_AUheliolist'])
                    fullY.append(retur['Y_AUheliolist'])
                    names.append(retur['N'])
                else:
                    retu = contin.barycentric(_)
             #   retur = contin.reel(_) switching sides to astlo.orbits     
                    retur = astro.orbits(_,'y',None,'y') #supportes all the objects
                    X.append(retu['X_helio']/contin.AU_m)
                    Y.append(retu['Y_helio']/contin.AU_m)
                    # Z.append(retu['Z_helio']/contin.AU_m)
                    fullX.append(retur['X_AUheliolist'])
                    fullY.append(retur['Y_AUheliolist'])
                #    fullZ.append(retur['Z_helioAU'])
                    names.append(retu['name']) #contains respective name.




            pl.clf()
            width,height = pl.terminal_size()
            pl.plotsize(width,height)
       #     pl.scatter([0],[0],color='red',marker='B',label='SSB')

            for _,idx in enumerate(fullX): #fullX contains 6 lists..plus the added objects..

                pl.plot(fullX[_],fullY[_],color='white')#label=vallues_C.get(names[_],'ERROR'))
                pl.scatter([X[_]],[Y[_]],color=vallues_col.get(names[_],'ERROR'),marker=vallues_mar.get(names[_],'ERROR'),label=vallues_C.get(names[_],'ERROR')) #doesnt retyrn an error even uf vallues_colndoesmt contain some keys.m maybe color argumwnt defaults to the default?


            pl.xlabel('X-AU')
            pl.ylabel('Y-AU')

            if days:
                pl.title(f'Jupiter and inner objects at UTC-time:{rungekutta['utc_time']} + {days} days + 1_hour for rk4') #if days, then barycentric plots are used.
            else:
                pl.title(f'Jupiter and inner objects at UTC-time:{retu['utc_time']} Heliocentric') #heliocentric...
            pl.theme('dark')
            
            return pl
#placed thebrungekutta timestepping logic to jupview only becuaeebi am curenrlt building for myself not others yet. i know the logic and later if it is in demand, i know what to do.

        elif jupview and view=='3D':
            print('jupview works only with 2D in this method.')
            return 'jupview works only with 2D in this method.'



        if innerview and view=='2D':

            X = []
            Y = []
         #   Z = []
            fullX = []
            fullY = []
          #  fullZ = []
            names = []

            for _ in vallues_j.keys():
                if _=='JUPITER' or _=='CERES':
                    continue
                retu = contin.barycentric(_)
                retur = contin.reel(_)
                X.append(retu['X_helio']/contin.AU_m)
                Y.append(retu['Y_helio']/contin.AU_m)
                fullX.append(retur['X_helioAU'])
                fullY.append(retur['Y_helioAU'])
                names.append(retu['name'])


            pl.clf()
            width,height = pl.terminal_size()
            pl.plotsize(width,height)
            pl.scatter([0],[0],color='green',marker='S',label='SUN')

            for _,idx in enumerate(fullX):
                pl.plot(idx,fullY[_],color='white')

                pl.scatter([X[_]],[Y[_]],color=vallues_col.get(names[_],'ERROR'),marker=vallues_mar.get(names[_],'ERROR'),label=vallues_C.get(names[_],'ERROR'))
            
            pl.xlabel('Distance in AU')
            pl.ylabel('Distance in AU')
            pl.title(f'inner objects at Unix time: {retu['Unix_time']}//{time.asctime().replace(':','t')} Heliocentric')
            pl.theme('dark')
            
            return pl

        elif innerview and view=='3D':
            print('innerview only works with 2D in this method\n')
            return 'innerview only works with 2D in this method'




    def comesteroids(self,name: str=None,days: float=None,frame: str='2D'):
        '''returns a plotext object for the geocentric plots for any supported comet or asteroid that has a kind of influence over Earth. Eg if name is apophis, then the plot will contain the real-time positions of the objects in their orbits. if days is given a value, the plot will contain the positions of the objects after a timestep of ¦real-time + days¦ using a 4rth order integration rk4. supported frames is 2D and or 3D. asteroid Apophis and comets. basically focuses on visualizing NEO plus the comets becauee them too are visible fron earth. includes a scatter for Sol relative SSB'''
        if name==None:
            return 'name cannot be none'

        if frame.upper() not in self.frames:
            return f'passed frame {frame} is not supported'

        name = name.upper()

        if name=='EARTH': #shoild add mercury,venus and mars for best visualization.
            return 'Name cannot be Earth for this method'
        #apophis has a upcoming big thing..plus halley too..should add support for major comets.
        supported_objects = ('HALLEY','APOPHIS','BENNU','EROS') #add more supoort to astlo for the comets and asteroida..
        oth_objs = ('MERCURY','VENUS','EARTH','MARS') #should include this objects in the final plot for best visualization.

        if name not in supported_objects:
            return 'name not supported for comesteroids method in class Mat.'

        X = []
        Y = []
        X_full = []
        Y_full = []
        if days:
            rungekutta = contin.rungekutta(None,None,None,days) #from this returned object i can get the state vectors for any object X..so for the other objects in this method for comaptibilty, i can get their states from thsi objeft.
            retu = rungekutta['new_pos_vectors'][contin.supp_objs[name]] #the target.
        else:
            rungekutta = contin.rungekutta() #util8ze this rungekutta methid i created.
            retu = rungekutta['new_pos_vectors'][contin.supp_objs[name]]
        
    #    earth_st = astro.orbits('EARTH','y',None,'y')
        retur = astro.orbits(name,'y',None,'y') #for the target.

        for idx,itm in enumerate(oth_objs):
            nva = astro.orbits(itm,'y',None,'y')#nva stop. never stop..im telling myself to nwver stop.
        #    nvar = contin.barycentric() changed to use rungekutta
            X_full.append(nva['X_AUheliolist'])
            Y_full.append(nva['Y_AUheliolist'])

        for idx,itm in enumerate(oth_objs):
            others = rungekutta['new_pos_vectors'][idx+1]
            X.append(others[0]/contin.AU_m)
            Y.append(others[1]/contin.AU_m)

        vallues_col = {'MERCURY':'darkgrey','VENUS':'yellow','EARTH':'blue','MARS':'darkred','VESTA':'red','CERES':'red','PALLAS':'red','HYGIEA':'red','JUPITER':'green','SATURN':'magenta','URANUS':'lightblue','NEPTUNE':'darkblue','PLUTO':'red','HAUMEA':'red','MAKEMAKE':'red','ERIS':'magenta'}
        vallues_mar = {'MERCURY':'m','VENUS':'V','EARTH':'E','MARS':'M','VESTA':'v','CERES':'c','PALLAS':'p','HYGIEA':'H','JUPITER':'j','SATURN':'s','URANUS':'u','NEPTUNE':'n','PLUTO':'P','HAUMEA':'h','MAKEMAKE':'m','ERIS':'e','HALLEY':'L','APOPHIS':'A','BENNU':'N','EROS':'R'}
        vallues_C = {'MERCURY':'MERCURY','VENUS':'VENUS','EARTH':'EARTH','MARS':'MARS','VESTA':'VESTA','CERES':'CERES','PALLAS':'PALLAS','HYGIEA':'HYGIEA','JUPITER':'JUPITER','SATURN':'SATURN','URANUS':'URANUS','NEPTUNE':'NEPTUNE','PLUTO':'PLUTO','ERIS':'ERIS','HALLEY':'HALLEY','APOPHIS':'APOPHIS','BENNU':'BENNU','EROS':'EROS'}

        pl.clf()
        width,height = pl.terminal_size()
        pl.plotsize(width,height)
        pl.scatter([0],[0],color='green',marker='B',label='SSB') #im using rungekutta so yeah relatuve SSB
        pl.scatter([rungekutta['new_pos_vectors'][0][0]/contin.AU_m],[rungekutta['new_pos_vectors'][0][1]/contin.AU_m],color='yellow',marker='S',label='SOL') #scatter also the sun
        for idx,itm in enumerate(oth_objs): #for the static objects..
            pl.plot(X_full[idx],Y_full[idx],color='white')
            pl.scatter([X[idx]],[Y[idx]],color=vallues_col.get(itm,'error'),marker=vallues_mar.get(itm,'error'),label=vallues_C.get(itm,'error')) #remebrr plus one for compatibilty...Sol is at index 0..for rungekutta
        pl.plot(retur['X_AUheliolist'],retur['Y_AUheliolist'],color='cyan') #the target object being tracked shiuld have a diffrent color..choosed cyan
        pl.scatter([retu[0]/contin.AU_m],[retu[1]/contin.AU_m],color='red',marker=vallues_mar.get(name,'error'),label=vallues_C.get(name,'error'))
        pl.xlabel('X-AU')
        pl.ylabel('Y-AU')
        if days:
            pl.title(f'Near Earth Object: {name} at UTCtime: {rungekutta['utc_time']} + {days} days Barycentric')
        else:
            pl.title(f'Near Earth Object: {name} at UTCtime: {rungekutta['utc_time']} Barycentric') #Near Earth objevt.
        pl.theme('dark')

        return pl

#3D logic should just jump it to the start of this method.       

  #      pass




    def lunatrack(self,dimension: str='2D'):
        '''tracks Solar system objects true path as it orbits the central mass. The moons path as it orbits the Earth-moon-Barycenter.This method only shows the real time positions without showing their orbits. built specifically for Luna'''

     #   if name==None:
      #      return 'name cannot be none'

      #  name = name.upper()
        dy = ['2D','3D']


        if dimension not in dy:
            return 'dimension passed not supported'
        elif dimension!='2D': #the dy check is already implemented above...
            dimension = dimension.upper()
# do the earth circle plot here


       # if (name=='LUNAR' or name=='LUNA' or name=='MOON') and dimension=='2D': #best plus mercury becauee of their shor periods around their central masses..but focusing on luna..

        with open('import_states.json','r') as f:
            data = json.load(f)

        magn_r = vectors.magn_vect(data['states_list'][0])
        magn_v = vectors.magn_vect(data['states_list'][1])

        #gets the points for luna for a circular orbit
            
        pl.clf()
        width, height = pl.terminal_size()
        pl.plotsize(width,height)
        pl.scatter([0],[0],marker='EMB') #B is the EMB
        pl.xlabel('X axis Lunar real-time distance from EMB kme4')
        pl.ylabel('Y axis Lunar real-time distance from EMB kme4')
        pl.title(f'Lunar relative EMB UTCtime {data['UTCtime']} = {magn_r/1000} km, {magn_v/1000} km/s')
        pl.theme('dark') #this block lets the plotext object not to update everytime..jsing the same canvas but the plotting updates after every second..i will get back tonthe original logic later.
        #    while True:
         #       try:
                    
       #     pl.plot([data['states_list'][0][0]/1000],[data['states_list'][0][1]/1000],color='white')
        pl.scatter([data['states_list'][0][0]/10000000],[data['states_list'][0][1]/10000000],color='red',marker='L') #converted to m then also rsduced the magnitude by 10000km hence showed kme4

        return pl #needs some major work here...
        #    pl.show()
                 #   time.sleep(60)
                    
                #except KeyboardInterrupt:
                 #   raise KeyboardInterrupt('KeyboardInterrupt')




