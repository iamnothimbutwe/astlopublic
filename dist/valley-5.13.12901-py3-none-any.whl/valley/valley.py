import time
from rich.console import Console
from .mark import gem, ini # the vigenere cipher
#import click
import os
import platform
from importlib import resources
import sys
import random
import json

# ---------------------------------------------------------
# Copyright (c) 2026 Mark. All rights reserved.
# Unauthorized copying of this file, via any medium, is 
# strictly prohibited. Written by Mark (iamnothimbutwe) on Github.
# ---------------------------------------------------------



# interactive no hard coding

# This ensures it finds the version of todo.txt and recycle.txt that was installed
#BASE_DIR = os.path.dirname(os.path.abspath(__file__))  use this if the .txt files are in the root directory and also the __file__ is in the root directory and not in a subdirectory
#TODO_PATH = os.path.join(BASE_DIR, 'todo.txt')
#RECYCLE_PATH = os.path.join(BASE_DIR, 'recycle.txt')

console=Console()
email = 'astlospacesystems@gmail.com'

class Todo:
    '''a simple todo application.'''

    def __init__(self):

        #print('use "l" for Lower, "m" for Medium and "h" for High for the second function argument')

        # Path to package root ('valley')
        package_root = resources.files('valley')
        self.version = 'Valley v5.10.12901'

        self.add_file=package_root / 'todo.json'          #TODO_PATH
        self.deleted_file=package_root / 'recycle.json'      #RECYCLE_PATH
        self.recycled_file=package_root / 'recycled.json'    #RECYCLED_PATH
        self.setup_file=package_root / 'setup.json'    # the file that stores user settings and details..
        self.priorities={'l':'Lower','m':'Medium','h':'High'}
        #self.in_str=('0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15')

        #self.in_str = 500
        self.key_file = package_root / 'key.json'
        self.admin = package_root / 'admin.json'
        self.alpha = ('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z')
        self.numero = ('1','2','3','4','5','6','7','8','9','0')
        self.setup_reset = {'ciph_sett':None,'location_setting':None} #the available settings for user...


    def setu(self,bypass=None):
        '''the setup for user'''

        #console.print(f'{self.version}\n')
        #time.sleep(0.3)

        with open(self.setup_file,'r') as f:
           # lis_t = f.read().splitlines() #zeroth value holds the cipher setting
            lis_t = json.load(f)
           # f.close()

       # if len(lis_t)==0 or bypass: # bypass0woqqó fowr bypa1ssin1g the set setting. kinda look a resetup button
        if lis_t['ciph_sett']==None or bypass:

            if os.name=='nt':
                os.system('cls')
            else:
                os.system('clear')


            console.print('[bold Cyan]- Welcome to the valley setup.../[/bold Cyan]\n\n[bold white] Do you want to use the cipher as default over plain raw words?\n\nHowever the add command has an optional parameter to optionally use the cipher through a key of your like to encrypt your entries.\nRemember your key if key is used or entered manually.[/bold white]\n[bold red]Do not exit or KeyboardInterrupt this interface. Doing so will create runtime errors. Please wait for the setup interface to finish.[/bold red]\n')
            chk = ['Y','N']
            ans = console.input('[Y/n]: ').upper()
      #      ans = ans.upper()

            while ans not in chk: #it will even handoe the None case

                ##ans = console.input('[Y/n]: ')
                #ans = ans.upper()
                console.print(f'\n[bold red]Caps insensitive. use y/Y for Yes or n/N for No. given: {ans}')
                ans = input('[Y/n]: ').upper()
                #ans = ans.upper()

            if ans=='Y':
                console.print(f'\n[green]You chose {ans}: i will always run in encrypt mode from now. To undo please uninstall and reinstall or choose command settings to run setup again..\nrunning setup again does not delete your existing entries[/green]')
                time.sleep(5.5)
                cipher = True

            else:
                console.print(f'\n[cyan]You chose {ans}. i will always run in plain words ¦decrypted¦ mode.\nNo worries though.. The add command has the optional option ¦key¦ that lets you use the key to the cipher of your liking once for every entry chosen. You will have to remember it though[/cyan]')
                time.sleep(5.5)
                cipher = False
                


            #setup_is_done = True
            if cipher:
                lis_t['ciph_sett']=cipher
                with open(self.setup_file,'w',encoding='utf-8') as f: #it clears the whole file and rewrites new settings
                   # wrt = f.write('True\n')
                    lis_t['ciph_sett']=cipher
                    json.dump(lis_t,f,indent=4)
                  #  f.close()

             #   console.print(f'\n\n[bold white]Welcome to Valley: {self.version}[/bold white]')


         #       time.sleep(3)
            elif cipher==False:
                with open(self.setup_file,'w',encoding='utf-8') as f:
                  #  wrt = f.write('False\n') #when using please use .upper()/.lower()
                    lis_t['ciph_sett']=cipher
                    json.dump(lis_t,f,indent=4)
                  #  f.close()

            #    console.print(f'\n\n[bold white]Welcome to Valley: {self.version}[/bold white]')
             #   time.sleep(3)

        if lis_t['location_setting']==None:
            print('\ncontinuing to location setup.../\n') #keep on building everything..stick on the same shit..itballnstarted as bullshit now its growing into an actual immortal Bull.
            time.sleep(2)

        if lis_t['location_setting']==None or bypass:

            if os.name=='nt':
                os.system('cls')
            else:
                os.system('clear')

            console.print('[bold Cyan]- The valley user default location setup.../[/bold Cyan]\n\n[bold white]Valley reuires the default geodetic values. These geodetic values allow automation for valley-astlo intergration.\nValley will always use the passed geodetic values in any scenario that reauires them\n\nGeodetic values: latitude-North or South of equator, longitude-East or West of Equator, altitude in meters for Solar system objects and km for Earth orbiting satellites. Use a negative sign to indicate South¦West and leave signless if positive East¦North\n\nUse astlo for global geodetic-topocentric capability.\n\nFollow what the screen asks and enter the correct details.[/bold white]\n\n[bold red]Do not exit or KeyboardInterrupt this interface. Doing so will create runtime errors. Please wait for the setup interface to finish.[/bold red]\n')

            lste = ['User latitude','User longitude','User altitude']
            user_geodetic_values = []

            for i in lste:
                ans = float(console.input(f'[yellow]{i}: [/yellow]'))
                user_geodetic_values.append(ans)

            #i forgot tonopen and close this json filea..open read close then open manipulate..close
            with open(self.setup_file,'r') as f:
                dau = json.load(f)


            with open(self.setup_file,'w',encoding='utf-8') as file:
                lis_t['location_setting']=user_geodetic_values
                json.dump(lis_t,file,indent=4)

            console.print(f'\n\n[bold white]Welcome to Valley: {self.version}[/bold white]')
            time.sleep(3)





    def add_todo(self,key=None,priority='m'.lower(),restore=None):
        '''adds new todo'''

        self.setu()

        with open(self.setup_file,'r') as f:
         #   wrt = f.read().splitlines()
            wrt = json.load(f)
           # f.close()
        # if key is givwn a value, that value will act as the key used to encrypt howver this key should be remembred by the user. thebdefault is ..👀

        if wrt['ciph_sett']==True:
            ind = random.randint(1,16)
            randomkey = self.randomgen()

            with open(self.key_file,'r') as f:
                datarr = json.load(f)

            with open(self.key_file,'w',encoding='utf-8') as f: #saves the key used here for a log.
              #  keylst = f.read().splitlines()
               # keylst = json.load(f)
                datarr.append(randomkey['string_key'])
                json.dump(datarr,f,indent=4)
            #    f.close()
          #  newkey = ind - 1 # for compatiblyit with list indices that start from zero

           # key = keylst[newkey]  #the intial default key..i want it in furture tonchose randomyl from a rich data structure of posiible hard keys..##supports random key generation##
            key = randomkey['string_key']

        ###LAZIMA ITA SETUP SO SETUP FILE WILL ALWAYS CONTAIN A VALUE.####
        else:
            never = 'stop'


            ##if the user gives key a value, then it would always have been overridden by key_2 so Key....if setup file zeroth index is True, even if user manually passes a key, it will awalys be overr8den by the internal ones.
# if setup is set to encryptnas default then areyounwill always be the default key even if yoj guve key a valie while calling add fxn. if setup file zeroth is false, then the user can give their own version of thebkey


#in the json file, the writtem used_key==key will always shpw as key 'key' nomatter the one chosen by the user or the randonly selected one.


        if os.name=='nt':
            os.system('cls')
        else:
            os.system('clear')


        if restore:
            '''restores a deleted note/todo'''

         #   if os.name=='nt':
          #      os.system('cls')
           # else:
            #    os.system('clear')

            with open(self.deleted_file,'r') as fil_e:
             #   lis_t = fil_e.read().splitlines()
                lis_t = json.load(fil_e)
          #      fil_e.close()

               # console.print('[bold yellow]MAXIMUM ENTRIES TO RESTORE: {len(lis_t)}[/bold yellow]')                                            
            #console.print('[bold blue]\t\t   ...Deleted entries...[/bold blue]')
            #for index,itm in enumerate(lis_t):
             #   print(f'({index}) {itm}')
              #  print()

            while len(lis_t) != 1: #if contains one value, ghen it is absolutely the meaningless data that allows json file maipulation..
                resto = ''

                while resto != 'q':

                    if os.name=='nt':
                        os.system('cls')
                    else:
                        os.system('clear')


                    with open(self.deleted_file,'r') as fil_e:
                    #    lis_t = fil_e.read().splitlines()
                        lis_t = json.load(fil_e)
                  #      fil_e.close()

                    with open(self.add_file,'r') as f:
                        lst = json.load(f)

                    with open(self.recycled_file,'r') as f:
                        rec = json.load(f)
                        
                    with open(self.admin,'r') as f:
                        adm = json.load(f)


                    console.print(f'[bold yellow]Use the displayed index to select the target entry.\nMAXIMUM ENTRIES TO RESTORE: {len(lis_t)-1}[/bold yellow]') #-1 refer to delete methedo


                    console.print('[bold blue]\t\t   ...Deleted entries...[/bold blue]')
                    for index,itm in enumerate(lis_t):
                        if index==0:
                            continue #zeroth index contains meaningless data
                        print(f'({index}) {itm}')
                        print()

                    resto = input('Enter entry index to restore[q to quit]: ').lower()
                    time_resto = time.asctime()                       
                    while not resto.isdigit() and not resto.isalpha(): #special characters
                        console.print('[bold red]DO NOT USE SPECIAL CHARACTERS TO RESTORE OR DELETE AN ENTRY[/bold red]')
                        resto = input('Enter entry index to restore[q to quit]: ').lower()
                        time_resto = time.asctime()


                    if resto.isdigit():
                        resto = int(resto)

                    if resto in range(len(lis_t)) and resto!=0:
                        restored = lis_t.pop(int(resto))

                        with open(self.add_file,'w',encoding='utf-8') as fil_e: #was using recycle.txt
                           # fil_e.write(f'Time_restored={time_resto} --- {restored}\n')
                            dataa = {'restored':restored,'Time_restored':time_resto}
                            lst.append(dataa)

                            json.dump(lst,fil_e,indent=4)
                         #   fil_e.close()

                        with open(self.recycled_file,'w',encoding='utf-8') as fil_e:
                          #  fil_e.write(f'Time_restored={time_resto} --- {restored}\n')
                            dataa = {'restored':restored,'Time_restored':time_resto}
                            rec.append(dataa)
                            json.dump(rec,fil_e,indent=4)
                    #        fil_e.close()
                        with open(self.admin,'w',encoding='utf-8') as f:
                            dataa = {'restored':restored,'time_restored':time_resto}
                            adm.append(dataa)
                            json.dump(adm,f,indent=4)


                        with open(self.deleted_file,'w+',encoding='utf-8') as fil_e:
                        #    for item_r in lis_t:
                              #  fil_e.write(f'{item_r}\n')
                            json.dump(lis_t,fil_e,indent=4)
                        #    fil_e.close()

                        console.print('[bold green]..RESTORED..[/bold green]\n')
                        time.sleep(0.3)
                        #sys.exit(0) # i want the program to exit after it restores. if the user wants to add a note/Todo, they call the fucntion without the restore argument.

                console.print('[bold red]..QUIT..[/bold red]\n')
                sys.exit(0) #exits if 'q' is entered..but the loop would exit automatically without the sys.exit(0)


            console.print('[bold red]RECYCLE BIN IS EMPTY[/bold red]\n')
            sys.exit(0)  # program will exit if the deleted file is empty..without the sys.exit(0) the program would continue to the next line which i dont want.

        
        console.print('\n[bold red]The Maximum entries you can enter is 15[/bold red]\n')

        with open(self.add_file,'r') as fil_e:
           # lis_t=fil_e.read().splitlines()
            lis_t = json.load(fil_e)
         #   fil_e.close()

       # data_lst = []
       # data_lst.append(lis_t)

        if len(lis_t)==15:
            console.print('\n[bold blue]...Maximum [/bold blue][bold red]Number[/bold red] [bold blue]of items entered.Please finish or Delete some to add more...[/bold blue]\n')
            #delete_todo()
            sys.exit(0)
        
        if priority not in self.priorities.keys():
            console.print(f'[red]priority letter entered is not supported: {priority}[/red]')
            return

        if priority!='m':
            prioty=f'{self.priorities[priority]}'

        else:
            prioty_1=f'{self.priorities[priority]}'

        txt=input('Enter new note: ')
        time_write=time.asctime()
        
        if key:
            ciph=gem(txt,key) # maybe you want to encode your todo
            dataa = {'ciph_text':ciph,'priority':prioty_1 if priority=='m' else prioty,'time_write':time_write,'mode':'key_used'}
            lis_t.append(dataa) #for compatibility, todo file has a preinstalled note at the first list/array index
            with open(self.add_file,'w',encoding='utf-8') as fil_e:
              #  fil_e.write(f'{time_write}: {ciph}, priority:{prioty_1 if priority=='m' else prioty}\n')
                
           #     dataa = {'ciph_text':ciph,'priority':prioty_1 if priority=='m' else prioty,'time_write':time_write,'mode':'key_used'} #the mode onlyntwlls if a key was used ornnot.
                json.dump(lis_t,fil_e,indent=4)
                #fil_e.close()

            with open(self.admin,'r') as f:
                lst = json.load(f)



            with open(self.admin,'w',encoding='utf-8') as fil_e:
                dataa = {'ciph_text':ciph,'key':key,'global_ciph_sett':wrt} #if global sett ciph is true then intwrnal random keys are used if not then the internal keys are not usd and key passed by user was used or nonkey was pssed by user.
                lst.append(dataa)
                json.dump(lst,fil_e,indent=4) #for the admin only accessed via the outside method the global method.


        else:
            with open(self.add_file,'w',encoding='utf-8') as fil_e:
               # fil_e.write(f'{time_write}: {txt}, priority:{prioty_1 if priority=='m' else prioty}\n')
                dataa = {'raw_text':txt,'priority':prioty_1 if priority=='m' else prioty,'time_write':time_write,'mode':'key_not_used'}
                lis_t.append(dataa)
                json.dump(lis_t,fil_e,indent=4)
             #   fil_e.close()

            with open(self.admin,'r') as f:
                lst = json.load(f)

            with open(self.admin,'w',encoding='utf-8') as f:
                dataa = {'raw_text':txt,'global_ciph_sett':wrt}
                lst.append(dataa)
                json.dump(lst,f,indent=4)

        console.print('\n[bold green]...Done...[/bold green]\n')

 #       if restore:
  #          '''restores a deleted note/todo'''
   #         with open(self.deleted_file,'r') as fil_e:
    #            lis_t = fil_e.read().splitlines()
     #           fil_e.close()
#
 #           console.print('[bold yellow]MAXIMUM ENTRIES TO RESTORE: {len(lis_t)}[/bold yellow]')
#
 #           console.print('[bold blue]\t\t   ...Deleted entries...[/bold blue]')
  #          for index,itm in enumerate(lis_t):
   #             print(f'({index}) {itm}')
    #            print()
#
 #           while len(lis_t) != 0:
  #              resto = ''
#
 #               while resto != 'q':
  #                  resto = input('Enter entry to restore: ').lower()
   #                 time_resto = time.asctime()
#
 #                   while not resto.isdigit() and not resto.isalpha(): #special characters
  #                      console.print('[bold Cyan]')
#
 #                       resto = input('Enter entry to restore: ').lower()
#
#
#
 #                   if not resto.isalpha(): # if resto.isdigit():
  #                      restored = lis_t.
#
 #                   with open(self.recycled_file,'a') as fil_e:
  #                      for item_r in lis_t:
   #                         fil_e.write(f'Time_restored={item_r}')
#

           # console.print('[bold red]recycle bin is empty[/bold red]')


        

    def delete_todo(self,clrh: str=None):
        '''deletes and updates the add_file file'''

        self.setu()


        if os.name=='nt':
            os.system('cls')
        else:
            os.system('clear')


        #print('\nUse (0) to delete the first entry and...\n')

        if clrh:
            '''clears all the entries in recycle bin'''

            #confirm = input('Confirm[y/n]').lower()
            clrh = clrh.lower()
            #confirm = ''
            j = ['y']  #,'n']
            while clrh in j:

                console.print('[bold red]CONFIRM EMPTY RECYCLE BIN...[/bold red]')
                t = ['y','n']


                confirm = input('       Confirm[y/n]: ').lower()

                while confirm in t:
                    if confirm=='n':
                        print('Cancelled')
                        sys.exit(0)

                    with open(self.deleted_file,'w',encoding='utf-8') as fil_e:
                        time_emptied  = time.asctime()
                       # fil_e.write(f'emptied at {time_emptied}')
                        json.dump([{'cleared':f'emtptied at{time_emptied}'}],fil_e,indent=4)


                    console.print('[bold red]EMPTIED[/bold red]')
                    #print('redirecting to second delete...\n')
                    sys.exit(0)
                console.print('[bold red]TO CONFIRM USE Y/y TO DECLINE USE N/n[/bold red]')
                #sys.exit(0)

            console.print('[bold magenta]USE y for YES. ONLY SUPPORTS Y/y[/bold magenta]')
            sys.exit(0)


           # while confirm in j: keeping restored entries gor now

               # console.print('[bold red]CONFIRM EMPTY RESTORED[/bold red]')



        dele_te=''

        while dele_te!='q':

            if os.name=='nt':
                os.system('cls')
            else:
                os.system('clear')

            print('\nUse the displayed index to delete the target entry...\n')


            with open(self.add_file,'r') as fil_e:
              #  lis_t=fil_e.read().splitlines()
                lis_t = json.load(fil_e)
             #   fil_e.close()

            with open(self.admin,'r') as f:
                admn = json.load(f)

            with open(self.deleted_file,'r') as f:
                dtd = json.load(f)


        #    with open(self.recycled_file,'r') as fil_e:
         #       lis_tt = fil_e.read().splitlines()
          #      fil_e.close()
#
 #           for itm_3 in lis_tt:
  #              lis_t.append(itm_3)
        
            console.print('[bold blue]\t\t   ...available entries...[/bold blue]')
            for index, liist in enumerate(lis_t):
                if index==0: #index zero contains meaningpess data
                    continue
                print(f'({index}) {liist}') 
        

            console.print(f'\n[bold yellow]Max entries to delete..{len(lis_t)-1}..[/bold yellow]\n') #because of the json version ..the json files alaways contain a zeroth index meaningless..
            dele_te=input('Enter entry index to Delete[q to quit]: ').lower()
            
            #if not dele_te.isalpha():
             #   if dele_te.isdigit():
              #      if int(dele_te)>15:
               #         console.print('[bold red]--..Error. Only a max of 15 entries can be entered and deleted.[/bold red]')
                #        sys.exit(0)

            # special characters are handled by the while not q statement. how? only an int is worked on if not int it will movebto next loop-iteration.
            if dele_te.isdigit():
                dele_te = int(dele_te) #assumimg the user follows the index format to enter the delete number..

            
            if dele_te in range(len(lis_t)) and dele_te!=0:    #range(self.in_str):  # dele_te.isdigit()
                
                my_list=lis_t.pop(int(dele_te))
                admn_rm = admn.pop(int(dele_te))
                time_delete=time.asctime()
                print()

                with open(self.deleted_file,'w',encoding='utf-8') as fil_e:
                  #  fil_e.write(f'Time_Deletion={time_delete} --- {my_list}\n')
                    dataa = {'deleted':my_list,'time_deletion':time_delete} #my list is a whole divtionaery inside the parent dictionary
                    dtd.append(dataa)
                    json.dump(dtd,fil_e,indent=4)
                  #  fil_e.close()
        
                with open(self.add_file,'w',encoding='utf-8') as fil_e:
                 #   for item in lis_t:
                  #      fil_e.write(f'{item}\n')
                    json.dump(lis_t,fil_e,indent=4)
                 #   fil_e.close()

                with open(self.admin,'w',encoding='utf-8') as f:
                    dat = {'deleted_admin_data':admn_rm}
                    admn.append(dat)
                    json.dump(admn,f,indent=4)

                console.print('[bold blue]..Done..[/bold blue]\n')
                time.sleep(0.3)

        console.print('[bold red]..Quit..[/bold red]\n')


    def settings(self,reset=None,single=None):
        '''just as the name says. the settings interface to valley'''

        if reset and single:
            console.print('[red]choose one between the ¦choosing the file to clear or allow valley to clear them all automatically¦ [/red]')
            return

        if os.name=='nt':
            os.system('cls')
        else:
            os.system('clear')

        lst = ['y','n']

        if reset:
            console.print('\n[bold white]Re-set ?[Y/n]\nThis will clear all of the files if given Y¦y and exit the settings interface if given n¦N[bold white]\n')
            print()
            res = input('   [Y/N]: ').lower()

            while res not in lst:
                console.print('[red]Caps insesitive Alert. Either use Y for yes or n for No[/red]')
                res = input('   [Y/n: ]').lower()

            if res=='y':
                console.print('[white]Continuing to clear all files.../[/white]')
                time.sleep(2)
                with open(self.add_file,'w',encoding='utf-8') as f:
                   # f.write(f'cleared at {time.asctime()}')
                    json.dump([{'cleared':f'cleared at {time.asctime()}'}],f,indent=4)
                    #f.close() this with statement auto vloses the file when it exits

                with open(self.deleted_file,'w',encoding='utf-8') as f:
                   # f.write(f'cleared at {time.asctime()}')
                    json.dump([{'cleared':f'cleared at {time.asctime()}'}],f,indent=4)

                with open(self.recycled_file,'w',encoding='utf-8') as f:
                   # f.write(f'cleared at {time.asctime()}')
                    json.dump([{'cleared':f'cleared at {time.asctime()}'}],f,indent=4)

              #  console.print('\n[white]Done[/white]')

                with open(self.admin,'w',encoding='utf-8') as f:
                    json.dump([{'cleared':f'cleared at {time.asctime()}'}],f,indent=4) #if add_file is cleared so must admin file for compatibility

                with open(self.setup_file,'w',encoding='utf-8') as f:
                   # setup_reset = {'ciph_sett':None,'location_setting':None} #always update this dictionary for setup file..moved to class initialization method.
                    json.dump(self.setup_reset,f,indent=4)


                console.print('\n[white]Done[/white]')

                return
            else:
                console.print('\n[bold white]Exiting the settings interface[/bold white]')
                return


        ##Single file Deletion..##
        if single:
            console.print('\n[white]This enables you to select which file to clear[/white]\n')
            print()
            print('use the displayed index to select target.\n')

            f_lst = [self.add_file,self.deleted_file,self.recycled_file]
            idf = [0,1,2]

            console.print(f'[bold yellow]Maximum files available for clearing: {len(f_lst)}[bold yellow]\n')
            print('         Available files:')

            for _,idx in enumerate(f_lst):
                print(f'''({_}) {'Available entries file.' if idx==self.add_file else 'Deleted entries file.' if idx==self.deleted_file else 'Recycled/restored entries file.' if idx==self.recycled_file else 'ERROR'}''')

            try:
                print()
                si = int(input('File index ? : '))
            except ValueError:
                console.print('\n[red]use intergers.[/red]')
                return

            print()
            while si not in idf:
                console.print(f'[red]A maximum of {len(f_lst)} files are available. your chosen index was: {si}[/red]\n')
                #time.sleep(1.5)
                try:
                    print()
                    si = int(input('File index ? : '))
                except ValueError:
                    console.print('[red]use intergers[/red]')
                    return

            console.print('[white]Continuing.../[/white]')
            time.sleep(2)


            #while True:

            if si==0:
                with open(self.add_file,'w',encoding='utf-8') as f:
                  #  f.write(f'cleared at {time.asctime()}')
                    json.dump([{'cleared':f'cleared at {time.asctime()}'}],f,indent=4)
                    
                    with open(self.admin,'w',encoding='utf-8') as f:
                        json.dump([{'cleared':f'cleared at {time.asctime()}'}],f,indent=4)

                console.print('\n[yellow]Available entries file cleared[/yellow]')

                #time.sleep(1.5)
                return
            elif si==1:
                with open(self.deleted_file,'w',encoding='utf-8') as f:
                  #  f.write(f'cleared at {time.asctime()}')
                    json.dump([{'cleared':f'cleared at {time.asctime()}'}],f,indent=4)

                console.print('\n[yellow]Deleted entries file cleared[/yellow]')
                #time.sleep()
                return
            elif si==2:
                with open(self.recycled_file,'w',encoding='utf-8') as f:
                  #  f.write(f'cleared at {time.asctime()}')
                    json.dump([{'cleared':f'cleared at {time.asctime()}'}],f,indent=4)


                console.print('\n[yellow]Recycled/restored entries file cleared[/yellow]')
                return


                #console.print('\n[white]want to clear another file ?[/white]')





        console.print('\n[bold white]Re-setup ?[Y/n][/bold white]\n')
       # lst = ['y','n']
        resetup = input('   [Y/n]: ').lower()

        while resetup not in lst:
            console.print('[bold red]Caps insesitive Alert. Either use Y for yes or n for No[/bold red]')
            resetup = input('   [Y/n]: ').lower()

        if resetup=='y':
            console.print('[bold white]Continuing.../[/bold white]')
            time.sleep(2)
            self.setu('y') #😈 the setu method and its option can only be accessed from the source code
        else:
            console.print('\n[bold white]Exiting the valley settings interface.../[/bold white]')
            return #the IDE friendly






    def list_todo(self,deleted=None,restored=None,talkastlo=None):
        '''lists the todo's'''

        self.setu() #in every method to make sure the setup runs regardless of which method choosed in the CLI at the start of setup at first time or wanting to resetup

        if os.name=='nt':
            os.system('cls')
        else:
            os.system('clear')


        print()
        #console.print('[bold blue]\t\t   ...Deleted entries...[/bold blue]')
        if talkastlo: #will be a phyisisc math note taking app??..maybe.
            console.print('[bold white]This interface allows viewing the contents of full_path.json which is located in Astlo_environment and is generated by valley via astlo.\nscroll to the most bottom part of the displayed text for human readable data.\nAstlo integration - if you want to see the actual results of the plot from the data, use astlo.anmte CLI+SDK[/bold white]\n\n\n')
            time.sleep(5)
            with open('full_path.json','r') as f:
                data = json.load(f)
            
       #     data_keys = []
        #    data_values = []
         #   for idx,itm in enumerate(data): #data is the main dictionary.
          #      data_keys.append(itm) #itm is one of the key to the dictionary
           #     data_values.append(data[itm]) #the keys index should follow the correspoding value..becyae i dont know thw contents for the dictionary..and i want to manipulate them one by ine. or just a soecific valuem...which i dont know its key...the below hashed out code was unnecessary..but you gotta start somewherw.
               # for i,m in enumerate(itm): #manipulated adictionarry to access the indibidiual objects..and mainuplayet them manipulate. i am not even using the idex i..and
               #     data_g.append(it)

              #  for i,m in enumerate(data_keys): #here i really need the index....ill use the main index fron the main for loop.idx.

        #    for idx,itm in enumerate(data_keys): #data_keys contains the keys fir the whole data dictionary.
         #       console.print(f'[bold white]{itm}: [/bold white][bold yellow]{data_values[idx]}[/bold yellow]\n')


            #the above hashed out code transaltes to this single block of code...yeah just start from scratch and make it better as you move..
            for idx,itm in enumerate(data): #or just for i in data...
                console.print(f'[bold white]{itm}: [/bold white][bold yellow]{data[itm]}[/bold yellow]\n')

            return


        if deleted:
            with open(self.deleted_file,'r') as fil_e:
          #      lis_t=fil_e.read().splitlines()
                lis_t = json.load(fil_e)
           #     fil_e.close()
        
            console.print('[bold blue]\t\t    ...Deleted entries...[/bold blue]')
            for index, liist in enumerate(lis_t):
                if index==0:
                    continue
                print(f'({index}) {liist}')
            print()

        print()
        #console.print('[bold blue]\t\t   ...available entries...[/bold blue]')
        if restored: #to view the restore history
            with open(self.recycled_file,'r') as fil_e:
              #  lis_t = fil_e.read().splitlines()
                lis_t = json.load(fil_e)
               # fil_e.close()

            console.print('[bold blue]\t\t    ...Restored entries...[/bold blue]')
            for index,liist in enumerate(lis_t):
                if index==0:
                    continue
                print(f'({index}) {liist}')
            print()

        print()
        with open(self.add_file,'r') as fil_e:
           # lis_t=fil_e.read().splitlines()
            lis_t = json.load(fil_e)
            #fil_e.close()

  #      with open(self.recycled_file,'r') as fil_e:
   #         list_1 = fil_e.read().splitlines()
    #        fil_e.close()
#
 #       for itm_r1 in list_1:
  #          lis_t.append(itm_r1)
        
        console.print('[bold blue]\t\t    ...Available entries...[/bold blue]')

        for index, liist in enumerate(lis_t):
            if index==0:
                continue
            print(f'({index}) {liist}')
        print()




    def decode(self):
        '''the method that decrypts the encrypted text if available. this method only automatically decrypts the automatically encrytped text if ciph_sett key == True. if False, the user must always remember the key used''' #howeber if the user forgwts, valley still chiniyamaji records the key used...

        self.setu()

      #  if data==None:
       #     console.print('[red]data to be decoded is required[/red]')
        #    return
        
        with open(self.setup_file,'r') as f:
            is_auto_manual = json.load(f)

        if is_auto_manual['ciph_sett']!=True:
            console.print('[red]This functionality only works with the automatically encoded entries activated through the settings command.\nIf key was used manually, use the manual_decode function. remember your key used if key==__manual__')
            return


     #   if data==None:
      #      return 'data to be decoded is required'

        if os.name=='nt':
            os.system('cls')
        else:
            os.system('clear')

        console.print('[bold white]This functionality only automatically decodes encoded data if ciph_sett == True. if False, the user should pass the remembered key to the key option in the CLI.\n\nThe user should remember the key used if they manually pass a key for encoding.[/bold white]\n\n')


        with open(self.add_file,'r') as f:
            data = json.load(f)


        while len(data)!=1: #zer9th index contains meaningless data always
            decode = ''

            while decode!='q':
                if os.name=='nt':
                    os.system('cls')
                else:
                    os.system('clear')
     
                console.print('[bold yellow]Available recorded entries.\nUse the index displayed to select target entry...[/bold yellow]\n')

                for _,idx in enumerate(data):
                    if _==0:
                        continue
                    print(f'({_}) ¦¦ {idx}')


                decode = console.input('\n[bold white]Enter entry index to decode [q to quit]: [/bold white]').lower()

                while not decode.isdigit() and not decode.isalpha():
                    console.print('[red]do not use special characters[/red]')
                    decode = console.input('\n[bold white]Enter entry index to decode [q to quit]: [/bold white]').lower()



             #   while data[decode]['mode']!='key_used':
              #      console.print(f'[red]selected entry {decode} cannot be decoded because it is in raw_text/original_format.[/red]')
               #     decode = console.input('[bold white]Enter index entry to decode: [/bold white]')


                if decode.isdigit():
                    decode = int(decode)


                if decode in range(len(data)) and decode!=0: #only intergers enter this if statement./

                    while data[decode]['mode']!='key_used':
                        console.print(f'[red]selected entry {decode} cannot be decoded because it is in raw_text/original_format.[/red]')
                        decode = console.input('\n[bold white]Enter entry index to decode [q to quit]: [/bold white]').lower()


                    #first i pop the desired data#...not popping pop will remove the data
               #     poped = data[decode]['ciph_text'] #while of valley assumes the user uses the displayed index values
              #      text_desired_decode = poped #not kn purpose
               #     from .mark import ini


  #              if decode.isdigit():
 #                   decode = int(decode)
#

            #    if decode in range(len(data)):

                    with open(self.admin,'r') as f:
                        adm = json.load(f)

                    decoded_text_desired = ini(data[decode]['ciph_text'],adm[decode]['key'])
                    console.print(f'\n\n[bold cyan]white spaces are removed for security reasons. decoded text: [/bold cyan][bold white]{decoded_text_desired}[/bold white]\n')

                    sys.exit(0) #exit after decoded..so as to allow the user to see the text.

            console.print('[red]Quit[/red]')
            return

        console.print('[red]No available entries to decode[/red]')
        return






    def manual_decode(self,key: str=None):
        '''the method that allows the user to hard decode using the key that was passed manually. This method only works if the auto-encode setting == False or No.'''

       # valleyed = Valley()
       # valleyed.setu()
        self.setu()
    
        if key==None:
            console.print('[red]The key that was used manually is required.[/red]')
            return

        #with open(self.add_file,'r') as f:
        #   data = json.load(f)


        #console.print('[bold yellow]        Available recorded entries.\n       Use the index displayed to select target entry...[/bold yellow]\n\n')

        #for _,idx in enumerate(data):
        #  print(f'({_}) {idx}')
        # print(

        if os.name=='nt':
            os.system('cls')
        else:
            os.system('clear')

        with open(self.setup_file,'r') as f:
            is_auto_manual = json.load(f)

        if is_auto_manual['ciph_sett']!=False:
            console.print('[red]This functionality only works with the manually encoded entries activated through the add-todo command --key option and the cipher setting set internal-random-automatic as false or no. Override the cipher setting and try again.\n')
            return



        with open(self.add_file,'r') as f:
            data = json.load(f)


        while len(data)!=1:
            forgot = ''

            while forgot!='q':

                if os.name=='nt':
                    os.system('cls')
                else:
                    os.system('clear')


                console.print('[bold yellow]Available recorded entries.\nUse the index displayed to select target entry...[/bold yellow]\n\n')

                for _,idx in enumerate(data):
                    if _==0:
                        continue
                    print(f'({_}) {idx}')

                forgot = console.input('\n[bold white]Enter entry index to decode [q to quit]: [/bold white]\n').lower()

                while not forgot.isdigit() and not forgot.isalpha():
                    console.print('[red]do not use special characters[/red]')
                    forgot = console.input('\n[bold white]Enter entry index to decode [q to quit]: [/bold white]').lower()


                if forgot.isdigit():
                    forgot = int(forgot)


                if forgot in range(len(data)) and forgot!=0:

                    while data[forgot]['mode']!='key_used':
                        console.print(f'[red]Selected entry {forgot} cannot be decoded becuase it is in raw_text/Original_format.')
                        forgot = console.input('\n[bold white]Enter entry index to decode [q to quit]: [/bold white]').lower()

          #  if forgot.isdigit():
           #     forgot = int(forgot)

            #if forgot in range(len(data)):

                    target_entry = data[forgot]['ciph_text']

          #      from .mark import ini
                    forgot_decode = ini(target_entry,key)

                    console.print(f'[bold cyan]white spaces are removed for security reasons. decoded text: [/bold cyan][bold white]{forgot_decode}[/bold white]\n')

                    sys.exit(0)

            console.print('[red]Quit[/red]')
            return

        console.print('[red]No available entries to decode[/red]')
        return



    def override_decode(self,entry: str=None):
        '''incase the auto-decode method fails for the internal keys encoding logic'''

#this method was for the previous manually crrated leys..like how i would just type random strings into the key file and then valley reads from it..that was not secure..now valley automatucally generates strings, stores them and uses them for encoding.
        if entry==None:
            return 'entry value is required'

        if os.name=='nt':
            os.system('cls')
        else:
            os.system('clear')

        with open(self.key_file,'r') as f:
            data = json.load(f) #a list

        dcd = []
        for idx,itm in enumerate(data):
            if idx==0:
                continue #zeroth index contains presinstalled entry for compatibility with jaon file.
            dcd.append(ini(entry,itm))


        return dcd



    def randomgen(self):
        '''this method generates random strings which are then used by the encoder if ciph_sett==True'''
        # guesses a random number then uses that number value to create a string with letters that match exactly the number value..if index guessed is 5 ghen the generated steing should contain 5letters. numbers and letters only..No special characters..

    #    check = random.randint(0,1) #if 0 then the string will only ever contain letters and if 1 then the string will contain both alphabetic and numeric letters..

        check = 0 # the vigenere cipher has to be tweaked i  order to allow using numbers as key to encode an entry..

        
        index = random.randint(4,12) # endpoints = (5,13) .. a string with a maximum of 13 letters and a minimum of 5. the letter can be alphabetic or alphanumeric

      #  if check==0:
       #     string_generate_index = random.randint(1,25) #25 possible english letters.
        #    numero_generate_index = None
      #  elif check==1:
       #     string_generate_index = random.randint(1,25)
        #    numero_generate_index = random.randint(0,9) #yeah 0 is also a possible number
            #the above block wo8ld only generate one value forever..adding it into the for loop to genrate random values for every step...

       # iter_list = []
 #       if check==1: #both..this if statement logic helps the method know which of the both alpha and number generated should be used.. because the final string should contain index letters..whether number or alpha..
  #          decider_dict = {0:string_generate_index,1:numero_generate_index}
   #         decider_helper = {0:'letters_only',1:'alphanumero'}
    #        decider = random.randint(0,1) #the output here will enable the program to know which of the two alphaonly/string with numbers and alpha mixed..
     #       choosen = decider_dict[decider] #demon time...this variable isnt needed..


        string_key = ''



        for itm in range(index): #range does not include the final value.. finalvalue-1..but we are just using the steps not the values. if index is 7 then 7 steps/index regardless of how range works.. 7=0,1,2,3,4,5,6 get it?? only using the steps..
            if check==0:
                string_generate_index = random.randint(1,25) #25 possible english letters.
                string_key += self.alpha[string_generate_index]


            elif check==1: #the following logic will help tell which of the both possibilities alphaonly/alphanumero should be used if check==1==mixed
                string_generate_index = random.randint(1,25)
                numero_generate_index = random.randint(0,9) #yeah 0 is also a possible number

           #     if check==1: #both..this if statement logic helps the method know which of the both alpha and number generated should be used.. because the final string should contain index letters..whether number or alpha..
                
                decider_dict = {0:string_generate_index,1:numero_generate_index}
                decider_helper = {0:'letters_only',1:'alphanumero'}
                decider = random.randint(0,1) #the output here will enable the program to know which of the two alphaonly/string with numbers and alpha mixed..
                choosen = decider_dict[decider] #demon time...this variable isnt needed..

                if decider_helper[decider]=='letters_only':
                    string_key += self.alpha[string_generate_index] #or string_key += self.alpha[choosen]
                elif decider_helper[decider]=='alphanumero':
                    string_key += self.numero[numero_generate_index] #or string_key += self.numero[choosen]
            else:
                return 'Error at randomgen'


        return {'string_key':string_key,'mode':f'{'alphabetic' if check==0 else 'alphanumeric'}. {check}','size_key':f'{index} letters','explanation':'the mode can be either alphabetic only or alphanumeric. Although, mode can be 1 for mixed but the returned string is only alphabetic or numeric only.'}






    def manual_decode_two(self,key: str=None):
        '''This method allows hard decode if key was passed manually. This method differs from manual_decode. manual_decode expects the auto-decode setting == False or No while manual_decode_two does not require any setting. The only requiremnt here is the key that was used manually. The key must be remembered though.'''
        ##I DONT KNOW WHY EVEN I WAS BUILDING THIS METHOD... if i fall into an error, ill just use the SDK part for valley to decod3.. Tgere are two possibilities 1=ciph_sett==True or 2=ciph_sett==False and they both have their own methods for decoding...So the following code in this method is useless..
        return 'discontinued'
       # pass

        if key==None:
            return 'the key passed manually is needed'

        if os.name=='nt':
            os.system('cls')
        else:
            os.system('clear')

        if key==None:
            console.print('[red]The key that was used manually is required.[/red]')
            return

        console.print('[bold white]The method that requires only the key that was passed manually[/bold white]')

        with open(self.add_file,'r') as f:
            data = json.load(f)

      #  while len(data)!=1: #i dont have to check if !=1 because json file will alays contain a zeroth index
        m_decode = ''

        while m_decode!='q':
            pass
            if os.name=='nt':
                os.system('cls')
            else:
                os.system('clear')

            console.print('[yellow]This method allows ')
            pass









