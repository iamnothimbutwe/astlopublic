
from .interface import ltx


if __name__ == '__main__':
    ltx()
