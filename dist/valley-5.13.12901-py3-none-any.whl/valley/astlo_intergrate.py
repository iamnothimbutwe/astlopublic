
from rich.console import Console
import os
import sys
from importlib import resources
from packaging import version
import json
from .valley import Todo

console = Console()
try:
    #import astlo
    from astlo import Vectors, __version__, Eo, Topocentric, Astro, Solexp, sate_posvel, Contin, Lsim, Mat, Humanread
    from astlo.np_encoder import NumpyEncoder
    

    from asho import Asho #2nd requirement for precision and moon tracking.
    from .astlotalk import talk #another key requiremn.moving the script to package root for valley...still best run in astloenvironment though.

    required_version = version.parse("v12.5.0") #astlo is the main requiremnt...the full astlo not the core engine...a usernusingnthe core engine will not be able to use this feature for valley...the settings file to store default the current location for user...
    installed_version = version.parse(__version__)

    if installed_version < required_version:
        print("\n❌🚫 ERROR: valley requires astlo >= v12.5.0")
        print(f"   You have astlo {__version__} installed.")
        print("   Please upgrade with:   pip install ¦new .whl file¦ the .whl files are available in the releases section of the public repo to astlo")
        print("   Then try installing or running valley again.\n")
        sys.exit(1)



except ImportError as r:
    print("\n❌🚫 ERROR: valley requires astlo to be installed first.")
    print("   Please install astlo with: astlo>=v12.5.0 from the public repo to astlo")
    print("   Then try installing or running valley again.\n")
    print(f'{r}') #dope..prints the error..helped me debugg something..
    sys.exit(1)                                                                         
#except Exception as e:
 #   Fallback in case packaging module is missing
 #  print(f"\n⚠️  🚫  Warning: Could not verify astlo version ({e})")
   # print("   Continuing anyway...\n")
    # pass




except ModuleNotFoundError:
    console.print('[bold red]astlo, astlohorizons and ¦astlotalk in Astlo-environment directory¦ are required.Either (one or two are missing) or (all are missing) Please install then try again[/bold red]')
    #return 'astlo>=v5.63.53 not found'
    sys.exit(1) #exit code 0 = success while exit code 1 = failure

#setup only checksbifbastlonis installed ..then this part habdlesnthe versioj part


astro = Astro() #doimg this in the class would have made it that i woild be calling astlo everytime. or maybe im still doong it..
contin = Contin()
mat = Mat()
vectors = Vectors()




class AstloIntergrate(Todo):
    '''this class allows valley to talk with astlo and its dependecies to generate appropriate json files'''
    def __init__(self):
        super().__init__()
        self.astro = astro
        self.talk = talk #flag
        self.mat = mat
        self.vectors = vectors
        self.contin = contin


    def genfullpath(self,name: str=None):
        '''generates a json file that contains 3D vectors for the full orbit of object name.'''
#adding all objects so no need to add if name not in supoored yet....Done..
#the final JSON file should contain all the data SSB full plus cureent r,v,orbital_day and heliocenteif and current r,v,orbital day
        if name==None:
            console.print('[red]name is required to continue for this method.[/red]')
            return 'name is required to continue for this method.'
        name = name.upper()
        values = ['MERCURY','VENUS','EARTH','MARS','VESTA','CERES','PALLAS','HYGIEA','JUPITER','SATURN','URANUS','NEPTUNE','PLUTO','HAUMEA','MAKEMAKE','ERIS','HALLEY','APOPHIS']

        if name not in values:
            console.print('[red]Name Not Supported.[/red]')
            return 'NAME NOT SUPPORTED'

        full_states = self.astro.orbits(name,'y',None,'y')
        current = self.contin.barycentric(name) #the current heliocentric states. and varycentric and osculating elemants...
        a_X,a_Y,a_Z = self.contin.acce(name)
       # current_SSB = self.contin.barycentric(name) barycentric returns both heliocebtric and barycentric..
        #full SSB path coming soon..
      #  current_states_helio_array = np.array(current['X_helio'],current['Y_helio']) #json auto converts them to lists 💔

        with open('full_path.json','w',encoding='utf-8') as file: # Best practice is to use everything associated with aslto in Astlo-environwmtn directory...this part of valley is best when run in that directory..but the other oart of Valley can be run evrywhere....

            data = {'Name':name,f'size_of_fullvectors_for_fullorbit_same_as_period_for_{name}':len(full_states['X_helio_list']),'full_r_vectors_X_m':full_states['X_helio_list'],'full_r_vectors_Y_m':full_states['Y_helio_list'],'full_r_vectors_Z_m':full_states['Z_helio_list'],'full_r_vectors_X_AU':full_states['X_AUheliolist'],'full_r_vectors_Y_AU':full_states['Y_AUheliolist'],'full_r_vectors_Z_AU':full_states['Z_AUheliolist'],'perifocal_x_full_vectors':full_states['x_list_peri'],'perifocal_y_full_vectors':full_states['y_list_peri'],f'CURRENT_r_fullvector_relative_Heliocenter_UTCtime={str(current['utc_time'])}':([current['X_helio'],current['Y_helio'],current['Z_helio']],'units = m'),f'Current_r_fullvector_relative_SSB_UTCtime={str(current['utc_time'])}':([current['X_bary'],current['Y_bary'],current['Z_bary']],'units = m'),'UTC_time':str(current['utc_time']),f'current_orbital_day_on_{name}':current['resp_day'],'Current_v_fullvector_relative_heliocenter':([current['v_Xhelio'],current['v_Yhelio'],current['v_Zhelio']],'units = m/s'),'Current_v_fullvector_relative_SSB':([current['v_X'],current['v_Y'],current['v_Z']],'units = m/s'),'Current_gravitational_acceleration_fullvector_relative_SSB':([a_X,a_Y,a_Z],'units = m/s²'),'osculating_element_a_Heliocentric_m':current['osc_ahelio'],'osculating_element_a_Barycentric_m':current['osc_a'],'osculating_element_e_heliocentric_fullvector_unitless':[current['e_Xhelio'],current['e_Yhelio'],current['e_Zhelio']],'osculating_element_e_Barycentric_fullvector_unitless':[current['e_X'],current['e_Y'],current['e_Z']],'osculating_element_i_heliocentric_relative_ecliptic':current['osc_ihelio'],'osculating_element_i_Barycentric_relative_ecliptic':current['osc_i'],'Longitude_of_ascending_node_Ω Omega_heliocentric_degrees':current['Omegahelio'],'Longitude_of_ascending_node_Ω Omega_Barycentric_degrees':current['Omega'],'argument_of_perihelion_ω omega_degrees':current['argof_perihelion'],'argument_of_periapsis_ω omega_Barycentric_degrees':current['argof_periapsis'],'True_anomaly_Nu_heliocentric_degrees':current['true_anomalyhelio'],'True_anomaly_Nu_barycentric_degrees':current['true_anomaly'],'Notes and explanations':'astlo has an inbuilt rk4 intergrator. Use it to get refined states for any solarsystem object X.\nUse astlo.vectors to work around the vectors in this file.\nUse astlo.humanread to get full details including history,explorations,pictures,videos,scientific_facts for any Solar system object X.\nThe consumer of this file can manipulate the data by: plotting perifocal, 2D and 3D real-time visuals.\nThe Full astlo suite is best because the core version lacks some features that are required by valley.\nBest practice is to run anything related to astlo in the Astlo-environment directory. This part of Valley that uses astlo included. The other parts of valley are universal meaning they can be run in any directory. If this part of valley that uses astlo is used in another directory/environment other than the stated one, the user will leave files everywhere.\nHence the stated environment as Best practice.\nAstlo Space Systems, r/kenyaspacenerds'}

            json.dump(data,file,cls=NumpyEncoder,indent=4)


        return 'complete'

#add note..plus runge kutta should be its own method ..have its own file..Done...
#no passing magnitudes...its a json file


   # def rk4(self,name: str=None,days: int=None,tt)
