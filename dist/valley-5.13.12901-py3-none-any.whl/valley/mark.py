from .dect_ import dict_, dict__, dict___, dict____

# ---------------------------------------------------------
# Copyright (c) 2026 Mark. All rights reserved.
# Unauthorized copying of this file, via any medium, is 
# strictly prohibited. Written by Mark (iamnothimbutwe) on Github.
# ---------------------------------------------------------






# in one way i can use whitespaces in the cipher and original string..and the second way i remove the whitespaces b4 i enumerate to encode...

# what if one wants to use a key with whitespaces..? need to adjust..

# removed the whitespaces becoz its easy to crack the cipher with the whitespaces included



def gem(string: str, key: str):
    '''vigenere cipher encoding function'''

    o_string=string.lower()
    key=key.lower()
    key_length=len(key)
    ciph=''
    new=''

    for letter in o_string:
        if letter in dict___:
            o_string=o_string.replace(letter,dict___[letter])
        else:
            continue

    for letter in o_string:
        #if letter.isalpha():
        if letter==' ':
            continue
        else:
            new += letter

    for index, letter in enumerate(new):
        #if not letter.isalpha():
            #ciph += letter
            #continue
        if letter=='.':
            ciph += letter
            continue

        if letter not in dict____:
            key_index = index % key_length
            key_char = key[key_index]
            o_num = dict_[letter]
            key_num = dict_[key_char]
            ciph_num = ((o_num+key_num) % 26)
            ciph_char = dict__[str(ciph_num)]
            ciph += ciph_char
        else:
            #continue
            ciph += letter

    return ciph



def ini(string: str, key: str):
    '''vigenere cipher decoding function'''

    o_string=string.lower()
    key=key.lower()
    key_length=len(key)
    ciph_o=''
    #new=''
    
    for letter in o_string:
        if letter in dict____:
            o_string=o_string.replace(letter,dict____[letter])
        else:
            continue

    #for letter in o_string:
        #if letter.isalpha():
        #if letter==' ':
            #continue
        #else:
            #new += letter

    #for index, letter in enumerate(new):
    for index, letter in enumerate(o_string):
        #if not letter.isalpha():
            #ciph_o += letter
            #continue
        
        if letter=='.':
            ciph_o += letter
            continue

        if letter not in dict___:
            key_index = index % key_length
            key_char = key[key_index]
            ciph_num = dict_[letter]
            key_num = dict_[key_char]
            o_num = ((ciph_num - key_num) % 26)
            o__char = dict__[str(o_num)]
            ciph_o += o__char
        else:
            #continue
            ciph_o += letter

    return ciph_o


#if __name__=='__main__':
    #print(ini(gem('wassup bi5ch 3900','was'),'was'))
    

