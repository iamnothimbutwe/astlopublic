'''
valley

an encrypted note/Todo taking CLI that encrypts through ciphers.
It is also the json file generator for astlo engine

It is basically a note/todo taking CLI that integrates ciphers for security and also acts as a physics CLI powered by astlo'
'''

__version__ = 'v5.15.14901'
__author__ = '@iamnothimbutwe on Github and Gitlab. Sisi'
__email__ = 'astlospacesystems@gmail.com'

from .valley import Todo  #5he user shoild only access the cipher logic..thatbwas then with this randomgen method, i would like to access it anytime..
from .mark import gem, ini #the tool used to decrypt

__all__ = ['Todo','gem','ini','__version__','__author__','__email__']
