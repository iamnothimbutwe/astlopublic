##matplotlib and numpy##

import matplotlib
from rich.console import Console

console=Console()

#matplotlib.use('TkAgg')

try:
    matplotlib.use('TkAgg')
    console.print('[bold Cyan]Using TkAgg backend.[/bold Cyan]')
except ImportError:
    # If TkAgg fails, let Matplotlib pick the best available backend automatically
    console.print('[bold red]Warning: Tkinter not found. Falling back to default backend.[/bold red]')
    pass 

#import matplotlib.pyplot as plt

from .astlo import Astro
from .contin import Contin
from rich.console import Console
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import StrMethodFormatter
import time

##matplotlib uses specific geometric markers not like plotext##


astro = Astro()
contin = Contin()
#console = Console()


class Mat:
    def __init__(self):
        self.mission = 'to make astrophysiscs and the universe available to anyone with just a phone or a terminal without needing heavy libraries or the internet.'
        self.working = 'uses the TkAgg X-11 friendly backend'

    def matpt(self,name: str=None,baryc=None):
        '''the 3D projections..orbit supported 11 objects plotting. i will update'''

        if name==None:
            console.print('[bold red]NAME CANNOT BE NONE OR EMPTY[/bold red]')
            return ##IDE friendly..
        name = name.upper()

        vallues = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'CERES':1681,'JUPITER':4333,'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174}

        if name not in vallues.keys():
            console.print('[bold red]NAME NOT LOCALLY RECOGNIZED FOR VISUALIZATIONS OR WRONG SPELLING\nSUPPORTS PLOTTING 11 OBJECTS AS OF NOW[/bold red]')
            return

        vallues_1 = {'MERCURY':'red','VENUS':'yellow','EARTH':'blue','MARS':'red','CERES':'grey','JUPITER':'grey','SATURN':'grey','URANUS':'cyan','NEPTUNE':'blue','PLUTO':'grey','ERIS':'red','HAUMEA':'grey','MAKEMAKE':'grey','HYGIEA':'grey','VESTA':'grey','PALLAS':'grey'} #mat uses specific geometric markers use the colors in the dictionary

        if baryc:
            pass


        #ret = astro.orbit(0,vallues.get(name,-2),None,'y')
        ret = contin.reel(name) # heliocentric frame
        reti = contin.barycentric(name)
        tro = astro.orbit(0,int(vallues.get(name,'ERROR')),None,'y')


        py_list = []
        for _,idx in enumerate(ret['X_helioAU']):
            g = [idx,ret['Y_helioAU'][_],ret['Z_helioAU'][_]]
            py_list.append(g)

        array_np = np.array(py_list)
        X = array_np[:,0] #all rows first column
        Y = array_np[:,1] #second volumn
        Z = array_np[:,2]

        fig = plt.figure(figsize=(10,10))
        ax = fig.add_subplot(projection='3d') #maybe the 111 was kinda makingit render one small box square quadrant

        ax.plot(tro['x_list_peri'],tro['y_list_peri'],color='cyan',alpha=0.4,linewidth=0.7,label='2D orbit')


        ##plot##
        ax.plot(X,Y,Z,color='magenta',label=name,linewidth=1.2)
        ax.scatter([0],[0],[0],s=300,marker='o',color='yellow',label='sun') #the heliocenter..heliocentric frame plotting
        ax.scatter([reti['X_helio']/contin.AU_m],[reti['Y_helio']/contin.AU_m],[reti['Z_helio']/contin.AU_m],s=100,marker='o',color=vallues_1.get(name,'ERROR'))

        ax.set_facecolor('darkgrey')
        fig.patch.set_facecolor('darkgrey')

        #hide the grey grid lines
        ax.xaxis.pane.fill = False
        ax.yaxis.pane.fill = False
        ax.zaxis.pane.fill = False #obviously if not fals then default is true .?..maybe

        #the numbers to be int,float with how many decimal places.
        au_f = StrMethodFormatter('{x:.2f}AU')
        ax.xaxis.set_major_formatter(au_f)
        ax.yaxis.set_major_formatter(au_f)
        ax.zaxis.set_major_formatter(au_f)


        ##tick labels the numbers formatter##
        ax.tick_params(axis='x',color='white')
        ax.tick_params(axis='y',color='white')
        ax.tick_params(axis='z',color='white')

        ax.set_xlabel('x_AU',color='magenta')
        ax.set_ylabel('y_AU',color='magenta')
        ax.set_zlabel('z_AU',color='magenta')
        ax.set_box_aspect([1,1,1])
        ax.set_title(f'{name}-Unix time: {reti['Unix_time']}//{time.asctime()} Heliocentric',color='green')

        #save file

        output_save = f'{name}-Unix time: {reti['Unix_time']} or {time.asctime()} Heliocentric.png'
        plt.savefig(output_save,facecolor=fig.get_facecolor(),dpi=300)

        console.print(f'\n[bold Cyan]3D visualization rendered to {output_save} [/bold Cyan]\n')

        return plt


        #plt.show() # save the image instead of the mainloop to show one state.


    def fulplot(self):
        '''plots all of the orbits in one instance'''

        vallues = {'MERCURY':88,'VENUS':225,'EARTH':365,'MARS':687,'CERES':1681,'JUPITER':4333,'SATURN':10759,'URANUS':30685,'NEPTUNE':60190,'PLUTO':90465,'ERIS':204174}

        flx_list = []
        fly_list = []
        flz_list = [] #ill only append the live orbital plots and live positions
        psx_list = []
        psy_list = []
        psz_list = []
        fl_listx = []
        fl_listy = []
        fl_listz = []

        fl_ps = []

        tro = astro.orbit(0,int(vallues.get('ERIS','ERROR')),None,'y')



        for _ in vallues.keys():
            reel = contin.reel(_) #heliocentric
            ps = contin.barycentric(_)
            flx_list.append(reel['X_helioAU'])
            fly_list.append(reel['Y_helioAU'])
            flz_list.append(reel['Z_helioAU'])
            psx_list.append(ps['X_helio'])
            psy_list.append(ps['Y_helio'])
            psz_list.append(ps['Z_helio'])

        


        ##Numpy and matplotlib##

        for _,idx in enumerate(flx_list): #the array has a shape of 11, big number maybe😑..
            array_npfx = np.array(idx)
            array_npfy = np.array(fly_list[_])
            array_npfz = np.array(flz_list[_])

            fl_listx.append(array_npfx)
            fl_listy.append(array_npfy)
            fl_listz.append(array_npfz)

        px = np.array(psx_list)
        py = np.array(psy_list)
        pz = np.array(psz_list)



        fig = plt.figure(figsize=(10,10))
        ax = fig.add_subplot(projection='3d')

        ax.plot(tro['x_list_peri'],tro['y_list_peri'],color='cyan',alpha=0.4,linewidth=0.7,label='2D ORBIT')
        ax.scatter([0],[0],[0],s=400,color='yellow',marker='o',label='sun')

        vallues_1 = {'MERCURY':'magenta','VENUS':'yellow','EARTH':'blue','MARS':'darkred','CERES':'darkgrey','JUPITER':'lightgrey','SATURN':'black','URANUS':'lightblue','NEPTUNE':'darkblue','PLUTO':'red','ERIS':'magenta'}#'HAUMEA':'grey','MAKEMAKE':'grey','HYGIEA':'grey','VESTA':'g
        vallues_C = {'MERCURY':'MERCURY','VENUS':'VENUS','EARTH':'EARTH','MARS':'MARS','CERES':'CERES','JUPITER':'JUPITER','SATURN':'SATURN','URANUS':'URANUS','NEPTUNE':'NEPTUNE','PLUTO':'PLUTO','ERIS':'ERIS'}#'HAUMEA':'grey','MAKEMAKE':'grey','HYGIEA':'grey','VESTA':'grey','PALLAS':'grey'}

        name_l = [g for g in vallues_1.keys()]


        for _,idx in enumerate(fl_listx): #the multiple plots

            name = name_l[_]

            ax.plot(idx,fl_listy[_],fl_listz[_],color=vallues_1.get(name,'ERROR'),linewidth=1.3,label=vallues_C.get(name,'ERROR'))
            ax.scatter([px[_]/contin.AU_m],[py[_]/contin.AU_m],[pz[_]/contin.AU_m],s=120,color=vallues_1.get(name,'ERROR'),marker='o')


        ax.set_facecolor('darkgrey')
        fig.patch.set_facecolor('darkgrey')

        #hide the grey grid linne

        ax.xaxis.pane.fill = False
        ax.yaxis.pane.fill = False
        ax.zaxis.pane.fill = False #obviously if not fals then default is true .?..maybe

        #the numbers to be int,float with how many decimal places.

        au_f = StrMethodFormatter('{x:.2f}AU')
        ax.xaxis.set_major_formatter(au_f)
        ax.yaxis.set_major_formatter(au_f)
        ax.zaxis.set_major_formatter(au_f)
        
        ##tick labels the numbers formatter##

        ax.tick_params(axis='x',color='white')
        ax.tick_params(axis='y',color='white')
        ax.tick_params(axis='z',color='white')

        ax.set_xlabel('x_AU',color='magenta')
        ax.set_ylabel('y_AU',color='magenta')
        ax.set_zlabel('z_AU',color='magenta')
        ax.set_box_aspect([1,1,1])
        ax.set_title(f'Fulplot - Unix time: {ps['Unix_time']}//{time.asctime()} Heliocentric',color='green')

        #save file

        output_save = f'Fulplot - Unix time: {ps['Unix_time']} or {time.asctime()} Heliocentric.png'
        plt.savefig(output_save,facecolor=fig.get_facecolor(),dpi=300)

        console.print(f'\n[bold Cyan]3D visualization rendered to {output_save} [/bold Cyan]\n')


        return plt


    def pin(self):
        pass















        













        


