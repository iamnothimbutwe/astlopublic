
# Copyright © 2026 Mark Macharia [@iamnothimbutwe Github]
# All rights reserved.                                                
# Unauthorized copying, modification, distribution, or commercial use of this software (or substantial portions of it) is strictly prohibited without express written permission from the author.


"""
astlo
=====

A real-time and still developing Astronomy/Astrophysics/celestial orbital mechanics engine.

Features:
- Barycentric & heliocentric coordinates (16 bodies)
- Real-time positions +SSB, velocities, light delay
- Full orbital propagation in days/AU
- Orbit classification (circle/ellipse/parabola/hyperbola)
- Terminal plotting with plotext
"""

__version__ = "v5.65.61"
__author__ = "macharia/@iamnothimbutwe Github and Gitlab/Macharia"
__email__ = "markmacgh@gmail.com/hecateare@gmail.com"

# Exposing the main classes so users can do clean imports
from .astlo import Astro
from .contin import Contin
from .vect import Vectors

# Make theese classes available when someone does "from astlo import *"
__all__ = ["Astro","Contin",'Vectors',"__version__"]
